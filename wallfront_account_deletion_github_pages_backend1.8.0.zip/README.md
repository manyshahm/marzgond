# Wallfront account deletion page

Public Google Play account-deletion URL:

`https://manyshahm.github.io/wallfront-account-deletion/`

## Publish on GitHub Pages

1. Create a **public** repository named `wallfront-account-deletion` under the GitHub account `manyshahm`.
2. Extract this ZIP on your device.
3. Upload **the extracted files and folders**, including `.github`, to the repository root. GitHub does not extract uploaded ZIP files automatically.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **GitHub Actions**.
6. Run the workflow or push a commit. The page will be published at the URL above.

## Backend dependency

The page calls these HTTPS API routes:

- `https://persian-melody.ir/marzband/api/account/delete/verify`
- `https://persian-melody.ir/marzband/api/account/delete/confirm`

Upload the matching Backend `1.8.0` package before testing the page.

## Security

- No API key, password, Firebase credential, or service-account file is included.
- Credentials are not written to local storage, session storage, cookies, or the repository.
- The Backend accepts browser requests only from `https://manyshahm.github.io`.
- Successful verification creates a one-time deletion token valid for five minutes.
