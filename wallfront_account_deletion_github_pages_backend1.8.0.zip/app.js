'use strict';

const API_BASE = 'https://persian-melody.ir/marzband/api/account/delete';

const state = {
  step: 1,
  email: '',
  deletionToken: '',
  busy: false,
};

const elements = {
  steps: [...document.querySelectorAll('[data-step]')],
  progress: [...document.querySelectorAll('[data-progress]')],
  message: document.getElementById('global-message'),
  warningConfirm: document.getElementById('warning-confirm'),
  warningNext: document.getElementById('warning-next'),
  email: document.getElementById('account-email'),
  emailNext: document.getElementById('email-next'),
  password: document.getElementById('account-password'),
  togglePassword: document.getElementById('toggle-password'),
  verify: document.getElementById('verify-account'),
  dialog: document.getElementById('final-dialog'),
  cancelDelete: document.getElementById('cancel-delete'),
  confirmDelete: document.getElementById('confirm-delete'),
  reference: document.getElementById('deletion-reference'),
  backButtons: [...document.querySelectorAll('[data-back]')],
};

function createRequestId() {
  if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') {
    return globalThis.crypto.randomUUID();
  }
  return `req-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function showMessage(text, type = 'error') {
  elements.message.textContent = text;
  elements.message.classList.toggle('is-info', type === 'info');
  elements.message.hidden = false;
  elements.message.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function clearMessage() {
  elements.message.hidden = true;
  elements.message.textContent = '';
  elements.message.classList.remove('is-info');
}

function setStep(step) {
  state.step = step;
  clearMessage();
  elements.steps.forEach((section) => {
    const active = Number(section.dataset.step) === step;
    section.hidden = !active;
    section.classList.toggle('is-active', active);
  });
  elements.progress.forEach((item) => {
    const number = Number(item.dataset.progress);
    item.classList.toggle('is-active', number === step || (step === 5 && number === 4));
    item.classList.toggle('is-complete', number < step || step === 5);
  });
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (step === 2) elements.email.focus();
  if (step === 3) elements.password.focus();
}


function setFinalConfirmationProgress(active) {
  elements.progress.forEach((item) => {
    const number = Number(item.dataset.progress);
    if (active) {
      item.classList.toggle('is-active', number === 4);
      item.classList.toggle('is-complete', number < 4);
    } else {
      item.classList.toggle('is-active', number === state.step);
      item.classList.toggle('is-complete', number < state.step);
    }
  });
}

function setBusy(busy, button, busyText, normalText) {
  state.busy = busy;
  button.disabled = busy;
  button.textContent = busy ? busyText : normalText;
}

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 190;
}

async function postJson(url, body) {
  const response = await fetch(url, {
    method: 'POST',
    mode: 'cors',
    cache: 'no-store',
    credentials: 'omit',
    redirect: 'error',
    referrerPolicy: 'no-referrer',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  let payload = {};
  try {
    payload = await response.json();
  } catch (_) {
    payload = {};
  }

  if (!response.ok || payload.ok !== true) {
    const error = new Error(payload.error || 'request_failed');
    error.code = payload.error || 'request_failed';
    error.status = response.status;
    throw error;
  }
  return payload;
}

function friendlyError(error) {
  switch (error && error.code) {
    case 'invalid_credentials':
      return "We couldn't verify those account details. Check your email and password and try again.";
    case 'too_many_attempts':
      return 'Too many attempts. Please wait 15 minutes and try again.';
    case 'deletion_session_expired':
      return 'Your secure deletion session expired. Please verify your email and password again.';
    case 'origin_not_allowed':
      return 'This deletion request must be started from the official Wallfront account deletion page.';
    default:
      return 'The request could not be completed. Check your connection and try again.';
  }
}

async function verifyAccount() {
  if (state.busy) return;
  const password = elements.password.value;
  if (!password) {
    showMessage('Enter your account password.');
    elements.password.focus();
    return;
  }

  clearMessage();
  setBusy(true, elements.verify, 'Verifying…', 'Verify account');
  try {
    const payload = await postJson(`${API_BASE}/verify`, {
      email: state.email,
      password,
      requestId: createRequestId(),
    });
    state.deletionToken = payload.deletionToken;
    elements.password.value = '';
    elements.password.type = 'password';
    elements.togglePassword.textContent = 'Show';
    elements.togglePassword.setAttribute('aria-pressed', 'false');
    elements.dialog.hidden = false;
    setFinalConfirmationProgress(true);
    elements.confirmDelete.focus();
  } catch (error) {
    elements.password.value = '';
    showMessage(friendlyError(error));
    elements.password.focus();
  } finally {
    setBusy(false, elements.verify, 'Verifying…', 'Verify account');
  }
}

async function deleteAccount() {
  if (state.busy || !state.deletionToken) return;
  clearMessage();
  setBusy(true, elements.confirmDelete, 'Deleting…', 'Delete Account');
  elements.cancelDelete.disabled = true;
  try {
    const payload = await postJson(`${API_BASE}/confirm`, {
      deletionToken: state.deletionToken,
      confirmed: true,
      requestId: createRequestId(),
    });
    state.deletionToken = '';
    state.email = '';
    elements.email.value = '';
    elements.dialog.hidden = true;
    elements.reference.textContent = payload.deletionId ? `Deletion reference: ${payload.deletionId}` : '';
    setStep(5);
  } catch (error) {
    elements.dialog.hidden = true;
    if (error && error.code === 'deletion_session_expired') {
      state.deletionToken = '';
      setStep(3);
    }
    showMessage(friendlyError(error));
  } finally {
    setBusy(false, elements.confirmDelete, 'Deleting…', 'Delete Account');
    elements.cancelDelete.disabled = false;
  }
}

elements.warningConfirm.addEventListener('change', () => {
  elements.warningNext.disabled = !elements.warningConfirm.checked;
});

elements.warningNext.addEventListener('click', () => {
  if (elements.warningConfirm.checked) setStep(2);
});

elements.emailNext.addEventListener('click', () => {
  const email = elements.email.value.trim().toLowerCase();
  if (!validEmail(email)) {
    showMessage('Enter a valid email address.');
    elements.email.focus();
    return;
  }
  state.email = email;
  setStep(3);
});

elements.email.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') elements.emailNext.click();
});

elements.password.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') verifyAccount();
});

elements.togglePassword.addEventListener('click', () => {
  const showing = elements.password.type === 'text';
  elements.password.type = showing ? 'password' : 'text';
  elements.togglePassword.textContent = showing ? 'Show' : 'Hide';
  elements.togglePassword.setAttribute('aria-pressed', String(!showing));
  elements.togglePassword.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
});

elements.verify.addEventListener('click', verifyAccount);
elements.confirmDelete.addEventListener('click', deleteAccount);

elements.cancelDelete.addEventListener('click', () => {
  if (state.busy) return;
  elements.dialog.hidden = true;
  state.deletionToken = '';
  setFinalConfirmationProgress(false);
  elements.password.focus();
});

elements.dialog.addEventListener('click', (event) => {
  if (event.target === elements.dialog && !state.busy) elements.cancelDelete.click();
});

elements.backButtons.forEach((button) => {
  button.addEventListener('click', () => {
    if (state.busy) return;
    state.deletionToken = '';
    elements.password.value = '';
    setStep(Number(button.dataset.back));
  });
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !elements.dialog.hidden && !state.busy) elements.cancelDelete.click();
});

window.addEventListener('pagehide', () => {
  state.deletionToken = '';
  state.email = '';
  elements.password.value = '';
});
