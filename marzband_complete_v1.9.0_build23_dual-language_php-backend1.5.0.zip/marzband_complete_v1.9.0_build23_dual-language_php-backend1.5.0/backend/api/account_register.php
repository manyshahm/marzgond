<?php require_once __DIR__ . '/core.php';
$data=input_json();
$name=clean_string($data['name']??'',80);$email=normalize_email($data['email']??'');$password=(string)($data['password']??'');
$countryCode=strtoupper(clean_string($data['countryCode']??'IR',3))?:'IR';$deviceId=clean_string($data['deviceId']??'',120);
if(strlen($name)<2||strlen($name)>80)respond(['ok'=>false,'error'=>'invalid_name'],422);
if(!validate_email_value($email))respond(['ok'=>false,'error'=>'invalid_email'],422);
if(strlen($password)<8)respond(['ok'=>false,'error'=>'weak_password'],422);
if(strlen($deviceId)<12)respond(['ok'=>false,'error'=>'device_id_required'],422);
$result=state_tx(function(array &$state)use($name,$email,$password,$countryCode,$deviceId):array{
    if(isset($state['email_index'][$email]))return ['error'=>'email_already_registered','code'=>409];
    $now=now_ms();$accountId=random_id('a_');
    $account=array_replace(default_account_fields(),['id'=>$accountId,'name'=>$name,'email'=>$email,'email_lower'=>$email,'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'country_code'=>$countryCode,'created_at'=>$now,'last_login_at'=>$now,'last_seen_at'=>$now]);
    record_activity($account,'account_registered',['deviceId'=>$deviceId]);
    $state['accounts'][$accountId]=$account;$state['email_index'][$email]=$accountId;$token=create_player_session($state,$accountId);
    $profile=['device_id'=>$deviceId,'account_id'=>$accountId,'name'=>$name,'email'=>$email,'country_code'=>$countryCode,'avatar_key'=>'guest','cups'=>0,'registered'=>true,'registered_at'=>$now];upsert_user($state,$profile);
    return ['token'=>$token,'user'=>public_account($state['accounts'][$accountId])];
});
if(isset($result['error']))respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);respond(['ok'=>true]+$result,201);
