<?php require_once __DIR__ . '/core.php';
$data=input_json();
$result=state_tx(function(array &$state) use($data): array {
    $profile=profile_from_authenticated_input($state,$data);
    $user=upsert_user($state,$profile); $id=$profile['device_id']; $accountId=(string)$profile['account_id'];
    $active=(string)($state['accounts'][$accountId]['active_match_id']??$user['active_match_id']??'');
    if($active!==''&&isset($state['matches'][$active])&&($state['matches'][$active]['status']??'')==='active'){
        $m=$state['matches'][$active];
        if(role_for_match($m,$id)===null) return ['error'=>'account_already_in_match','code'=>409];
        return ['status'=>$m['mode']==='bot'?'bot':'matched','session'=>session_payload($state,$m,$id)];
    }
    $since=(int)($state['users'][$id]['queue_since']??0);
    if($since<=0) return ['status'=>'cancelled'];
    $waited=max(0,now_ms()-$since);
    if($waited>=MATCHMAKING_WAIT_MS){
        $matchId=create_bot_match($state,$id);
        return ['status'=>'bot','session'=>session_payload($state,$state['matches'][$matchId],$id),'waitedMs'=>$waited];
    }
    return ['status'=>'waiting','waitedMs'=>$waited];
});
if(isset($result['error'])) respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);
respond(['ok'=>true]+$result);
