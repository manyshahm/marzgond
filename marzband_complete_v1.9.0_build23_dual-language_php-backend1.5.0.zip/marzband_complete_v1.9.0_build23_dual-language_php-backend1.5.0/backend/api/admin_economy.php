<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';
require_admin();
$economy = state_tx(function(array &$state): array {
    $totalCoins = 0; $positive = 0; $negative = 0; $count = 0; $dailyReady = 0; $wheelReady = 0;
    foreach ($state['accounts'] as $account) {
        $totalCoins += max(0, (int)($account['coins'] ?? 0));
        if ((daily_status($account)['canClaim'] ?? false) === true) $dailyReady++;
        if ((wheel_status($account)['canSpin'] ?? false) === true) $wheelReady++;
        foreach (($account['transactions'] ?? []) as $tx) {
            if (!is_array($tx)) continue; $delta = (int)($tx['delta'] ?? 0); $count++;
            if ($delta >= 0) $positive += $delta; else $negative += abs($delta);
        }
    }
    return ['totalCoins'=>$totalCoins, 'totalPositive'=>$positive, 'totalNegative'=>$negative, 'transactionCount'=>$count, 'dailyReadyUsers'=>$dailyReady, 'wheelReadyUsers'=>$wheelReady];
});
respond(['ok'=>true, 'economy'=>$economy]);
