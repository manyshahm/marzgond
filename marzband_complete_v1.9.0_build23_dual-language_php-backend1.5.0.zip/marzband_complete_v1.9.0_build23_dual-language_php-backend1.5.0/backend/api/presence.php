<?php require_once __DIR__ . '/core.php';
$data=input_json();
$result=state_tx(function(array &$state) use($data): array {
    $profile=profile_from_authenticated_input($state,$data);
    $user=upsert_user($state,$profile);
    return ['cups'=>(int)$user['cups'],'user'=>public_account($state['accounts'][$profile['account_id']])];
});
respond(['ok'=>true]+$result);
