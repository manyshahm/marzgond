<?php require_once __DIR__ . '/core.php';
$data=input_json(); $email=normalize_email($data['email']??'');
if(!validate_email_value($email)) respond(['ok'=>false,'error'=>'invalid_email'],422);
$result=state_tx(function(array &$state) use($email): array {
    $accountId=(string)($state['email_index'][$email]??'');
    if($accountId===''||!isset($state['accounts'][$accountId])) return ['error'=>'account_not_found','code'=>404];
    $code=(string)random_int(100000,999999);
    $state['password_resets'][$email]=['code_hash'=>hash('sha256',$code),'expires_at'=>now_ms()+RESET_CODE_TTL_MS,'attempts'=>0];
    return ['recoveryCode'=>$code,'expiresInSeconds'=>(int)(RESET_CODE_TTL_MS/1000)];
});
if(isset($result['error'])) respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);
respond(['ok'=>true]+$result);
