<?php require_once __DIR__ . '/core.php'; require_admin();
$data=input_json();$accountId=clean_string($data['accountId']??'',100);$amount=(int)($data['amount']??0);$note=clean_string($data['note']??'Admin adjustment',200);$requestId=clean_string($data['requestId']??'',140)?:random_id('admin_');
if($amount===0)respond(['ok'=>false,'error'=>'invalid_amount'],422);
$result=state_tx(function(array &$state)use($accountId,$amount,$note,$requestId):array{
    $cached=idempotent_result($state,$requestId);if($cached!==null)return $cached;
    if(!isset($state['accounts'][$accountId]))return ['error'=>'account_not_found','code'=>404];
    if($amount<0&&(int)$state['accounts'][$accountId]['coins']<abs($amount))return ['error'=>'insufficient_balance','code'=>409];
    $tx=record_transaction($state['accounts'][$accountId],'admin_adjustment',$amount,$note,$requestId,['admin'=>ADMIN_USERNAME]);record_activity($state['accounts'][$accountId],'admin_coin_adjustment',['amount'=>$tx['delta'],'note'=>$note]);
    $result=['user'=>public_account($state['accounts'][$accountId]),'transaction'=>$tx];store_idempotent_result($state,$requestId,$result);return $result;
});if(isset($result['error']))respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);respond(['ok'=>true]+$result);
