<?php require_once __DIR__ . '/core.php';
$data=input_json();
state_tx(function(array &$state) use($data): void {
    $profile=profile_from_authenticated_input($state,$data);
    upsert_user($state,$profile);
    remove_from_queue($state,$profile['device_id']);
});
respond(['ok'=>true]);
