<?php require_once __DIR__ . '/core.php';
$data=input_json(); $requestId=clean_string($data['requestId']??'',120) ?: random_id('q_');
$result=state_tx(function(array &$state) use($data,$requestId): array {
    $profile=profile_from_authenticated_input($state,$data);
    $user=upsert_user($state,$profile); $id=$profile['device_id']; $accountId=(string)$profile['account_id'];
    $active=(string)($state['accounts'][$accountId]['active_match_id']??$user['active_match_id']??'');
    if($active!==''&&isset($state['matches'][$active])&&($state['matches'][$active]['status']??'')==='active'){
        $m=$state['matches'][$active];
        if(role_for_match($m,$id)===null) return ['error'=>'account_already_in_match','code'=>409];
        return ['status'=>$m['mode']==='bot'?'bot':'matched','session'=>session_payload($state,$m,$id)];
    }
    clear_active_match_for_device($state,$id);
    remove_account_from_queue($state,$accountId);
    $candidate=null;
    foreach($state['queue'] as $otherId){
        if($otherId===$id) continue;
        $other=$state['users'][$otherId]??null;
        if(!is_array($other)||!empty($other['active_match_id'])||($other['last_seen_at']??0)<now_ms()-20000) continue;
        if((string)($other['account_id']??'')===$accountId) continue;
        $candidate=$otherId; break;
    }
    if($candidate!==null){
        $matchId=create_real_match($state,$candidate,$id);
        return ['status'=>'matched','session'=>session_payload($state,$state['matches'][$matchId],$id)];
    }
    $state['users'][$id]['queue_since']=now_ms();
    $state['users'][$id]['queue_request_id']=$requestId;
    $state['accounts'][$accountId]['queue_device_id']=$id;
    $state['queue'][]=$id;
    return ['status'=>'waiting','waitedMs'=>0];
});
if(isset($result['error'])) respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);
respond(['ok'=>true]+$result);
