<?php require_once __DIR__ . '/core.php';
$data=input_json();
$result=state_tx(function(array &$state)use($data):array{
    $account=require_account_from_input($state,$data);$selected=clean_string($data['league']??league_key_for_cups((int)$account['cups']),20);
    if(!in_array($selected,['bronze','silver','gold','diamond','legend'],true))$selected=league_key_for_cups((int)$account['cups']);
    $all=[];foreach($state['accounts'] as $a)if(league_key_for_cups((int)$a['cups'])===$selected)$all[]=$a;
    usort($all,fn($a,$b)=>(int)$b['cups']<=>(int)$a['cups'] ?: strcmp((string)$a['name'],(string)$b['name']));
    $entries=[];$currentRank=null;foreach($all as $i=>$a){$rank=$i+1;if((string)$a['id']===(string)$account['id'])$currentRank=$rank;if($rank<=50)$entries[]=['rank'=>$rank,'name'=>$a['name'],'cups'=>(int)$a['cups'],'countryCode'=>$a['country_code'],'avatarKey'=>$a['avatar_key'],'isCurrentPlayer'=>(string)$a['id']===(string)$account['id']];}
    $archiveKeys=array_keys($state['season']['archives']);rsort($archiveKeys);$lastKey=$archiveKeys[0]??null;$last=$lastKey?($state['season']['archives'][$lastKey]??[]):[];
    return ['league'=>$selected,'entries'=>$entries,'currentRank'=>$currentRank,'currentUser'=>public_account($state['accounts'][(string)$account['id']]),'lastMonth'=>['season'=>$lastKey,'entries'=>$last]];
});respond(['ok'=>true]+$result);
