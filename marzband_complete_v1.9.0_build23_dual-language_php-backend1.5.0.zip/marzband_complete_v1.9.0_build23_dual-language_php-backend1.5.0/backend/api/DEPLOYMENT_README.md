# استقرار مرزبند روی cPanel

1. محتویات پوشه `api` را در `public_html/marzband/api` قرار دهید.
2. محتویات پوشه `admin-panel` را در `public_html/marzband/admin-panel` قرار دهید.
3. پوشه `api/storage` باید برای PHP قابل نوشتن باشد.
4. هنگام ارتقا، فایل موجود `api/storage/state.json` را حذف یا جایگزین نکنید؛ این فایل شامل حساب‌ها و پیشرفت کاربران است. بسته انتشار عمداً فایل state.json را شامل نمی‌شود.

تست سلامت:

`https://persian-melody.ir/marzband/api/health.php`

پنل:

`https://persian-melody.ir/marzband/admin-panel/`

## اجرای دقیق ریست ماهانه

در cPanel یک Cron Job برای روز اول هر ماه، ساعت 12:00 به وقت ایران تنظیم کنید و فایل زیر را با PHP CLI اجرا کنید:

`php /home/CPANEL_USER/public_html/marzband/api/season_maintenance.php`

علاوه بر Cron، تمام APIها هنگام اولین درخواست بعد از زمان مقرر نیز ریست انجام‌نشده را به‌صورت idempotent اجرا می‌کنند.
