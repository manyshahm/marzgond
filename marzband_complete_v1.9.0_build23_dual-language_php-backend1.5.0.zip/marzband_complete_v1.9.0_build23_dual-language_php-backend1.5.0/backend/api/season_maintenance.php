<?php
require_once __DIR__ . '/core.php';

// Designed for a cPanel cron job. Browser requests still require the admin token.
if (PHP_SAPI !== 'cli') {
    require_admin();
}

$result = state_tx(function (array &$state): array {
    ensure_monthly_season($state);
    $current = current_season_key();
    $previous = date('Y-m', strtotime('-1 month'));
    return [
        'currentSeason' => $current,
        'lastResetKey' => (string) ($state['season']['last_reset_key'] ?? ''),
        'previousMonthTopPlayers' => array_values($state['season']['archives'][$previous] ?? []),
    ];
});

respond(['ok' => true, 'version' => API_VERSION, 'season' => $result, 'time' => iso_time()]);
