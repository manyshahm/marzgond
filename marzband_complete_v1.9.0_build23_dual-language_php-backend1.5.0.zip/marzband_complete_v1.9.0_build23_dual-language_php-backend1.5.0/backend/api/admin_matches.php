<?php require_once __DIR__ . '/core.php'; require_admin();
$limit=max(1,min(100,(int)($_GET['limit']??50)));
$matches=state_tx(function(array &$state) use($limit): array {
    $items=array_values($state['matches']); usort($items,fn($a,$b)=>(int)($b['started_at']??0)<=>(int)($a['started_at']??0)); $items=array_slice($items,0,$limit); $out=[];
    foreach($items as $m){$blue=$state['users'][$m['blue_device_id']??'']['name']??($m['blue_name']??'—');$red=($m['mode']??'')==='bot'?'ربات':($state['users'][$m['red_device_id']??'']['name']??'—');$winner=$state['users'][$m['winner_device_id']??'']['name']??'';$out[]=['id'=>$m['id'],'mode'=>$m['mode'],'status'=>$m['status'],'finish_reason'=>$m['finish_reason']??null,'moves_count'=>(int)($m['moves_count']??0),'started_at'=>iso_time((int)$m['started_at']),'ended_at'=>empty($m['ended_at'])?null:iso_time((int)$m['ended_at']),'duration_seconds'=>(int)($m['duration_seconds']??0),'blue_name'=>$blue,'red_name'=>$red,'winner_name'=>$winner];}
    return $out;
});
respond(['ok'=>true,'matches'=>$matches]);
