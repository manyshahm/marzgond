<?php require_once __DIR__ . '/core.php';
$data=input_json();$email=normalize_email($data['email']??'');$password=(string)($data['password']??'');$deviceId=clean_string($data['deviceId']??'',120);
if(!validate_email_value($email)||$password==='')respond(['ok'=>false,'error'=>'invalid_credentials'],401);
if(strlen($deviceId)<12)respond(['ok'=>false,'error'=>'device_id_required'],422);
$result=state_tx(function(array &$state)use($email,$password,$deviceId):array{
    $accountId=(string)($state['email_index'][$email]??'');$account=$accountId!==''?($state['accounts'][$accountId]??null):null;
    if(!is_array($account)||!password_verify($password,(string)($account['password_hash']??'')))return ['error'=>'invalid_credentials','code'=>401];
    $now=now_ms();$state['accounts'][$accountId]['last_login_at']=$now;$state['accounts'][$accountId]['last_seen_at']=$now;record_activity($state['accounts'][$accountId],'account_login',['deviceId'=>$deviceId]);
    $token=create_player_session($state,$accountId);$profile=['device_id'=>$deviceId,'account_id'=>$accountId,'name'=>$account['name'],'email'=>$account['email'],'country_code'=>$account['country_code'],'avatar_key'=>$account['avatar_key'],'cups'=>(int)$account['cups'],'registered'=>true,'registered_at'=>(int)$account['created_at']];upsert_user($state,$profile);
    return ['token'=>$token,'user'=>public_account($state['accounts'][$accountId])];
});
if(isset($result['error']))respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);respond(['ok'=>true]+$result);
