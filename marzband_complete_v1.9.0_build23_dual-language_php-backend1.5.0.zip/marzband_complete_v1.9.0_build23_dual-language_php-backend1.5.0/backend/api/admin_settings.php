<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';
require_admin();
$settings = state_tx(function(array &$state): array {
    return [
        'apiVersion'=>API_VERSION, 'timezone'=>date_default_timezone_get(), 'currentSeason'=>current_season_key(),
        'lastResetKey'=>(string)($state['season']['last_reset_key'] ?? ''),
        'archiveCount'=>count($state['season']['archives'] ?? []), 'accountCount'=>count($state['accounts'] ?? []),
        'serverTime'=>iso_time(), 'stateVersion'=>(int)($state['version'] ?? 0),
    ];
});
respond(['ok'=>true, 'settings'=>$settings]);
