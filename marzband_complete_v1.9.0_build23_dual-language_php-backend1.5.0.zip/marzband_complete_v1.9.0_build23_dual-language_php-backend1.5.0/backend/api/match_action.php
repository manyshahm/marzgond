<?php require_once __DIR__ . '/core.php';
$data=input_json(); $matchId=clean_string($data['matchId']??'',100); $requestId=clean_string($data['requestId']??'',120); $action=is_array($data['action']??null)?$data['action']:[];
$result=state_tx(function(array &$state) use($data,$matchId,$requestId,$action): array {
    $profile=profile_from_authenticated_input($state,$data); upsert_user($state,$profile); $id=$profile['device_id'];
    if(!isset($state['matches'][$matchId])) return ['error'=>'match_not_found','code'=>404];
    $match=&$state['matches'][$matchId]; $role=role_for_match($match,$id);
    if($role===null||$match['mode']!=='real') return ['error'=>'match_access_denied','code'=>403];
    tick_match($state,$match);
    if($match['status']!=='active') return ['status'=>'finished','finished'=>finished_payload($match,$role)];
    if($requestId!==''&&isset($match['processed_requests'][$requestId])) return ['status'=>'active','matchId'=>$matchId,'state'=>perspective_snapshot($match['engine'],$role),'turnEndsAt'=>$match['turn_ends_at'],'opponentConnected'=>true,'revision'=>$match['revision']];
    if($match['engine']['turn']!==$role) return ['error'=>'not_your_turn','code'=>409,'state'=>perspective_snapshot($match['engine'],$role)];
    $actual=action_from_perspective($action,$role); $applied=false;
    if(($actual['type']??'')==='move'){$d=$actual['destination']??[];$applied=engine_move($match['engine'],['row'=>(int)($d['row']??-1),'col'=>(int)($d['col']??-1)]);}
    elseif(($actual['type']??'')==='wall'){$applied=engine_wall($match['engine'],(int)($actual['row']??-1),(int)($actual['col']??-1),($actual['orientation']??'horizontal')==='vertical'?'vertical':'horizontal');}
    if(!$applied) return ['error'=>'invalid_action','code'=>422,'state'=>perspective_snapshot($match['engine'],$role)];
    if($requestId!==''){$match['processed_requests'][$requestId]=now_ms();if(count($match['processed_requests'])>60)$match['processed_requests']=array_slice($match['processed_requests'],-40,null,true);}
    $match['moves_count']=count($match['engine']['history']);$match['last_activity_at']=now_ms();$match['revision']++;
    if($match['engine']['winner']!==null){finish_real_match($state,$match,$match['engine']['winner'],'goal');return ['status'=>'finished','finished'=>finished_payload($match,$role)];}
    $match['turn_ends_at']=now_ms()+TURN_DURATION_MS;
    return ['status'=>'active','matchId'=>$matchId,'state'=>perspective_snapshot($match['engine'],$role),'turnEndsAt'=>$match['turn_ends_at'],'opponentConnected'=>true,'revision'=>$match['revision']];
});
if(isset($result['error'])) respond(['ok'=>false,'error'=>$result['error'],'state'=>$result['state']??null],(int)$result['code']);
respond(['ok'=>true]+$result);
