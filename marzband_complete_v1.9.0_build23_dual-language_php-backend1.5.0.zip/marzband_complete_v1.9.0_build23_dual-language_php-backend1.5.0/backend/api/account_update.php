<?php require_once __DIR__ . '/core.php';
$data=input_json();
$result=state_tx(function(array &$state)use($data):array{
    $account=require_account_from_input($state,$data);$id=(string)$account['id'];
    if(array_key_exists('countryCode',$data))$state['accounts'][$id]['country_code']=strtoupper(clean_string($data['countryCode'],3))?:$state['accounts'][$id]['country_code'];
    if(array_key_exists('name',$data)){ $name=clean_string($data['name'],80); if(strlen($name)>=2)$state['accounts'][$id]['name']=$name; }
    $state['accounts'][$id]['last_seen_at']=now_ms();record_activity($state['accounts'][$id],'profile_updated',[]);
    foreach($state['users'] as $deviceId=>$user)if((string)($user['account_id']??'')===$id){$state['users'][$deviceId]['country_code']=$state['accounts'][$id]['country_code'];$state['users'][$deviceId]['name']=$state['accounts'][$id]['name'];}
    return ['user'=>public_account($state['accounts'][$id])];
});respond(['ok'=>true]+$result);
