<?php require_once __DIR__ . '/core.php';
$data=input_json(); $matchId=clean_string($data['matchId']??'',100); $reason=clean_string($data['reason']??'left',40);
$result=state_tx(function(array &$state) use($data,$matchId,$reason): array {
    $profile=profile_from_authenticated_input($state,$data); upsert_user($state,$profile); $id=$profile['device_id'];
    if(!isset($state['matches'][$matchId])) return ['ok'=>true]; $match=&$state['matches'][$matchId]; $role=role_for_match($match,$id);
    if($role===null) return ['ok'=>true];
    if($match['mode']==='bot'){
        if($match['status']==='active'){$match['status']='cancelled';$match['finish_reason']=$reason;$match['ended_at']=now_ms();}
        clear_active_match_for_device($state,$id,$matchId); return ['ok'=>true];
    }
    if($match['status']==='active') finish_real_match($state,$match,other_role($role),$reason);
    return ['ok'=>true,'finished'=>finished_payload($match,$role)];
});
respond($result);
