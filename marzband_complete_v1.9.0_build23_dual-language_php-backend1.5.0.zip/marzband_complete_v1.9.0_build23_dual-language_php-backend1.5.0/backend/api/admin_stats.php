<?php require_once __DIR__ . '/core.php'; require_admin();
$stats=state_tx(function(array &$state): array {
    $now=now_ms();$today=strtotime('today')*1000;$yesterday=$today-86400000;$week=$now-7*86400000;$month=$now-30*86400000;
    $s=['total_users'=>count($state['accounts']),'online_now'=>0,'active_today'=>0,'active_yesterday'=>0,'active_week'=>0,'active_month'=>0,'registrations_today'=>0,'registrations_yesterday'=>0,'registrations_week'=>0,'registrations_month'=>0,'matches_total'=>0,'matches_real'=>0,'matches_bot'=>0,'matches_active'=>0];
    foreach($state['accounts'] as $a){$last=(int)($a['last_seen_at']??0);$reg=(int)($a['created_at']??0);if($last>=$now-ONLINE_WINDOW_MS)$s['online_now']++;if($last>=$today)$s['active_today']++;if($last>=$yesterday&&$last<$today)$s['active_yesterday']++;if($last>=$week)$s['active_week']++;if($last>=$month)$s['active_month']++;if($reg>0){if($reg>=$today)$s['registrations_today']++;if($reg>=$yesterday&&$reg<$today)$s['registrations_yesterday']++;if($reg>=$week)$s['registrations_week']++;if($reg>=$month)$s['registrations_month']++;}}
    foreach($state['matches'] as $m){if(($m['status']??'')==='active')$s['matches_active']++;if(($m['status']??'')==='finished'){$s['matches_total']++;$s[($m['mode']??'')==='real'?'matches_real':'matches_bot']++;}}
    return $s;
});
respond(['ok'=>true,'stats'=>$stats,'generatedAt'=>iso_time()]);
