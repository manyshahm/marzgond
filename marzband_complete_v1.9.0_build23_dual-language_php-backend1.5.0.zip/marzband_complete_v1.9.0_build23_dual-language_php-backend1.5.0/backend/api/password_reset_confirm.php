<?php require_once __DIR__ . '/core.php';
$data=input_json(); $email=normalize_email($data['email']??''); $code=clean_string($data['code']??'',12); $password=(string)($data['newPassword']??'');
if(!validate_email_value($email)||strlen($code)!==6) respond(['ok'=>false,'error'=>'invalid_recovery_code'],422);
if(strlen($password)<8) respond(['ok'=>false,'error'=>'weak_password'],422);
$result=state_tx(function(array &$state) use($email,$code,$password): array {
    $reset=$state['password_resets'][$email]??null;
    if(!is_array($reset)||(int)($reset['expires_at']??0)<now_ms()||!hash_equals((string)($reset['code_hash']??''),hash('sha256',$code))) return ['error'=>'invalid_recovery_code','code'=>422];
    $accountId=(string)($state['email_index'][$email]??'');
    if($accountId===''||!isset($state['accounts'][$accountId])) return ['error'=>'account_not_found','code'=>404];
    $state['accounts'][$accountId]['password_hash']=password_hash($password,PASSWORD_DEFAULT);
    unset($state['password_resets'][$email]);
    foreach($state['sessions'] as $hash=>$session) if(($session['account_id']??'')===$accountId) unset($state['sessions'][$hash]);
    return ['updated'=>true];
});
if(isset($result['error'])) respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);
respond(['ok'=>true]+$result);
