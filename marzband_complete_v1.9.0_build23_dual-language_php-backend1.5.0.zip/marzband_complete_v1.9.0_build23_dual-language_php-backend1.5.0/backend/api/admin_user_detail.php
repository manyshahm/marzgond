<?php require_once __DIR__ . '/core.php'; require_admin();
$id=clean_string($_GET['id']??'',100);
$result=state_tx(function(array &$state)use($id):array{
    if($id===''||!isset($state['accounts'][$id]))return ['error'=>'account_not_found','code'=>404];$a=$state['accounts'][$id];$now=now_ms();
    return ['user'=>public_account($a)+['online'=>(int)($a['last_seen_at']??0)>=$now-ONLINE_WINDOW_MS,'transactions'=>array_reverse(array_slice($a['transactions']??[],-100)),'activities'=>array_reverse(array_slice($a['activity_log']??[],-100)),'matchHistory'=>array_reverse(array_slice($a['match_history']??[],-50))]];
});if(isset($result['error']))respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);respond(['ok'=>true]+$result);
