<?php require_once __DIR__ . '/core.php';
$data=input_json(); $matchId=clean_string($data['matchId']??'',100); $reactionSeq=max(0,(int)($data['reactionSeq']??0));
$result=state_tx(function(array &$state) use($data,$matchId,$reactionSeq): array {
    $profile=profile_from_authenticated_input($state,$data); upsert_user($state,$profile); $id=$profile['device_id'];
    if(!isset($state['matches'][$matchId])) return ['error'=>'match_not_found','code'=>404];
    $match=&$state['matches'][$matchId]; $role=role_for_match($match,$id);
    if($role===null||$match['mode']!=='real') return ['error'=>'match_access_denied','code'=>403];
    tick_match($state,$match);
    if($match['status']!=='active') return ['status'=>'finished','finished'=>finished_payload($match,$role)];
    $oppId=opponent_device($match,$role); $opp=$state['users'][$oppId]??[];
    $oppConnected=(int)($opp['last_seen_at']??0)>=now_ms()-DISCONNECT_GRACE_MS;
    if(!$oppConnected){ finish_real_match($state,$match,$role,'disconnect_timeout'); return ['status'=>'finished','finished'=>finished_payload($match,$role)]; }
    $oppRole=other_role($role); $reaction=$match['reactions'][$oppRole]??['seq'=>0,'value'=>''];
    return ['status'=>'active','matchId'=>$matchId,'state'=>perspective_snapshot($match['engine'],$role),'turnEndsAt'=>(int)$match['turn_ends_at'],'opponentConnected'=>$oppConnected,'revision'=>(int)$match['revision'],'reaction'=>((int)$reaction['seq']>$reactionSeq)?$reaction:null];
});
if(isset($result['error'])) respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);
respond(['ok'=>true]+$result);
