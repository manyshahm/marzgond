<?php require_once __DIR__ . '/core.php';
$data=input_json();$action=clean_string($data['action']??'',50);$requestId=clean_string($data['requestId']??'',140)?:random_id('req_');
$result=state_tx(function(array &$state)use($data,$action,$requestId):array{
    $cached=idempotent_result($state,$requestId);if($cached!==null)return $cached;
    $account=require_account_from_input($state,$data);$id=(string)$account['id'];$result=[];
    switch($action){
        case 'claim_daily':
            $status=daily_status($state['accounts'][$id]);if(!$status['canClaim'])return ['error'=>'daily_already_claimed','code'=>409];
            $state['accounts'][$id]['daily_streak']=$status['day'];$state['accounts'][$id]['last_daily_claim_at']=now_ms();
            $tx=record_transaction($state['accounts'][$id],'daily_reward',(int)$status['rewardCoins'],'Daily login reward',$requestId,['day'=>$status['day']]);$result=['rewardCoins'=>$tx['delta']];break;
        case 'spin_wheel':
            $status=wheel_status($state['accounts'][$id]);if(!$status['canSpin'])return ['error'=>'wheel_cooldown','code'=>409,'wheel'=>$status];
            $prize=WHEEL_PRIZES[array_rand(WHEEL_PRIZES)];$state['accounts'][$id]['last_wheel_spin_at']=now_ms();$state['accounts'][$id]['pending_wheel_prize']=0;
            $tx=record_transaction($state['accounts'][$id],'wheel_reward',$prize,'Daily fortune wheel',$requestId);$result=['prize'=>$tx['delta']];break;
        case 'reward_ad':
            $tx=record_transaction($state['accounts'][$id],'rewarded_ad',20,'Completed rewarded video',$requestId);$result=['rewardCoins'=>$tx['delta']];break;
        case 'double_match_reward':
            $matchId=clean_string($data['matchId']??'',140);if($matchId==='')return ['error'=>'match_id_required','code'=>422];
            $historyIndex=null;
            foreach(($state['accounts'][$id]['match_history']??[]) as $index=>$entry){if(is_array($entry)&&($entry['matchId']??'')===$matchId){$historyIndex=$index;break;}}
            if($historyIndex===null)return ['error'=>'match_not_found','code'=>404];
            $entry=$state['accounts'][$id]['match_history'][$historyIndex];
            if(($entry['won']??false)!==true||(int)($entry['coinDelta']??0)<=0)return ['error'=>'reward_not_eligible','code'=>409];
            if(($entry['rewardDoubled']??false)===true)return ['error'=>'reward_already_doubled','code'=>409,'rewardCoins'=>(int)($entry['doubleRewardCoins']??0)];
            $extra=(int)$entry['coinDelta'];
            $uniqueRequest='double-'.$matchId.'-'.$id;
            $tx=record_transaction($state['accounts'][$id],'match_double_reward',$extra,'Rewarded video double win reward',$uniqueRequest,['matchId'=>$matchId,'league'=>$entry['league']??league_name_for_cups((int)($entry['cupBefore']??0)),'mode'=>$entry['mode']??'bot']);
            $state['accounts'][$id]['match_history'][$historyIndex]['rewardDoubled']=true;
            $state['accounts'][$id]['match_history'][$historyIndex]['doubleRewardCoins']=$tx['delta'];
            $state['accounts'][$id]['match_history'][$historyIndex]['rewardDoubledAt']=iso_time();
            if(isset($state['matches'][$matchId])&&is_array($state['matches'][$matchId])){$state['matches'][$matchId]['double_rewards'][$id]=['coins'=>$tx['delta'],'created_at'=>now_ms()];}
            record_activity($state['accounts'][$id],'match_reward_doubled',['matchId'=>$matchId,'coins'=>$tx['delta']]);
            $result=['rewardCoins'=>$tx['delta'],'matchId'=>$matchId,'rewardDoubled'=>true];break;
        case 'buy_avatar':
            $key=clean_string($data['itemKey']??'',40);if(!array_key_exists($key,AVATAR_PRICES))return ['error'=>'invalid_item','code'=>422];
            if(!in_array($key,$state['accounts'][$id]['owned_avatars'],true)){$price=AVATAR_PRICES[$key];if((int)$state['accounts'][$id]['coins']<$price)return ['error'=>'not_enough_coins','code'=>409];record_transaction($state['accounts'][$id],'avatar_purchase',-$price,'Avatar purchase',$requestId,['itemKey'=>$key]);$state['accounts'][$id]['owned_avatars'][]=$key;}
            $state['accounts'][$id]['avatar_key']=$key;record_activity($state['accounts'][$id],'avatar_selected',['itemKey'=>$key]);$result=['itemKey'=>$key];break;
        case 'select_avatar':
            $key=clean_string($data['itemKey']??'',40);if(!in_array($key,$state['accounts'][$id]['owned_avatars'],true))return ['error'=>'item_not_owned','code'=>409];$state['accounts'][$id]['avatar_key']=$key;record_activity($state['accounts'][$id],'avatar_selected',['itemKey'=>$key]);$result=['itemKey'=>$key];break;
        case 'buy_wall':
            $key=clean_string($data['itemKey']??'',40);if(!array_key_exists($key,WALL_PRICES))return ['error'=>'invalid_item','code'=>422];
            if(!in_array($key,$state['accounts'][$id]['owned_walls'],true)){$price=WALL_PRICES[$key];if((int)$state['accounts'][$id]['coins']<$price)return ['error'=>'not_enough_coins','code'=>409];record_transaction($state['accounts'][$id],'wall_purchase',-$price,'Wall skin purchase',$requestId,['itemKey'=>$key]);$state['accounts'][$id]['owned_walls'][]=$key;}
            $state['accounts'][$id]['wall_skin_key']=$key;record_activity($state['accounts'][$id],'wall_selected',['itemKey'=>$key]);$result=['itemKey'=>$key];break;
        case 'select_wall':
            $key=clean_string($data['itemKey']??'',40);if(!in_array($key,$state['accounts'][$id]['owned_walls'],true))return ['error'=>'item_not_owned','code'=>409];$state['accounts'][$id]['wall_skin_key']=$key;record_activity($state['accounts'][$id],'wall_selected',['itemKey'=>$key]);$result=['itemKey'=>$key];break;
        default:return ['error'=>'invalid_action','code'=>422];
    }
    $result=['user'=>public_account($state['accounts'][$id])]+$result;store_idempotent_result($state,$requestId,$result);return $result;
});
if(isset($result['error']))respond(['ok'=>false]+$result,(int)($result['code']??400));respond(['ok'=>true]+$result);
