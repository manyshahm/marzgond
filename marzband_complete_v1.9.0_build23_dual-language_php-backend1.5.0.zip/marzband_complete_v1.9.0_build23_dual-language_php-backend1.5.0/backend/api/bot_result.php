<?php require_once __DIR__ . '/core.php';
$data=input_json();$matchId=clean_string($data['matchId']??'',100);$won=!empty($data['won']);$moves=max(0,min(1000,(int)($data['movesCount']??0)));$reason=clean_string($data['reason']??'completed',40);
$result=state_tx(function(array &$state)use($data,$matchId,$won,$moves,$reason):array{
    $profile=profile_from_authenticated_input($state,$data);$user=upsert_user($state,$profile);$id=$profile['device_id'];
    if(!isset($state['matches'][$matchId]))return ['error'=>'match_not_found','code'=>404];$match=&$state['matches'][$matchId];
    if($match['mode']!=='bot'||$match['blue_device_id']!==$id)return ['error'=>'match_access_denied','code'=>403];
    if($match['status']==='finished'&&isset($match['bot_result']))return $match['bot_result'];
    $before=(int)($match['blue_start_cups']??$user['cups']);$delta=league_cup_delta($before,$won);$after=max(0,$before+$delta);$now=now_ms();$duration=max(0,(int)floor(($now-(int)$match['started_at'])/1000));
    $accountResult=apply_match_result_to_account($state,$id,$won,$before,$after,$delta,'bot',$matchId,(string)($match['opponent']['name']??'Bot'),$duration,$moves);
    $match['status']='finished';$match['winner_device_id']=$won?$id:null;$match['finish_reason']=$reason;$match['moves_count']=$moves;$match['ended_at']=$now;$match['duration_seconds']=$duration;
    $result=['matchId'=>$matchId,'state'=>null,'won'=>$won,'finishReason'=>$reason,'durationSeconds'=>$duration]+$accountResult;$match['bot_result']=$result;return $result;
});
if(isset($result['error']))respond(['ok'=>false,'error'=>$result['error']],(int)$result['code']);respond(['ok'=>true,'result'=>$result]);
