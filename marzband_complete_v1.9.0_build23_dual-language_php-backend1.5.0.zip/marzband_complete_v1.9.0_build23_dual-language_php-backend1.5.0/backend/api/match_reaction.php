<?php require_once __DIR__ . '/core.php';
$data=input_json(); $matchId=clean_string($data['matchId']??'',100); $reaction=clean_string($data['reaction']??'',20);
state_tx(function(array &$state) use($data,$matchId,$reaction): void {
    $profile=profile_from_authenticated_input($state,$data); upsert_user($state,$profile); $id=$profile['device_id'];
    if(!isset($state['matches'][$matchId])) return; $match=&$state['matches'][$matchId]; $role=role_for_match($match,$id);
    if($role===null||$match['mode']!=='real'||$match['status']!=='active'||$reaction==='') return;
    $seq=(int)($match['reactions'][$role]['seq']??0)+1; $match['reactions'][$role]=['seq'=>$seq,'value'=>$reaction]; $match['last_activity_at']=now_ms();
});
respond(['ok'=>true]);
