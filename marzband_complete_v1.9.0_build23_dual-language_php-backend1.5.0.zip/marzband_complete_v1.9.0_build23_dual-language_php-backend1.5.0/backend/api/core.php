<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Tehran');
ini_set('display_errors', '0');
error_reporting(0);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') exit;

const API_VERSION = '1.5.0';
const MATCHMAKING_WAIT_MS = 5000;
const TURN_DURATION_MS = 30000;
const ONLINE_WINDOW_MS = 12000;
const DISCONNECT_GRACE_MS = 30000;
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'M@ny0098';
const ADMIN_SECRET = 'marzband-php-build15-persistent-admin-token';
const STATE_FILE = __DIR__ . '/storage/state.json';
const RESET_CODE_TTL_MS = 15 * 60 * 1000;
const WHEEL_COOLDOWN_MS = 24 * 60 * 60 * 1000;

const AVATAR_PRICES = [
    'guest'=>0,'rookieBoy'=>1000,'rookieGirl'=>1500,'strategist'=>2500,'explorer'=>3500,
    'cyberSoldier'=>5000,'cyberGuardian'=>7000,'stormHero'=>9000,'warriorQueen'=>11000,
    'fireSage'=>13000,'arcaneQueen'=>15000,
];
const WALL_PRICES = ['classic'=>0,'ocean'=>500,'flame'=>800,'gold'=>1250,'cyber'=>1750,'emerald'=>2200,'frost'=>2600,'rose'=>3000,'shadow'=>3500,'plasma'=>4200,'crystal'=>5000,'silver'=>6000];
const WHEEL_PRIZES = [10,20,30,40,50,75,100,150];

function now_ms(): int { return (int) floor(microtime(true) * 1000); }
function iso_time(?int $ms = null): string {
    $ms ??= now_ms();
    return date('c', (int) floor($ms / 1000));
}
function respond(array $payload, int $status = 200): void {
    http_response_code($status);
    if (!array_key_exists('serverTimeMillis', $payload)) $payload['serverTimeMillis'] = now_ms();
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function input_json(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    return is_array($data) ? $data : [];
}
function clean_string(mixed $value, int $max = 255): string {
    $value = trim((string) $value);
    return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : substr($value, 0, $max);
}
function normalize_email(mixed $value): string { return strtolower(clean_string($value, 190)); }
function random_id(string $prefix = ''): string { return $prefix . bin2hex(random_bytes(16)); }
function random_token(int $bytes = 32): string { return bin2hex(random_bytes($bytes)); }
function token_hash(string $token): string { return hash('sha256', $token); }
function admin_token(): string { return hash_hmac('sha256', ADMIN_USERNAME . '|' . ADMIN_PASSWORD, ADMIN_SECRET); }
function bearer_token(): string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $header, $m)) return trim($m[1]);
    return '';
}
function require_admin(): void {
    if (!hash_equals(admin_token(), bearer_token())) respond(['ok'=>false,'error'=>'Unauthorized'], 401);
}
function validate_email_value(string $email): bool { return $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false; }
function current_day_key(): string { return date('Y-m-d'); }
function yesterday_day_key(): string { return date('Y-m-d', strtotime('-1 day')); }
function current_season_key(): string { return date('Y-m'); }
function league_key_for_cups(int $cups): string {
    if ($cups >= 4000) return 'legend';
    if ($cups >= 2500) return 'diamond';
    if ($cups >= 1500) return 'gold';
    if ($cups >= 500) return 'silver';
    return 'bronze';
}
function league_name_for_cups(int $cups): string { return ucfirst(league_key_for_cups($cups)); }
function league_cup_delta(int $cups, bool $won): int {
    return match (league_key_for_cups($cups)) {
        'bronze' => $won ? 30 : -20,
        'silver' => $won ? 27 : -23,
        'gold' => $won ? 25 : -25,
        'diamond' => $won ? 22 : -28,
        default => $won ? 20 : -30,
    };
}
function league_win_coins(int $cups): int {
    return match (league_key_for_cups($cups)) {
        'bronze' => 10,
        'silver' => 20,
        'gold' => 30,
        'diamond' => 40,
        default => 50,
    };
}
function default_account_fields(): array {
    return [
        'cups'=>0,'coins'=>200,'avatar_key'=>'guest','wall_skin_key'=>'classic',
        'owned_avatars'=>['guest'],'owned_walls'=>['classic'],
        'daily_streak'=>0,'last_daily_claim_at'=>null,
        'last_wheel_spin_at'=>null,'pending_wheel_prize'=>0,
        'wins'=>0,'losses'=>0,'matches_played'=>0,'real_matches'=>0,'bot_matches'=>0,
        'transactions'=>[],'activity_log'=>[],'match_history'=>[],'settings'=>[],
        'active_match_id'=>null,'queue_device_id'=>null,'processed_requests'=>[],
    ];
}
function default_state(): array {
    return [
        'version'=>3,'accounts'=>[],'email_index'=>[],'sessions'=>[],'password_resets'=>[],
        'users'=>[],'queue'=>[],'matches'=>[],'idempotency'=>[],
        'season'=>['last_reset_key'=>current_season_key(),'archives'=>[]],
    ];
}
function normalize_string_list(mixed $value, array $fallback): array {
    if (!is_array($value)) return $fallback;
    $out=[];
    foreach ($value as $item) { $v=clean_string($item,40); if ($v!=='' && !in_array($v,$out,true)) $out[]=$v; }
    return $out ?: $fallback;
}
function normalize_account(array $account, string $id): array {
    $account = array_replace(default_account_fields(), $account);
    $account['id'] = (string) ($account['id'] ?? $id);
    $account['email_lower'] = normalize_email($account['email_lower'] ?? $account['email'] ?? '');
    $account['cups'] = max(0, (int) $account['cups']);
    $account['coins'] = max(0, (int) $account['coins']);
    $account['avatar_key'] = array_key_exists((string)$account['avatar_key'], AVATAR_PRICES) ? (string)$account['avatar_key'] : 'guest';
    $account['wall_skin_key'] = array_key_exists((string)$account['wall_skin_key'], WALL_PRICES) ? (string)$account['wall_skin_key'] : 'classic';
    $account['owned_avatars'] = normalize_string_list($account['owned_avatars'], ['guest']);
    $account['owned_walls'] = normalize_string_list($account['owned_walls'], ['classic']);
    if (!in_array('guest',$account['owned_avatars'],true)) $account['owned_avatars'][]='guest';
    if (!in_array('classic',$account['owned_walls'],true)) $account['owned_walls'][]='classic';
    if (!in_array($account['avatar_key'],$account['owned_avatars'],true)) $account['avatar_key']='guest';
    if (!in_array($account['wall_skin_key'],$account['owned_walls'],true)) $account['wall_skin_key']='classic';
    foreach (['wins','losses','matches_played','real_matches','bot_matches','daily_streak','pending_wheel_prize'] as $key) $account[$key]=max(0,(int)$account[$key]);
    foreach (['transactions','activity_log','match_history','settings','processed_requests'] as $key) if (!is_array($account[$key])) $account[$key]=[];
    return $account;
}
function normalize_state(array $state): array {
    $defaults=default_state();
    foreach ($defaults as $key=>$value) if (!isset($state[$key]) || !is_array($state[$key])) $state[$key]=$value;
    $state['version']=3;
    $state['email_index']=[];
    foreach ($state['accounts'] as $id=>$account) {
        if (!is_array($account)) { unset($state['accounts'][$id]); continue; }
        $state['accounts'][$id]=normalize_account($account,(string)$id);
        $email=$state['accounts'][$id]['email_lower'];
        if ($email!=='') $state['email_index'][$email]=(string)$id;
    }
    if (!isset($state['season']['last_reset_key'])) $state['season']['last_reset_key']=current_season_key();
    if (!isset($state['season']['archives']) || !is_array($state['season']['archives'])) $state['season']['archives']=[];
    return $state;
}
function append_limited(array &$list, array $item, int $limit = 1000): void {
    $list[]=$item;
    if (count($list)>$limit) $list=array_slice($list,-$limit);
}
function record_activity(array &$account, string $type, array $data=[]): void {
    append_limited($account['activity_log'], ['id'=>random_id('act_'),'type'=>$type,'data'=>$data,'created_at'=>now_ms()], 1000);
}
function record_transaction(array &$account, string $type, int $delta, string $reason, string $requestId, array $meta=[]): array {
    $before=max(0,(int)$account['coins']);
    $after=max(0,$before+$delta);
    $actual=$after-$before;
    $account['coins']=$after;
    $tx=['id'=>random_id('tx_'),'request_id'=>$requestId,'type'=>$type,'reason'=>$reason,'delta'=>$actual,'before'=>$before,'after'=>$after,'meta'=>$meta,'created_at'=>now_ms()];
    append_limited($account['transactions'],$tx,2000);
    record_activity($account,'coin_transaction',$tx);
    return $tx;
}
function idempotent_result(array &$state, string $requestId): ?array {
    if ($requestId==='' || !isset($state['idempotency'][$requestId]) || !is_array($state['idempotency'][$requestId])) return null;
    return $state['idempotency'][$requestId]['result'] ?? null;
}
function store_idempotent_result(array &$state, string $requestId, array $result): void {
    if ($requestId==='') return;
    $state['idempotency'][$requestId]=['created_at'=>now_ms(),'result'=>$result];
    if (count($state['idempotency'])>5000) {
        uasort($state['idempotency'],fn($a,$b)=>(int)($a['created_at']??0)<=>(int)($b['created_at']??0));
        $state['idempotency']=array_slice($state['idempotency'],-4000,null,true);
    }
}
function daily_status(array $account): array {
    $last=(int)($account['last_daily_claim_at']??0);
    $lastKey=$last>0?date('Y-m-d',(int)floor($last/1000)):'';
    $can=$lastKey!==current_day_key();
    $streak=max(0,(int)($account['daily_streak']??0));
    $day=$can ? ($lastKey===yesterday_day_key()?min(10,$streak+1):1) : max(1,min(10,$streak));
    return ['canClaim'=>$can,'day'=>$day,'rewardCoins'=>min(100,$day*10),'streak'=>$streak,'lastClaimAt'=>$last>0?iso_time($last):null];
}
function wheel_status(array $account): array {
    $last=(int)($account['last_wheel_spin_at']??0);
    $next=$last>0?$last+WHEEL_COOLDOWN_MS:0;
    $can=$last<=0 || now_ms()>=$next;
    return ['canSpin'=>$can,'lastSpinAt'=>$last>0?iso_time($last):null,'nextSpinAt'=>$can?null:iso_time($next),'remainingMs'=>$can?0:max(0,$next-now_ms()),'pendingPrize'=>(int)($account['pending_wheel_prize']??0)];
}
function public_account(array $account): array {
    return [
        'id'=>(string)($account['id']??''),'name'=>(string)($account['name']??'بازیکن مهمان'),'email'=>(string)($account['email']??''),
        'countryCode'=>(string)($account['country_code']??'IR'),'cups'=>(int)($account['cups']??0),'coins'=>(int)($account['coins']??0),
        'league'=>league_name_for_cups((int)($account['cups']??0)),'avatarKey'=>(string)($account['avatar_key']??'guest'),
        'wallSkinKey'=>(string)($account['wall_skin_key']??'classic'),'ownedAvatars'=>array_values($account['owned_avatars']??['guest']),
        'ownedWalls'=>array_values($account['owned_walls']??['classic']),'daily'=>daily_status($account),'wheel'=>wheel_status($account),
        'stats'=>['wins'=>(int)($account['wins']??0),'losses'=>(int)($account['losses']??0),'matchesPlayed'=>(int)($account['matches_played']??0),'realMatches'=>(int)($account['real_matches']??0),'botMatches'=>(int)($account['bot_matches']??0)],
        'settings'=>$account['settings']??[],'createdAt'=>iso_time((int)($account['created_at']??now_ms())),'lastSeenAt'=>iso_time((int)($account['last_seen_at']??now_ms())),
    ];
}
function create_player_session(array &$state, string $accountId): string {
    $token=random_token(32); $state['sessions'][token_hash($token)]=['account_id'=>$accountId,'created_at'=>now_ms(),'last_seen_at'=>now_ms()]; return $token;
}
function account_from_token(array &$state, string $token): ?array {
    if ($token==='') return null; $hash=token_hash($token); $session=$state['sessions'][$hash]??null;
    if (!is_array($session)) return null; $accountId=(string)($session['account_id']??'');
    if ($accountId==='' || !isset($state['accounts'][$accountId])) return null;
    $state['sessions'][$hash]['last_seen_at']=now_ms(); $state['accounts'][$accountId]['last_seen_at']=now_ms(); return $state['accounts'][$accountId];
}
function require_account_from_input(array &$state, array $data): array {
    $account=account_from_token($state,clean_string($data['token']??'',256));
    if ($account===null) respond(['ok'=>false,'error'=>'authentication_required'],401); return $account;
}
function profile_from_authenticated_input(array &$state, array $data): array {
    $account=require_account_from_input($state,$data); $deviceId=clean_string($data['deviceId']??'',120);
    if (strlen($deviceId)<12) respond(['ok'=>false,'error'=>'device_id_required'],422);
    return ['device_id'=>$deviceId,'account_id'=>(string)$account['id'],'name'=>(string)$account['name'],'email'=>(string)$account['email'],'country_code'=>(string)$account['country_code'],'avatar_key'=>(string)$account['avatar_key'],'cups'=>(int)$account['cups'],'registered'=>true,'registered_at'=>(int)($account['created_at']??now_ms())];
}
function upsert_user(array &$state, array $profile): array {
    $id=$profile['device_id']; $now=now_ms(); $existing=$state['users'][$id]??[];
    if (!is_array($existing)) $existing=[];
    $existing=array_replace(['device_id'=>$id,'created_at'=>$now,'active_match_id'=>null,'queue_since'=>null,'queue_request_id'=>null,'matches_played'=>0,'wins'=>0,'losses'=>0,'real_matches'=>0,'bot_matches'=>0],$existing,[
        'account_id'=>$profile['account_id'],'name'=>$profile['name'],'email'=>$profile['email'],'country_code'=>$profile['country_code'],'avatar_key'=>$profile['avatar_key'],'cups'=>$profile['cups'],'registered'=>true,'registered_at'=>$profile['registered_at'],'last_seen_at'=>$now,
    ]);
    $accountId=(string)$existing['account_id']; if (isset($state['accounts'][$accountId])) $existing['active_match_id']=$state['accounts'][$accountId]['active_match_id']??$existing['active_match_id'];
    $state['users'][$id]=$existing; return $existing;
}
function public_user(array $user): array { return ['name'=>(string)($user['name']??'حریف'),'countryCode'=>(string)($user['country_code']??'IR'),'avatarKey'=>(string)($user['avatar_key']??'guest'),'cups'=>(int)($user['cups']??0)]; }
function remove_from_queue(array &$state, string $deviceId): void {
    $state['queue']=array_values(array_filter($state['queue'],fn($id)=>(string)$id!==$deviceId));
    if (!isset($state['users'][$deviceId])) return;
    $state['users'][$deviceId]['queue_since']=null; $state['users'][$deviceId]['queue_request_id']=null;
    $accountId=(string)($state['users'][$deviceId]['account_id']??'');
    if ($accountId!=='' && isset($state['accounts'][$accountId]) && ($state['accounts'][$accountId]['queue_device_id']??null)===$deviceId) $state['accounts'][$accountId]['queue_device_id']=null;
}
function remove_account_from_queue(array &$state, string $accountId): void { if ($accountId==='') return; foreach($state['users'] as $deviceId=>$user) if((string)($user['account_id']??'')===$accountId) remove_from_queue($state,(string)$deviceId); }
function clear_active_match_for_device(array &$state, string $deviceId, ?string $expectedMatchId=null): void {
    if (!isset($state['users'][$deviceId])) return; $current=(string)($state['users'][$deviceId]['active_match_id']??'');
    if ($expectedMatchId!==null && $current!=='' && $current!==$expectedMatchId) return;
    $state['users'][$deviceId]['active_match_id']=null; $accountId=(string)($state['users'][$deviceId]['account_id']??'');
    if ($accountId!=='' && isset($state['accounts'][$accountId])) { $accountCurrent=(string)($state['accounts'][$accountId]['active_match_id']??''); if ($expectedMatchId===null || $accountCurrent==='' || $accountCurrent===$expectedMatchId) $state['accounts'][$accountId]['active_match_id']=null; }
}
function set_active_match_for_device(array &$state, string $deviceId, string $matchId): void {
    if (!isset($state['users'][$deviceId])) return; $state['users'][$deviceId]['active_match_id']=$matchId; $accountId=(string)($state['users'][$deviceId]['account_id']??'');
    if ($accountId!=='' && isset($state['accounts'][$accountId])) { $state['accounts'][$accountId]['active_match_id']=$matchId; $state['accounts'][$accountId]['queue_device_id']=null; }
}
function role_for_match(array $match, string $deviceId): ?string { if(($match['blue_device_id']??'')===$deviceId)return 'blue'; if(($match['red_device_id']??'')===$deviceId)return 'red'; return null; }
function other_role(string $role): string { return $role==='blue'?'red':'blue'; }
function opponent_device(array $match,string $role): string { return (string)($role==='blue'?($match['red_device_id']??''):($match['blue_device_id']??'')); }
function ensure_monthly_season(array &$state): void {
    $now=now_ms(); $currentKey=current_season_key(); $resetAt=(int)(strtotime(date('Y-m-01 12:00:00'))*1000); $last=(string)($state['season']['last_reset_key']??$currentKey);
    if ($now<$resetAt || $last===$currentKey) return;
    $archiveKey=date('Y-m',strtotime('-1 month',intdiv($resetAt,1000))); $ranking=[];
    foreach($state['accounts'] as $account) $ranking[]=['accountId'=>$account['id'],'name'=>$account['name'],'countryCode'=>$account['country_code'],'avatarKey'=>$account['avatar_key'],'cups'=>(int)$account['cups']];
    usort($ranking,fn($a,$b)=>$b['cups']<=>$a['cups'] ?: strcmp((string)$a['name'],(string)$b['name']));
    $state['season']['archives'][$archiveKey]=array_slice($ranking,0,10);
    foreach($state['accounts'] as $id=>&$account) {
        if ((int)$account['cups']>4000) { $before=(int)$account['cups']; $account['cups']=4000; record_activity($account,'monthly_legend_reset',['before'=>$before,'after'=>4000,'season'=>$archiveKey]); }
    }
    unset($account);
    foreach($state['users'] as &$user) { $aid=(string)($user['account_id']??''); if($aid!==''&&isset($state['accounts'][$aid]))$user['cups']=(int)$state['accounts'][$aid]['cups']; }
    unset($user); $state['season']['last_reset_key']=$currentKey;
}
function cleanup_state(array &$state): void {
    ensure_monthly_season($state); $now=now_ms();
    foreach($state['password_resets'] as $email=>$reset) if(!is_array($reset)||(int)($reset['expires_at']??0)<$now)unset($state['password_resets'][$email]);
    foreach($state['idempotency'] as $id=>$item) if((int)($item['created_at']??0)<$now-90*86400000)unset($state['idempotency'][$id]);
    $queue=[];$seen=[];
    foreach($state['queue'] as $deviceId){$deviceId=(string)$deviceId;if($deviceId===''||isset($seen[$deviceId]))continue;$user=$state['users'][$deviceId]??null;if(!is_array($user)||!empty($user['active_match_id'])||($user['queue_since']??0)<=0)continue;if(($user['last_seen_at']??0)<$now-20000){remove_from_queue($state,$deviceId);continue;}$queue[]=$deviceId;$seen[$deviceId]=true;}
    $state['queue']=$queue;
    foreach($state['matches'] as $id=>&$match){if(($match['status']??'')!=='active')continue;$last=(int)($match['last_activity_at']??$match['started_at']??$now);if($last<$now-15*60*1000){$match['status']='cancelled';$match['finish_reason']='inactive_timeout';$match['ended_at']=$now;foreach(['blue_device_id','red_device_id'] as $key){$device=(string)($match[$key]??'');if($device!=='')clear_active_match_for_device($state,$device,(string)$id);}}}unset($match);
}
function state_tx(callable $callback): mixed {
    $dir=dirname(STATE_FILE); if(!is_dir($dir))@mkdir($dir,0755,true); $fp=@fopen(STATE_FILE,'c+'); if(!$fp)respond(['ok'=>false,'error'=>'storage_unavailable'],500);
    if(!flock($fp,LOCK_EX)){fclose($fp);respond(['ok'=>false,'error'=>'storage_lock_unavailable'],503);} rewind($fp);$raw=stream_get_contents($fp);$decoded=json_decode($raw?:'{}',true);$state=normalize_state(is_array($decoded)?$decoded:default_state());cleanup_state($state);
    try{$args=[&$state];$result=call_user_func_array($callback,$args);rewind($fp);ftruncate($fp,0);fwrite($fp,json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));fflush($fp);return $result;}finally{flock($fp,LOCK_UN);fclose($fp);}
}
function engine_new(): array {
    return [
        'blue' => ['row' => 8, 'col' => 4],
        'red' => ['row' => 0, 'col' => 4],
        'turn' => 'blue',
        'winner' => null,
        'blueWalls' => 10,
        'redWalls' => 10,
        'turnNumber' => 1,
        'walls' => [],
        'history' => [],
    ];
}
function cell_key(array $c): string { return ((int) $c['row']) . ':' . ((int) $c['col']); }
function same_cell(array $a, array $b): bool { return (int) $a['row'] === (int) $b['row'] && (int) $a['col'] === (int) $b['col']; }
function inside(array $c): bool { return $c['row'] >= 0 && $c['row'] < 9 && $c['col'] >= 0 && $c['col'] < 9; }
function position_of(array $engine, string $player): array { return $engine[$player]; }
function is_blocked(array $engine, array $a, array $b): bool {
    $dr = $b['row'] - $a['row'];
    $dc = $b['col'] - $a['col'];
    if (abs($dr) + abs($dc) !== 1) return true;
    foreach ($engine['walls'] as $wall) {
        if ($dc === 1 && $wall['orientation'] === 'vertical' && $wall['col'] === $a['col'] && ($wall['row'] === $a['row'] || $wall['row'] === $a['row'] - 1)) return true;
        if ($dc === -1 && $wall['orientation'] === 'vertical' && $wall['col'] === $b['col'] && ($wall['row'] === $a['row'] || $wall['row'] === $a['row'] - 1)) return true;
        if ($dr === 1 && $wall['orientation'] === 'horizontal' && $wall['row'] === $a['row'] && ($wall['col'] === $a['col'] || $wall['col'] === $a['col'] - 1)) return true;
        if ($dr === -1 && $wall['orientation'] === 'horizontal' && $wall['row'] === $b['row'] && ($wall['col'] === $a['col'] || $wall['col'] === $a['col'] - 1)) return true;
    }
    return false;
}
function legal_moves(array $engine, ?string $player = null): array {
    $player ??= $engine['turn'];
    $origin = position_of($engine, $player);
    $opponent = position_of($engine, other_role($player));
    $result = [];
    $seen = [];
    $directions = [[1,0],[-1,0],[0,1],[0,-1]];
    $add = function(array $c) use (&$result, &$seen): void {
        $key = cell_key($c);
        if (!isset($seen[$key])) { $seen[$key] = true; $result[] = $c; }
    };
    foreach ($directions as [$dr, $dc]) {
        $adj = ['row' => $origin['row'] + $dr, 'col' => $origin['col'] + $dc];
        if (!inside($adj) || is_blocked($engine, $origin, $adj)) continue;
        if (!same_cell($adj, $opponent)) { $add($adj); continue; }
        $beyond = ['row' => $adj['row'] + $dr, 'col' => $adj['col'] + $dc];
        if (inside($beyond) && !is_blocked($engine, $adj, $beyond)) { $add($beyond); continue; }
        $sides = $dr === 0 ? [[1,0],[-1,0]] : [[0,1],[0,-1]];
        foreach ($sides as [$sdr, $sdc]) {
            $diag = ['row' => $adj['row'] + $sdr, 'col' => $adj['col'] + $sdc];
            if (inside($diag) && !is_blocked($engine, $adj, $diag)) $add($diag);
        }
    }
    return $result;
}
function shortest_path_length(array $engine, string $player): ?int {
    $start = position_of($engine, $player);
    $target = $player === 'blue' ? 0 : 8;
    $queue = [[$start, 0]];
    $visited = [cell_key($start) => true];
    $directions = [[1,0],[-1,0],[0,1],[0,-1]];
    while ($queue) {
        [$cell, $distance] = array_shift($queue);
        if ($cell['row'] === $target) return $distance;
        foreach ($directions as [$dr, $dc]) {
            $next = ['row' => $cell['row'] + $dr, 'col' => $cell['col'] + $dc];
            $key = cell_key($next);
            if (!inside($next) || isset($visited[$key]) || is_blocked($engine, $cell, $next)) continue;
            $visited[$key] = true;
            $queue[] = [$next, $distance + 1];
        }
    }
    return null;
}
function can_place_wall(array &$engine, int $row, int $col, string $orientation, ?string $player = null): bool {
    $player ??= $engine['turn'];
    $wallsLeft = $player === 'blue' ? $engine['blueWalls'] : $engine['redWalls'];
    if ($engine['winner'] !== null || $wallsLeft <= 0 || $row < 0 || $row > 7 || $col < 0 || $col > 7) return false;
    if ($orientation !== 'horizontal' && $orientation !== 'vertical') return false;
    foreach ($engine['walls'] as $wall) {
        if ($wall['orientation'] === $orientation) {
            if ($orientation === 'horizontal' && $wall['row'] === $row && abs($wall['col'] - $col) <= 1) return false;
            if ($orientation === 'vertical' && $wall['col'] === $col && abs($wall['row'] - $row) <= 1) return false;
        } elseif ($wall['row'] === $row && $wall['col'] === $col) return false;
    }
    $engine['walls'][] = ['row' => $row, 'col' => $col, 'orientation' => $orientation, 'owner' => $player];
    $valid = shortest_path_length($engine, 'blue') !== null && shortest_path_length($engine, 'red') !== null;
    array_pop($engine['walls']);
    return $valid;
}
function engine_move(array &$engine, array $destination): bool {
    if ($engine['winner'] !== null) return false;
    $legal = false;
    foreach (legal_moves($engine) as $cell) if (same_cell($cell, $destination)) { $legal = true; break; }
    if (!$legal) return false;
    $player = $engine['turn'];
    $from = $engine[$player];
    $engine[$player] = $destination;
    $engine['history'][] = ['type' => 'move', 'player' => $player, 'from' => $from, 'to' => $destination];
    if ($engine['blue']['row'] === 0) $engine['winner'] = 'blue';
    elseif ($engine['red']['row'] === 8) $engine['winner'] = 'red';
    else { $engine['turn'] = other_role($player); $engine['turnNumber']++; }
    return true;
}
function engine_wall(array &$engine, int $row, int $col, string $orientation): bool {
    if (!can_place_wall($engine, $row, $col, $orientation)) return false;
    $player = $engine['turn'];
    $wall = ['row' => $row, 'col' => $col, 'orientation' => $orientation, 'owner' => $player];
    $engine['walls'][] = $wall;
    if ($player === 'blue') $engine['blueWalls']--; else $engine['redWalls']--;
    $engine['history'][] = ['type' => 'wall', 'player' => $player, 'wall' => $wall];
    $engine['turn'] = other_role($player);
    $engine['turnNumber']++;
    return true;
}
function engine_expire(array &$engine): void {
    if ($engine['winner'] !== null) return;
    $engine['turn'] = other_role($engine['turn']);
    $engine['turnNumber']++;
}
function engine_snapshot(array $engine): array {
    $walls = [];
    foreach ($engine['walls'] as $w) $walls[] = ['row'=>$w['row'],'col'=>$w['col'],'orientation'=>$w['orientation']==='horizontal'?0:1,'owner'=>$w['owner']==='blue'?0:1];
    $history = [];
    foreach ($engine['history'] as $r) {
        if ($r['type'] === 'wall') $history[] = ['type'=>'wall','player'=>$r['player']==='blue'?0:1,'row'=>$r['wall']['row'],'col'=>$r['wall']['col'],'orientation'=>$r['wall']['orientation']==='horizontal'?0:1];
        else $history[] = ['type'=>'move','player'=>$r['player']==='blue'?0:1,'fromRow'=>$r['from']['row'],'fromCol'=>$r['from']['col'],'toRow'=>$r['to']['row'],'toCol'=>$r['to']['col']];
    }
    return [
        'mode'=>2,'blueRow'=>$engine['blue']['row'],'blueCol'=>$engine['blue']['col'],'redRow'=>$engine['red']['row'],'redCol'=>$engine['red']['col'],
        'turn'=>$engine['turn']==='blue'?0:1,'winner'=>$engine['winner']===null?null:($engine['winner']==='blue'?0:1),
        'blueWalls'=>$engine['blueWalls'],'redWalls'=>$engine['redWalls'],'turnNumber'=>$engine['turnNumber'],'walls'=>$walls,'history'=>$history,
    ];
}
function perspective_snapshot(array $engine, string $role): array {
    $s = engine_snapshot($engine);
    if ($role === 'blue') return $s;
    $walls = [];
    foreach ($s['walls'] as $w) $walls[] = ['row'=>7-$w['row'],'col'=>7-$w['col'],'orientation'=>$w['orientation'],'owner'=>$w['owner']===0?1:0];
    $history = [];
    foreach ($s['history'] as $r) {
        if ($r['type'] === 'wall') $history[] = ['type'=>'wall','player'=>$r['player']===0?1:0,'row'=>7-$r['row'],'col'=>7-$r['col'],'orientation'=>$r['orientation']];
        else $history[] = ['type'=>'move','player'=>$r['player']===0?1:0,'fromRow'=>8-$r['fromRow'],'fromCol'=>8-$r['fromCol'],'toRow'=>8-$r['toRow'],'toCol'=>8-$r['toCol']];
    }
    return [
        ...$s,
        'blueRow'=>8-$s['redRow'],'blueCol'=>8-$s['redCol'],'redRow'=>8-$s['blueRow'],'redCol'=>8-$s['blueCol'],
        'turn'=>$s['turn']===0?1:0,'winner'=>$s['winner']===null?null:($s['winner']===0?1:0),
        'blueWalls'=>$s['redWalls'],'redWalls'=>$s['blueWalls'],'walls'=>$walls,'history'=>$history,
    ];
}
function action_from_perspective(array $action, string $role): array {
    if ($role === 'blue') return $action;
    if (($action['type'] ?? '') === 'move') {
        $d = $action['destination'] ?? [];
        return ['type'=>'move','destination'=>['row'=>8-(int)($d['row']??0),'col'=>8-(int)($d['col']??0)]];
    }
    if (($action['type'] ?? '') === 'wall') return ['type'=>'wall','row'=>7-(int)($action['row']??0),'col'=>7-(int)($action['col']??0),'orientation'=>($action['orientation']??'horizontal')];
    return $action;
}

function calculate_delta(int $playerCups, int $opponentCups, bool $won): int { return league_cup_delta($playerCups,$won); }
function add_match_history(array &$account, array $entry): void { append_limited($account['match_history'],$entry,300); }
function apply_match_result_to_account(array &$state, string $deviceId, bool $won, int $before, int $after, int $delta, string $mode, string $matchId, string $opponentName, int $duration, int $moves): array {
    $user=&$state['users'][$deviceId]; $user['cups']=$after; $user['matches_played']=(int)($user['matches_played']??0)+1; $user[$won?'wins':'losses']=(int)($user[$won?'wins':'losses']??0)+1; $user[$mode==='real'?'real_matches':'bot_matches']=(int)($user[$mode==='real'?'real_matches':'bot_matches']??0)+1;
    $accountId=(string)($user['account_id']??''); $coinDelta=0;$coinBefore=0;$coinAfter=0;
    if($accountId!==''&&isset($state['accounts'][$accountId])){
        $account=&$state['accounts'][$accountId];$account['cups']=$after;$account['matches_played']=(int)$account['matches_played']+1;$account[$won?'wins':'losses']=(int)$account[$won?'wins':'losses']+1;$account[$mode==='real'?'real_matches':'bot_matches']=(int)$account[$mode==='real'?'real_matches':'bot_matches']+1;$account['last_seen_at']=now_ms();
        $coinBefore=(int)$account['coins']; if($won){$coinDelta=league_win_coins($before);$tx=record_transaction($account,'match_win_reward',$coinDelta,'League win reward','match-'.$matchId.'-'.$accountId,['league'=>league_name_for_cups($before),'mode'=>$mode]);$coinAfter=$tx['after'];}else{$coinAfter=$coinBefore;}
        add_match_history($account,['matchId'=>$matchId,'mode'=>$mode,'won'=>$won,'opponentName'=>$opponentName,'cupBefore'=>$before,'cupDelta'=>$delta,'cupAfter'=>$after,'coinDelta'=>$coinDelta,'rewardDoubled'=>false,'doubleRewardCoins'=>0,'durationSeconds'=>$duration,'movesCount'=>$moves,'playedAt'=>iso_time()]);
    }
    clear_active_match_for_device($state,$deviceId,$matchId);
    return ['cupBefore'=>$before,'cupDelta'=>$delta,'cupAfter'=>$after,'coinBefore'=>$coinBefore,'coinDelta'=>$coinDelta,'coinAfter'=>$coinAfter,'league'=>league_name_for_cups($before)];
}
function finish_real_match(array &$state, array &$match, string $winnerRole, string $reason): void {
    if(($match['status']??'')!=='active')return;$now=now_ms();$blueId=(string)$match['blue_device_id'];$redId=(string)$match['red_device_id'];$blue=$state['users'][$blueId];$red=$state['users'][$redId];$blueWon=$winnerRole==='blue';
    $blueBefore=(int)($match['blue_start_cups']??$blue['cups']);$redBefore=(int)($match['red_start_cups']??$red['cups']);$blueDelta=league_cup_delta($blueBefore,$blueWon);$redDelta=league_cup_delta($redBefore,!$blueWon);$blueAfter=max(0,$blueBefore+$blueDelta);$redAfter=max(0,$redBefore+$redDelta);
    $duration=max(0,(int)floor(($now-(int)$match['started_at'])/1000));$moves=count($match['engine']['history']);
    $blueResult=apply_match_result_to_account($state,$blueId,$blueWon,$blueBefore,$blueAfter,$blueDelta,'real',(string)$match['id'],(string)$red['name'],$duration,$moves);
    $redResult=apply_match_result_to_account($state,$redId,!$blueWon,$redBefore,$redAfter,$redDelta,'real',(string)$match['id'],(string)$blue['name'],$duration,$moves);
    $match['status']='finished';$match['winner_device_id']=$winnerRole==='blue'?$blueId:$redId;$match['finish_reason']=$reason;$match['ended_at']=$now;$match['duration_seconds']=$duration;$match['moves_count']=$moves;$match['cup_results']=['blue'=>$blueResult,'red'=>$redResult];$match['revision']++;
}
function finished_payload(array $match,string $role): array {
    $result=$match['cup_results'][$role]??['cupBefore'=>0,'cupDelta'=>0,'cupAfter'=>0,'coinBefore'=>0,'coinDelta'=>0,'coinAfter'=>0,'league'=>'Bronze'];
    return ['matchId'=>$match['id'],'state'=>isset($match['engine'])?perspective_snapshot($match['engine'],$role):null,'won'=>($match['winner_device_id']??'')===($role==='blue'?$match['blue_device_id']:$match['red_device_id']),'finishReason'=>$match['finish_reason']??'completed','cupBefore'=>$result['cupBefore'],'cupDelta'=>$result['cupDelta'],'cupAfter'=>$result['cupAfter'],'coinBefore'=>$result['coinBefore'],'coinDelta'=>$result['coinDelta'],'coinAfter'=>$result['coinAfter'],'league'=>$result['league'],'durationSeconds'=>(int)($match['duration_seconds']??0)];
}
function create_real_match(array &$state,string $a,string $b): string {
    $id=random_id('m_');$swap=random_int(0,1)===1;$blue=$swap?$b:$a;$red=$swap?$a:$b;$now=now_ms();
    $state['matches'][$id]=['id'=>$id,'mode'=>'real','status'=>'active','blue_device_id'=>$blue,'red_device_id'=>$red,'blue_start_cups'=>(int)$state['users'][$blue]['cups'],'red_start_cups'=>(int)$state['users'][$red]['cups'],'started_at'=>$now,'ended_at'=>null,'finish_reason'=>null,'winner_device_id'=>null,'moves_count'=>0,'engine'=>engine_new(),'turn_ends_at'=>$now+TURN_DURATION_MS,'last_activity_at'=>$now,'revision'=>1,'reactions'=>['blue'=>['seq'=>0,'value'=>''],'red'=>['seq'=>0,'value'=>'']],'processed_requests'=>[]];
    set_active_match_for_device($state,$blue,$id);set_active_match_for_device($state,$red,$id);remove_from_queue($state,$blue);remove_from_queue($state,$red);return $id;
}
function bot_opponent(array $user): array { $names=['نگهبان دیوار','سایه آبی','شکننده مسیر','نگهبان نئون','قهرمان مرز','روباه دیوار'];$countries=['IR','DE','TR','PK','AE','FR','IT','ES','BR','JP'];return ['name'=>$names[array_rand($names)],'countryCode'=>$countries[array_rand($countries)],'avatarKey'=>'guest','cups'=>max(0,(int)$user['cups']+random_int(-50,50))]; }
function create_bot_match(array &$state,string $deviceId): string {
    $id=random_id('b_');$now=now_ms();$state['matches'][$id]=['id'=>$id,'mode'=>'bot','status'=>'active','blue_device_id'=>$deviceId,'red_device_id'=>null,'blue_start_cups'=>(int)$state['users'][$deviceId]['cups'],'blue_name'=>$state['users'][$deviceId]['name'],'red_name'=>'ربات','opponent'=>bot_opponent($state['users'][$deviceId]),'started_at'=>$now,'ended_at'=>null,'finish_reason'=>null,'winner_device_id'=>null,'moves_count'=>0,'last_activity_at'=>$now,'revision'=>1];set_active_match_for_device($state,$deviceId,$id);remove_from_queue($state,$deviceId);return $id;
}
function session_payload(array $state,array $match,string $deviceId): array {
    if($match['mode']==='bot')return ['matchId'=>$match['id'],'opponent'=>$match['opponent'],'state'=>null,'turnEndsAt'=>null];$role=role_for_match($match,$deviceId);$oppId=opponent_device($match,$role);return ['matchId'=>$match['id'],'opponent'=>public_user($state['users'][$oppId]),'state'=>perspective_snapshot($match['engine'],$role),'turnEndsAt'=>(int)$match['turn_ends_at']];
}
function tick_match(array &$state, array &$match): void {
    if (($match['status']??'') !== 'active' || ($match['mode']??'') !== 'real') return;
    $now = now_ms();
    if ($now >= (int)$match['turn_ends_at']) {
        engine_expire($match['engine']);
        $match['turn_ends_at'] = $now + TURN_DURATION_MS;
        $match['last_activity_at'] = $now;
        $match['revision']++;
    }
}
