<?php require_once __DIR__ . '/core.php';
$summary=state_tx(function(array &$state): array {
    $now=now_ms();$online=0;
    foreach($state['accounts'] as $account) if((int)($account['last_seen_at']??0)>=$now-ONLINE_WINDOW_MS)$online++;
    return ['online'=>$online,'users'=>count($state['accounts'])];
});
respond(['ok'=>true,'service'=>'wallfront-php-api','version'=>API_VERSION,'online'=>$summary['online'],'users'=>$summary['users'],'time'=>iso_time()]);
