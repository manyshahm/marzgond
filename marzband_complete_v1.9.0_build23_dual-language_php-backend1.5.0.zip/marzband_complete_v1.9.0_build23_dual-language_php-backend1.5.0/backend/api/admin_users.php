<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';
require_admin();
$q = strtolower(clean_string($_GET['q'] ?? '', 100));
$league = strtolower(clean_string($_GET['league'] ?? '', 20));
$online = clean_string($_GET['online'] ?? '', 10);
$limit = max(1, min(500, (int)($_GET['limit'] ?? 200)));
$users = state_tx(function(array &$state) use ($q, $league, $online, $limit): array {
    $now = now_ms(); $out = [];
    foreach ($state['accounts'] as $a) {
        $isOnline = (int)($a['last_seen_at'] ?? 0) >= $now - ONLINE_WINDOW_MS;
        $lk = league_key_for_cups((int)($a['cups'] ?? 0));
        $haystack = strtolower((string)($a['name'] ?? '') . ' ' . (string)($a['email'] ?? '') . ' ' . (string)($a['id'] ?? ''));
        if ($q !== '' && !str_contains($haystack, $q)) continue;
        if ($league !== '' && $lk !== $league) continue;
        if ($online === '1' && !$isOnline) continue;
        if ($online === '0' && $isOnline) continue;
        $out[] = [
            'id'=>$a['id'], 'name'=>$a['name'], 'email'=>$a['email'], 'countryCode'=>$a['country_code'],
            'avatarKey'=>$a['avatar_key'] ?? 'guest', 'league'=>ucfirst($lk), 'cups'=>(int)$a['cups'], 'coins'=>(int)$a['coins'],
            'online'=>$isOnline, 'matchesPlayed'=>(int)($a['matches_played'] ?? 0), 'wins'=>(int)($a['wins'] ?? 0),
            'losses'=>(int)($a['losses'] ?? 0), 'registeredAt'=>iso_time((int)$a['created_at']), 'lastSeenAt'=>iso_time((int)$a['last_seen_at']),
        ];
    }
    usort($out, fn($a, $b) => strcmp((string)$b['lastSeenAt'], (string)$a['lastSeenAt']));
    return array_slice($out, 0, $limit);
});
respond(['ok'=>true, 'users'=>$users]);
