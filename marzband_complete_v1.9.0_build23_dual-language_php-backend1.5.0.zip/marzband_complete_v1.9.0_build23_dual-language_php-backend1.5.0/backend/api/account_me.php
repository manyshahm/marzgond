<?php require_once __DIR__ . '/core.php';
$data=input_json();
$result=state_tx(function(array &$state) use($data): array {
    $account=require_account_from_input($state,$data);
    return ['user'=>public_account($account)];
});
respond(['ok'=>true]+$result);
