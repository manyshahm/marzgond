<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';
require_admin();
$q = strtolower(clean_string($_GET['q'] ?? '', 160));
$type = strtolower(clean_string($_GET['type'] ?? '', 60));
$limit = max(1, min(1000, (int)($_GET['limit'] ?? 300)));
$rows = state_tx(function(array &$state) use ($q, $type, $limit): array {
    $out = [];
    foreach ($state['accounts'] as $account) {
        foreach (($account['transactions'] ?? []) as $tx) {
            if (!is_array($tx)) continue;
            $txType = strtolower((string)($tx['type'] ?? ''));
            if ($type !== '' && $txType !== $type) continue;
            $haystack = strtolower((string)($account['name'] ?? '') . ' ' . (string)($account['email'] ?? '') . ' ' . (string)($account['id'] ?? '') . ' ' . (string)($tx['reason'] ?? ''));
            if ($q !== '' && !str_contains($haystack, $q)) continue;
            $out[] = [
                'id'=>(string)($tx['id'] ?? ''), 'accountId'=>(string)($account['id'] ?? ''),
                'userName'=>(string)($account['name'] ?? 'User'), 'email'=>(string)($account['email'] ?? ''),
                'type'=>(string)($tx['type'] ?? ''), 'delta'=>(int)($tx['delta'] ?? 0),
                'before'=>(int)($tx['before'] ?? 0), 'after'=>(int)($tx['after'] ?? 0),
                'reason'=>(string)($tx['reason'] ?? ''), 'createdAt'=>iso_time((int)($tx['created_at'] ?? now_ms())),
            ];
        }
    }
    usort($out, fn($a, $b) => strcmp((string)$b['createdAt'], (string)$a['createdAt']));
    return array_slice($out, 0, $limit);
});
respond(['ok'=>true, 'transactions'=>$rows]);
