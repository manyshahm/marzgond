<?php require_once __DIR__ . '/core.php';
$data=input_json(); $token=clean_string($data['token']??'',256);
state_tx(function(array &$state) use($token): void { if($token!=='') unset($state['sessions'][token_hash($token)]); });
respond(['ok'=>true]);
