<?php require_once __DIR__ . '/core.php';
$data=input_json();
if(!hash_equals(ADMIN_USERNAME,clean_string($data['username']??'',80))||!hash_equals(ADMIN_PASSWORD,(string)($data['password']??''))) respond(['ok'=>false,'error'=>'Incorrect username or password'],401);
respond(['ok'=>true,'token'=>admin_token()]);
