'use strict';

const API_BASE = '/marzband/api';
const $ = (id) => document.getElementById(id);
const fa = new Intl.NumberFormat('fa-IR');
const dateFormat = new Intl.DateTimeFormat('fa-IR', { dateStyle: 'short', timeStyle: 'short' });
const sectionTitles = {
  dashboard: 'داشبورد', users: 'کاربران', matches: 'مسابقات',
  transactions: 'تراکنش‌ها', economy: 'پاداش‌ها و اقتصاد', settings: 'تنظیمات',
};

let token = localStorage.getItem('marzband_admin_token') || '';
let refreshTimer = null;
let selectedUserId = null;
let currentSection = 'dashboard';

function number(value) { return fa.format(Number(value) || 0); }
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  })[char]);
}
function initials(name) {
  const value = String(name || 'U').trim();
  return escapeHtml(value.slice(0, 1).toUpperCase() || 'U');
}
function showApp() { $('loginView').classList.add('hidden'); $('appView').classList.remove('hidden'); }
function showLogin() { $('appView').classList.add('hidden'); $('loginView').classList.remove('hidden'); }
function authHeaders(extra = {}) { return { Authorization: `Bearer ${token}`, ...extra }; }

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, { cache: 'no-store', ...options });
  const payload = await response.json().catch(() => ({}));
  if (response.status === 401) {
    logout();
    throw new Error('نشست مدیریت معتبر نیست.');
  }
  if (!response.ok || payload.ok === false) throw new Error(payload.error || 'خطای ارتباط با سرور');
  return payload;
}

function openSidebar() { $('sidebar').classList.add('open'); $('sidebarBackdrop').classList.remove('hidden'); }
function closeSidebar() { $('sidebar').classList.remove('open'); $('sidebarBackdrop').classList.add('hidden'); }

function setStats(stats = {}) {
  const map = {
    totalUsers: stats.total_users, onlineNow: stats.online_now,
    matchesActive: stats.matches_active, matchesTotal: stats.matches_total,
    activeToday: stats.active_today, activeYesterday: stats.active_yesterday,
    activeWeek: stats.active_week, activeMonth: stats.active_month,
    regToday: stats.registrations_today, regYesterday: stats.registrations_yesterday,
    regWeek: stats.registrations_week, regMonth: stats.registrations_month,
  };
  Object.entries(map).forEach(([id, value]) => { if ($(id)) $(id).textContent = number(value); });
  const real = Number(stats.matches_real) || 0;
  const bot = Number(stats.matches_bot) || 0;
  const total = Math.max(1, real + bot);
  $('realMatchesText').textContent = `${number(real)} مسابقه`;
  $('botMatchesText').textContent = `${number(bot)} مسابقه`;
  $('realMatchesBar').style.width = `${Math.round(real * 100 / total)}%`;
  $('botMatchesBar').style.width = `${Math.round(bot * 100 / total)}%`;
}

function matchRow(match) {
  const real = match.mode === 'real';
  const status = match.status === 'finished' ? 'پایان‌یافته' : match.status === 'active' ? 'فعال' : 'لغوشده';
  return `<tr><td>${match.started_at ? dateFormat.format(new Date(match.started_at)) : '—'}</td>
    <td><span class="badge">${real ? 'بازیکن واقعی' : 'ربات'}</span></td>
    <td>${escapeHtml(match.blue_name || '—')}</td><td>${escapeHtml(real ? (match.red_name || '—') : 'ربات')}</td>
    <td>${escapeHtml(match.winner_name || '—')}</td><td>${status}</td><td>${number(match.moves_count)}</td></tr>`;
}

async function loadDashboard() {
  try {
    const payload = await request('/admin_stats.php', { headers: authHeaders() });
    setStats(payload.stats || {});
    $('lastUpdate').textContent = `آخرین به‌روزرسانی: ${dateFormat.format(new Date(payload.generatedAt || Date.now()))}`;
    $('healthPill').innerHTML = '<i></i> متصل';
  } catch (error) {
    $('healthPill').textContent = 'قطع ارتباط';
    $('lastUpdate').textContent = error.message;
  }
}

async function loadMatches() {
  $('matchesBody').innerHTML = '<tr><td colspan="7" class="empty">در حال دریافت مسابقات…</td></tr>';
  try {
    const payload = await request('/admin_matches.php?limit=100', { headers: authHeaders() });
    const matches = Array.isArray(payload.matches) ? payload.matches : [];
    $('matchesBody').innerHTML = matches.length ? matches.map(matchRow).join('') : '<tr><td colspan="7" class="empty">هنوز مسابقه‌ای ثبت نشده است.</td></tr>';
  } catch (error) {
    $('matchesBody').innerHTML = `<tr><td colspan="7" class="empty error-text">${escapeHtml(error.message)}</td></tr>`;
  }
}

function userCard(user) {
  const online = user.online === true;
  return `<article class="user-card" data-user-card="${escapeHtml(user.id)}">
    <div class="user-card-head"><div class="user-avatar">${initials(user.name)}</div><div class="user-main"><strong>${escapeHtml(user.name || 'کاربر')}</strong><small>${escapeHtml(user.email || '—')}</small></div><span class="status ${online ? 'online' : 'offline'}">${online ? 'آنلاین' : 'آفلاین'}</span></div>
    <div class="user-stats"><div><span>لیگ</span><b>${escapeHtml(user.league || 'Bronze')}</b></div><div><span>کاپ</span><b>${number(user.cups)}</b></div><div><span>سکه</span><b>${number(user.coins)}</b></div><div><span>مسابقه</span><b>${number(user.matchesPlayed)}</b></div></div>
    <div class="user-meta"><span>${escapeHtml(user.countryCode || '—')}</span><span>آخرین فعالیت: ${user.lastSeenAt ? dateFormat.format(new Date(user.lastSeenAt)) : '—'}</span></div>
    <button class="user-edit" type="button" data-user-id="${escapeHtml(user.id)}">مشاهده و ویرایش</button>
  </article>`;
}

async function loadUsers() {
  $('usersGrid').innerHTML = '<div class="empty panel-lite">در حال دریافت کاربران…</div>';
  const params = new URLSearchParams({ limit: '500' });
  const q = $('userSearch').value.trim();
  const league = $('leagueFilter').value;
  const online = $('onlineFilter').value;
  if (q) params.set('q', q);
  if (league) params.set('league', league);
  if (online) params.set('online', online);
  try {
    const payload = await request(`/admin_users.php?${params}`, { headers: authHeaders() });
    const users = Array.isArray(payload.users) ? payload.users : [];
    $('usersCount').textContent = `${number(users.length)} کاربر`;
    $('usersGrid').innerHTML = users.length ? users.map(userCard).join('') : '<div class="empty panel-lite">کاربری پیدا نشد.</div>';
  } catch (error) {
    $('usersGrid').innerHTML = `<div class="empty panel-lite error-text">${escapeHtml(error.message)}</div>`;
  }
}

function transactionRow(tx) {
  const delta = Number(tx.delta) || 0;
  return `<tr><td>${tx.createdAt ? dateFormat.format(new Date(tx.createdAt)) : '—'}</td>
    <td><strong>${escapeHtml(tx.userName || '—')}</strong><br><small>${escapeHtml(tx.email || tx.accountId || '')}</small></td>
    <td>${escapeHtml(tx.type || '—')}</td><td class="${delta >= 0 ? 'positive' : 'negative'}">${delta >= 0 ? '+' : ''}${number(delta)}</td>
    <td>${number(tx.before)}</td><td>${number(tx.after)}</td><td>${escapeHtml(tx.reason || '—')}</td></tr>`;
}

async function loadTransactions() {
  $('transactionsBody').innerHTML = '<tr><td colspan="7" class="empty">در حال دریافت تراکنش‌ها…</td></tr>';
  const params = new URLSearchParams({ limit: '300' });
  const q = $('transactionSearch').value.trim();
  const type = $('transactionType').value;
  if (q) params.set('q', q);
  if (type) params.set('type', type);
  try {
    const payload = await request(`/admin_transactions.php?${params}`, { headers: authHeaders() });
    const rows = Array.isArray(payload.transactions) ? payload.transactions : [];
    $('transactionsCount').textContent = `${number(rows.length)} تراکنش`;
    $('transactionsBody').innerHTML = rows.length ? rows.map(transactionRow).join('') : '<tr><td colspan="7" class="empty">تراکنشی پیدا نشد.</td></tr>';
  } catch (error) {
    $('transactionsBody').innerHTML = `<tr><td colspan="7" class="empty error-text">${escapeHtml(error.message)}</td></tr>`;
  }
}

async function loadEconomy() {
  $('economyMetrics').innerHTML = '<div class="empty panel">در حال دریافت اطلاعات…</div>';
  try {
    const payload = await request('/admin_economy.php', { headers: authHeaders() });
    const e = payload.economy || {};
    const cards = [
      ['کل سکه کاربران', e.totalCoins, 'accent-cyan'], ['سکه افزوده‌شده', e.totalPositive, 'accent-green'],
      ['سکه کسرشده', e.totalNegative, 'accent-orange'], ['کل تراکنش‌ها', e.transactionCount, 'accent-violet'],
    ];
    $('economyMetrics').innerHTML = cards.map(([title, value, cls]) => `<article class="metric panel ${cls}"><span>${title}</span><strong>${number(value)}</strong><small>براساس اطلاعات Backend</small></article>`).join('');
  } catch (error) {
    $('economyMetrics').innerHTML = `<div class="empty panel error-text">${escapeHtml(error.message)}</div>`;
  }
}

async function loadSettings() {
  try {
    const payload = await request('/admin_settings.php', { headers: authHeaders() });
    const s = payload.settings || {};
    const rows = [
      ['نسخه API', s.apiVersion], ['منطقه زمانی', s.timezone], ['فصل جاری', s.currentSeason],
      ['آخرین ریست', s.lastResetKey], ['آرشیو ماهانه', s.archiveCount], ['تعداد حساب‌ها', s.accountCount],
      ['مسیر API', '/marzband/api'], ['زمان سرور', s.serverTime ? dateFormat.format(new Date(s.serverTime)) : '—'],
    ];
    $('settingsGrid').innerHTML = rows.map(([label, value]) => `<div><span>${label}</span><strong class="small-value">${escapeHtml(value ?? '—')}</strong></div>`).join('');
  } catch (error) {
    $('settingsGrid').innerHTML = `<div><span>خطا</span><strong class="error-text">${escapeHtml(error.message)}</strong></div>`;
  }
}

function transactionRows(transactions) {
  if (!transactions.length) return '<p class="muted">تراکنشی ثبت نشده است.</p>';
  return `<div class="table-wrap compact-table"><table><thead><tr><th>زمان</th><th>نوع</th><th>مقدار</th><th>قبل</th><th>بعد</th><th>توضیح</th></tr></thead><tbody>${transactions.map((tx) => {
    const delta = Number(tx.delta) || 0;
    return `<tr><td>${tx.created_at ? dateFormat.format(new Date(Number(tx.created_at))) : '—'}</td><td>${escapeHtml(tx.type)}</td><td class="${delta >= 0 ? 'positive' : 'negative'}">${delta >= 0 ? '+' : ''}${number(delta)}</td><td>${number(tx.before)}</td><td>${number(tx.after)}</td><td>${escapeHtml(tx.reason)}</td></tr>`;
  }).join('')}</tbody></table></div>`;
}
function matchHistoryRows(matches) {
  if (!matches.length) return '<p class="muted">مسابقه‌ای ثبت نشده است.</p>';
  return `<div class="table-wrap compact-table"><table><thead><tr><th>زمان</th><th>حریف</th><th>نوع</th><th>نتیجه</th><th>کاپ</th><th>سکه</th></tr></thead><tbody>${matches.map((m) => `<tr><td>${m.playedAt ? dateFormat.format(new Date(m.playedAt)) : '—'}</td><td>${escapeHtml(m.opponentName || '—')}</td><td>${m.mode === 'real' ? 'واقعی' : 'ربات'}</td><td>${m.won ? 'برد' : 'باخت'}</td><td class="${Number(m.cupDelta) >= 0 ? 'positive' : 'negative'}">${Number(m.cupDelta) >= 0 ? '+' : ''}${number(m.cupDelta)}</td><td>${number(m.coinDelta)}</td></tr>`).join('')}</tbody></table></div>`;
}
function activityRows(activities) {
  if (!activities.length) return '<p class="muted">فعالیتی ثبت نشده است.</p>';
  return `<div class="table-wrap compact-table"><table><thead><tr><th>زمان</th><th>نوع</th><th>جزئیات</th></tr></thead><tbody>${activities.map((a) => `<tr><td>${a.created_at ? dateFormat.format(new Date(Number(a.created_at))) : '—'}</td><td>${escapeHtml(a.type || '—')}</td><td class="activity-data">${escapeHtml(JSON.stringify(a.data || {}))}</td></tr>`).join('')}</tbody></table></div>`;
}

function renderUserDetail(user) {
  const stats = user.stats || {};
  const daily = user.daily || {};
  const wheel = user.wheel || {};
  return `<div class="detail-header"><div class="detail-avatar">${initials(user.name)}</div><div><p class="eyebrow">USER PROFILE</p><h2>${escapeHtml(user.name)}</h2><p class="muted">${escapeHtml(user.email)} • ${escapeHtml(user.id)}</p></div><span class="status ${user.online ? 'online' : 'offline'}">${user.online ? 'آنلاین' : 'آفلاین'}</span></div>
    <div class="detail-grid"><div><span>کشور</span><strong>${escapeHtml(user.countryCode)}</strong></div><div><span>لیگ</span><strong>${escapeHtml(user.league)}</strong></div><div><span>کاپ</span><strong>${number(user.cups)}</strong></div><div><span>سکه</span><strong id="detailCoins">${number(user.coins)}</strong></div><div><span>برد</span><strong>${number(stats.wins)}</strong></div><div><span>باخت</span><strong>${number(stats.losses)}</strong></div><div><span>مسابقات</span><strong>${number(stats.matchesPlayed)}</strong></div><div><span>آخرین فعالیت</span><strong class="small-value">${user.lastSeenAt ? dateFormat.format(new Date(user.lastSeenAt)) : '—'}</strong></div><div><span>آواتار فعال</span><strong>${escapeHtml(user.avatarKey || 'guest')}</strong></div><div><span>دیوار فعال</span><strong>${escapeHtml(user.wallSkinKey || 'classic')}</strong></div><div><span>آواتارهای خریداری‌شده</span><strong>${number((user.ownedAvatars || []).length)}</strong></div><div><span>دیوارهای خریداری‌شده</span><strong>${number((user.ownedWalls || []).length)}</strong></div><div><span>ثبت‌نام</span><strong class="small-value">${user.createdAt ? dateFormat.format(new Date(user.createdAt)) : '—'}</strong></div><div><span>بازی واقعی</span><strong>${number(stats.realMatches)}</strong></div><div><span>بازی با ربات</span><strong>${number(stats.botMatches)}</strong></div><div><span>شناسه حساب</span><strong class="small-value">${escapeHtml(user.id)}</strong></div></div>
    <section class="adjust-box"><h3>افزایش یا کاهش سکه</h3><div class="adjust-controls"><input id="coinAmount" type="number" min="1" step="1" placeholder="مقدار سکه"><input id="coinNote" maxlength="200" placeholder="دلیل تغییر"><button id="addCoinsButton" class="success" type="button">افزایش سکه</button><button id="removeCoinsButton" class="danger" type="button">کاهش سکه</button></div><p id="coinActionMessage" class="muted"></p></section>
    <div class="detail-grid"><div><span>روز پاداش</span><strong>${number(daily.day)}</strong></div><div><span>زنجیره ورود</span><strong>${number(daily.streak)}</strong></div><div><span>پاداش امروز</span><strong>${daily.canClaim ? 'قابل دریافت' : 'دریافت‌شده'}</strong></div><div><span>گردونه</span><strong>${wheel.canSpin ? 'قابل چرخش' : 'در انتظار'}</strong></div></div>
    <h3 class="detail-section-title">آخرین تراکنش‌ها</h3>${transactionRows(Array.isArray(user.transactions) ? user.transactions : [])}
    <h3 class="detail-section-title">تاریخچه مسابقات</h3>${matchHistoryRows(Array.isArray(user.matchHistory) ? user.matchHistory : [])}
    <h3 class="detail-section-title">فعالیت‌های حساب</h3>${activityRows(Array.isArray(user.activities) ? user.activities : [])}`;
}

async function openUser(id) {
  if (!id) return;
  selectedUserId = id;
  $('userModal').classList.remove('hidden');
  $('userDetailContent').innerHTML = '<div class="detail-loading">در حال دریافت اطلاعات…</div>';
  try {
    const payload = await request(`/admin_user_detail.php?id=${encodeURIComponent(id)}`, { headers: authHeaders() });
    $('userDetailContent').innerHTML = renderUserDetail(payload.user || {});
    $('addCoinsButton').addEventListener('click', () => adjustCoins(1));
    $('removeCoinsButton').addEventListener('click', () => adjustCoins(-1));
  } catch (error) {
    $('userDetailContent').innerHTML = `<p class="error-text">${escapeHtml(error.message)}</p>`;
  }
}

async function adjustCoins(direction) {
  const amount = Math.abs(Number($('coinAmount').value) || 0);
  const note = $('coinNote').value.trim() || 'تغییر موجودی توسط مدیر';
  if (!selectedUserId || amount <= 0) { $('coinActionMessage').textContent = 'مقدار معتبر وارد کنید.'; return; }
  const action = direction > 0 ? 'افزایش' : 'کاهش';
  if (!window.confirm(`${action} ${number(amount)} سکه برای این کاربر انجام شود؟`)) return;
  $('addCoinsButton').disabled = true; $('removeCoinsButton').disabled = true;
  const unique = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  try {
    const payload = await request('/admin_adjust_coins.php', {
      method: 'POST', headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ accountId: selectedUserId, amount: direction * amount, note, requestId: `admin-${unique}` }),
    });
    $('coinActionMessage').textContent = `موجودی جدید: ${number(payload.user.coins)} سکه`;
    await openUser(selectedUserId); await loadUsers(); await loadDashboard();
  } catch (error) {
    $('coinActionMessage').textContent = error.message;
  } finally {
    if ($('addCoinsButton')) $('addCoinsButton').disabled = false;
    if ($('removeCoinsButton')) $('removeCoinsButton').disabled = false;
  }
}

function closeUserModal() { selectedUserId = null; $('userModal').classList.add('hidden'); }

async function navigate(section) {
  if (!sectionTitles[section]) section = 'dashboard';
  currentSection = section;
  document.querySelectorAll('.page-section').forEach((el) => el.classList.add('hidden'));
  $(`${section}Section`).classList.remove('hidden');
  document.querySelectorAll('.side-link').forEach((el) => el.classList.toggle('active', el.dataset.section === section));
  $('pageTitle').textContent = sectionTitles[section];
  closeSidebar();
  history.replaceState(null, '', `#${section}`);
  if (section === 'dashboard') await loadDashboard();
  if (section === 'users') await loadUsers();
  if (section === 'matches') await loadMatches();
  if (section === 'transactions') await loadTransactions();
  if (section === 'economy') await loadEconomy();
  if (section === 'settings') await loadSettings();
}

async function refreshCurrent() {
  $('refreshButton').disabled = true;
  try { await navigate(currentSection); } finally { $('refreshButton').disabled = false; }
}

async function login(event) {
  event.preventDefault();
  $('loginError').textContent = '';
  const button = event.currentTarget.querySelector('button');
  button.disabled = true;
  try {
    const payload = await request('/admin_login.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: $('username').value.trim(), password: $('password').value }) });
    token = payload.token; localStorage.setItem('marzband_admin_token', token); showApp();
    await navigate(location.hash.slice(1) || 'dashboard');
    clearInterval(refreshTimer); refreshTimer = setInterval(loadDashboard, 10000);
  } catch (error) { $('loginError').textContent = error.message; } finally { button.disabled = false; }
}
function logout() { token = ''; localStorage.removeItem('marzband_admin_token'); clearInterval(refreshTimer); closeUserModal(); closeSidebar(); showLogin(); }

$('loginForm').addEventListener('submit', login);
$('menuButton').addEventListener('click', openSidebar);
$('closeSidebar').addEventListener('click', closeSidebar);
$('sidebarBackdrop').addEventListener('click', closeSidebar);
$('refreshButton').addEventListener('click', refreshCurrent);
$('logoutButton').addEventListener('click', logout);
document.querySelectorAll('.side-link').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.section)));
$('searchUsersButton').addEventListener('click', loadUsers);
$('userSearch').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadUsers(); });
$('leagueFilter').addEventListener('change', loadUsers);
$('onlineFilter').addEventListener('change', loadUsers);
$('usersGrid').addEventListener('click', (event) => { const button = event.target.closest('[data-user-id]'); if (button) openUser(button.dataset.userId); });
$('searchTransactionsButton').addEventListener('click', loadTransactions);
$('transactionSearch').addEventListener('keydown', (event) => { if (event.key === 'Enter') loadTransactions(); });
$('transactionType').addEventListener('change', loadTransactions);
$('closeUserModal').addEventListener('click', closeUserModal);
document.querySelectorAll('[data-close-modal]').forEach((element) => element.addEventListener('click', closeUserModal));
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') { if (!$('userModal').classList.contains('hidden')) closeUserModal(); else closeSidebar(); } });
window.addEventListener('hashchange', () => { if (token) navigate(location.hash.slice(1) || 'dashboard'); });

if (token) {
  showApp();
  navigate(location.hash.slice(1) || 'dashboard');
  refreshTimer = setInterval(loadDashboard, 10000);
} else {
  showLogin();
}
