# Marzband dual-language Flutter source 1.9.0+23

This repository-ready package contains two synchronized Flutter variants:

- `apps/english`: English/LTR, Android label `Wallfront`
- `apps/persian`: Persian/RTL, Android label `مرزبند`

Shared properties:

- Package Name: `mk.kadkhodai.marzband`
- Backend: `https://persian-melody.ir/marzband/api`
- Backend version: PHP `1.5.0`
- Version: `1.9.0+23`
- Same game logic, account, economy, leagues and matchmaking
- Same release keystore

## GitHub output

Extract this ZIP and upload its contents to the root of a GitHub repository.
Run `Build Marzband EN APK-AAB and FA APK` from Actions.

A successful run creates exactly three release artifacts:

1. English APK
2. English AAB
3. Persian APK

Failure diagnostics are uploaded only when a job fails.
