import 'dart:convert';

import 'package:flutter/services.dart';

import '../config/network_config.dart';
import 'network_status.dart';

class ApiClientException implements Exception {
  const ApiClientException({
    required this.message,
    this.code,
    this.statusCode,
  });

  final String message;
  final String? code;
  final int? statusCode;

  @override
  String toString() => message;
}

abstract final class ApiClient {
  static const MethodChannel _channel = MethodChannel(
    'mk.kadkhodai.marzband/storage',
  );

  static Future<Map<String, Object?>> post(
    String path,
    Map<String, Object?> body, {
    Duration? timeout,
  }) async {
    final uri = Uri.parse('${NetworkConfig.apiBase}$path');
    try {
      final result = await _channel.invokeMapMethod<String, Object?>(
        'httpPostJson',
        <String, Object?>{
          'url': uri.toString(),
          'body': jsonEncode(body),
          'timeoutMs': (timeout ?? NetworkConfig.connectionTimeout).inMilliseconds,
        },
      );
      final statusCode = (result?['statusCode'] as num?)?.toInt() ?? 0;
      final responseText = result?['body'] as String? ?? '';
      Object? decoded;
      try {
        decoded = jsonDecode(responseText.isEmpty ? '{}' : responseText);
      } on FormatException {
        throw ApiClientException(
          message: 'پاسخ سرور نامعتبر است.',
          code: 'invalid_response',
          statusCode: statusCode,
        );
      }
      final payload = decoded is Map<Object?, Object?>
          ? decoded.cast<String, Object?>()
          : <String, Object?>{};
      if (statusCode < 200 || statusCode >= 300 || payload['ok'] == false) {
        final code = payload['error'] as String?;
        throw ApiClientException(
          message: _messageForCode(code, statusCode),
          code: code,
          statusCode: statusCode,
        );
      }
      return payload;
    } on ApiClientException {
      rethrow;
    } on PlatformException catch (error) {
      throw ApiClientException(
        message: NetworkStatus.instance.isOnline
            ? 'دسترسی به سرور بازی ممکن نیست.'
            : 'اتصال اینترنت برقرار نیست',
        code: error.code,
      );
    } catch (_) {
      throw ApiClientException(
        message: NetworkStatus.instance.isOnline
            ? 'دسترسی به سرور بازی ممکن نیست.'
            : 'اتصال اینترنت برقرار نیست',
        code: 'network_error',
      );
    }
  }

  static String _messageForCode(String? code, int statusCode) {
    switch (code) {
      case 'authentication_required':
        return 'نشست حساب شما منقضی شده است؛ دوباره وارد شوید.';
      case 'invalid_credentials':
        return 'ایمیل یا رمز عبور نادرست است.';
      case 'email_already_registered':
        return 'این ایمیل قبلاً ثبت شده است؛ وارد حساب شوید.';
      case 'invalid_name':
        return 'یک نام معتبر برای بازیکن وارد کنید.';
      case 'invalid_email':
        return 'یک ایمیل معتبر وارد کنید.';
      case 'weak_password':
        return 'رمز عبور باید حداقل ۸ نویسه داشته باشد.';
      case 'account_not_found':
        return 'حسابی با این ایمیل پیدا نشد.';
      case 'invalid_recovery_code':
        return 'کد بازیابی اشتباه یا منقضی شده است.';
      case 'account_already_in_match':
        return 'این حساب هم‌اکنون یک مسابقه فعال دارد.';
      case 'daily_already_claimed':
        return 'پاداش روزانه امروز قبلاً دریافت شده است.';
      case 'wheel_cooldown':
        return 'زمان انتظار گردونه هنوز تمام نشده است.';
      case 'not_enough_coins':
      case 'insufficient_balance':
        return 'سکه کافی برای این عملیات وجود ندارد.';
      case 'item_not_owned':
        return 'این مورد در مالکیت حساب نیست.';
      case 'invalid_item':
        return 'مورد انتخاب‌شده فروشگاه نامعتبر است.';
      case 'storage_unavailable':
      case 'storage_lock_unavailable':
        return 'فضای ذخیره‌سازی سرور بازی موقتاً در دسترس نیست.';
      default:
        if (statusCode == 404) return 'مسیر درخواستی روی سرور پیدا نشد.';
        if (statusCode >= 500) return 'سرور بازی موقتاً در دسترس نیست.';
        return code?.isNotEmpty == true ? code! : 'خطای سرور.';
    }
  }
}
