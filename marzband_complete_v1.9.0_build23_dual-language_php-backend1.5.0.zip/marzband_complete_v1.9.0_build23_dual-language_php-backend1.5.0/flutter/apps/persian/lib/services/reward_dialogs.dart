import 'package:flutter/material.dart';

import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import 'rewarded_ad_service.dart';

enum _RewardChoice { normal, doubleReward }

abstract final class RewardDialogs {
  static Future<int> showDailyReward(
    BuildContext context,
    PlayerPreferences preferences,
  ) async {
    while (context.mounted && preferences.hasPendingDailyReward) {
      final day = preferences.pendingDailyRewardDay;
      final coins = preferences.pendingDailyRewardCoins;
      final choice = await showDialog<_RewardChoice>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.calendar_month_rounded, color: AppColors.gold, size: 42),
          title: Text('پاداش ورود روز $day'),
          content: Text(
            '$coins سکه آماده است؛ اکنون دریافت کنید یا با مشاهده کامل ویدئو آن را دوبرابر کنید.',
            textAlign: TextAlign.center,
            style: const TextStyle(height: 1.6),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.normal),
              child: Text('دریافت $coins سکه'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.doubleReward),
              icon: const Icon(Icons.ondemand_video_rounded),
              label: Text('دوبرابر: ${coins * 2}'),
            ),
          ],
        ),
      );
      if (choice == _RewardChoice.normal) return preferences.claimDailyReward();
      if (choice == _RewardChoice.doubleReward) {
        final rewarded = await RewardedAdService.show(context);
        if (!context.mounted) return 0;
        if (rewarded) return preferences.claimDailyReward(doubled: true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ویدئو کامل دیده نشد؛ پاداش اصلی همچنان قابل دریافت است.')),
        );
      }
    }
    return 0;
  }

  static Future<int> showWheelReward(
    BuildContext context,
    PlayerPreferences preferences,
  ) async {
    while (context.mounted && preferences.pendingWheelPrize > 0) {
      final coins = preferences.pendingWheelPrize;
      final choice = await showDialog<_RewardChoice>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.casino_rounded, color: AppColors.purple, size: 42),
          title: const Text('پاداش گردونه'),
          content: Text(
            'گردونه روی $coins سکه ایستاد؛ اکنون دریافت کنید یا با مشاهده کامل ویدئو آن را دوبرابر کنید.',
            textAlign: TextAlign.center,
            style: const TextStyle(height: 1.6),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.normal),
              child: Text('دریافت $coins'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.doubleReward),
              icon: const Icon(Icons.ondemand_video_rounded),
              label: Text('دوبرابر: ${coins * 2}'),
            ),
          ],
        ),
      );
      if (choice == _RewardChoice.normal) return preferences.claimWheelPrize();
      if (choice == _RewardChoice.doubleReward) {
        final rewarded = await RewardedAdService.show(context);
        if (!context.mounted) return 0;
        if (rewarded) return preferences.claimWheelPrize(doubled: true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ویدئو کامل دیده نشد؛ پاداش گردونه همچنان قابل دریافت است.')),
        );
      }
    }
    return 0;
  }
}
