import 'package:flutter/material.dart';

import '../models/game_history.dart';
import '../models/game_models.dart';
import '../state/game_history_store.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/player_avatar.dart';
import 'replay_screen.dart';

class MatchHistoryScreen extends StatelessWidget {
  const MatchHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = GameHistoryStore.instance;
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('تاریخچه مسابقات'),
          leading: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          actions: <Widget>[
            IconButton(
              tooltip: 'حذف همه',
              onPressed: store.entries.isEmpty
                  ? null
                  : () => _confirmClear(context, store),
              icon: const Icon(Icons.delete_sweep_outlined),
            ),
          ],
        ),
        body: AnimatedBuilder(
          animation: store,
          builder: (context, _) {
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: <Widget>[
                Card(
                  child: SwitchListTile(
                    value: store.enabled,
                    onChanged: store.setEnabled,
                    title: const Text(
                      'ذخیره تاریخچه مسابقات',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: const Text(
                      'فقط اطلاعات فشرده ۲۰ مسابقه اخیر ذخیره می‌شود و هیچ فایل ویدئویی نگهداری نمی‌شود.',
                    ),
                    secondary: const Icon(
                      Icons.history_rounded,
                      color: AppColors.cyan,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                if (store.entries.isEmpty)
                  const _EmptyHistory()
                else
                  for (final entry in store.entries)
                    _HistoryTile(
                      entry: entry,
                      onOpen: () {
                        Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => ReplayScreen(entry: entry),
                          ),
                        );
                      },
                      onDelete: () => store.delete(entry.id),
                    ),
              ],
            );
          },
        ),
      ),
    );
  }

  Future<void> _confirmClear(
    BuildContext context,
    GameHistoryStore store,
  ) async {
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('همه تاریخچه حذف شود؟'),
            content: const Text('این عملیات قابل بازگشت نیست.'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('انصراف'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('حذف'),
              ),
            ],
          ),
        ) ??
        false;
    if (confirmed) await store.clear();
  }
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({
    required this.entry,
    required this.onOpen,
    required this.onDelete,
  });

  final GameHistoryEntry entry;
  final VoidCallback onOpen;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final resultColor = entry.didPlayerWin ? const Color(0xFF55D98A) : AppColors.red;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
          child: Row(
            children: <Widget>[
              Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  PlayerAvatar(
                    avatar: PlayerPreferences.instance.avatarChoice,
                    size: 48,
                  ),
                  Positioned(
                    right: -3,
                    bottom: -3,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        color: resultColor,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.surface, width: 2),
                      ),
                      child: Icon(
                        entry.didPlayerWin
                            ? Icons.check_rounded
                            : Icons.close_rounded,
                        color: Colors.white,
                        size: 13,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '${entry.didPlayerWin ? 'برد' : 'باخت'} مقابل ${entry.opponentName}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${_modeLabel(entry.mode)} • ${entry.moves.length} حرکت • ${_duration(entry.durationSeconds)}',
                      style: const TextStyle(color: AppColors.muted, fontSize: 12),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      _date(entry.playedAt),
                      style: const TextStyle(color: AppColors.muted, fontSize: 11),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'حذف',
                onPressed: onDelete,
                icon: const Icon(Icons.delete_outline_rounded),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }

  static String _modeLabel(GameMode mode) {
    return switch (mode) {
      GameMode.local => 'دونفره محلی',
      GameMode.bot => 'بازی با ربات',
      GameMode.ranked => 'مسابقه رتبه‌ای',
    };
  }

  static String _duration(int seconds) {
    final minutes = seconds ~/ 60;
    final rest = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${rest.toString().padLeft(2, '0')}';
  }

  static String _date(DateTime date) {
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}  ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }
}

class _EmptyHistory extends StatelessWidget {
  const _EmptyHistory();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 60),
      child: Column(
        children: const <Widget>[
          Icon(Icons.history_toggle_off_rounded, size: 68, color: AppColors.muted),
          SizedBox(height: 14),
          Text(
            'هنوز مسابقه‌ای ثبت نشده است.',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
          ),
          SizedBox(height: 6),
          Text(
            'مسابقات پایان‌یافته با داده فشرده بازپخش در اینجا نمایش داده می‌شوند.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.muted, height: 1.6),
          ),
        ],
      ),
    );
  }
}
