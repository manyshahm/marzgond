import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/game_models.dart';
import '../network/online_game_service.dart';
import '../services/network_status.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/neon_background.dart';
import '../widgets/player_avatar.dart';
import 'online_game_screen.dart';

class MatchmakingScreen extends StatefulWidget {
  const MatchmakingScreen({super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen>
    with SingleTickerProviderStateMixin {
  static const int _searchSeconds = 5;

  final PlayerPreferences _preferences = PlayerPreferences.instance;
  final OnlineGameService _onlineService = OnlineGameService.instance;

  Timer? _timer;
  late final AnimationController _controller;
  int _elapsed = 0;
  bool _starting = false;
  bool _cancelled = false;
  String? _error;
  bool _online = NetworkStatus.instance.isOnline;

  @override
  void initState() {
    super.initState();
    NetworkStatus.instance.addListener(_onNetworkChanged);
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1900),
    )..repeat();
    _beginSearch();
  }


  void _onNetworkChanged() {
    if (!mounted) return;
    final online = NetworkStatus.instance.isOnline;
    setState(() {
      _online = online;
      if (!online) _error = 'اتصال اینترنت برقرار نیست';
    });
    if (!online && !_starting) {
      _timer?.cancel();
      _onlineService.cancelMatchmaking();
    }
  }

  String _friendlyError(String message) {
    if (!NetworkStatus.instance.isOnline) return 'اتصال اینترنت برقرار نیست';
    final lower = message.toLowerCase();
    if (lower.contains('failed to connect') ||
        lower.contains('unable to reach') ||
        lower.contains('connection') ||
        lower.contains('socket') ||
        lower.contains(':443')) {
      return 'دسترسی به سرور بازی ممکن نیست.';
    }
    return message;
  }

  Future<void> _beginSearch() async {
    _timer?.cancel();
    setState(() {
      _elapsed = 0;
      _error = null;
      _starting = false;
      _cancelled = false;
    });
    _online = NetworkStatus.instance.isOnline;
    if (!_online) {
      setState(() => _error = 'اتصال اینترنت برقرار نیست');
      return;
    }
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || _starting || _cancelled) return;
      setState(() => _elapsed = (_elapsed + 1).clamp(0, 99) as int);
    });

    try {
      final session = await _onlineService.findMatch();
      if (!mounted || _cancelled) return;
      _timer?.cancel();
      setState(() => _starting = true);
      await Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => OnlineGameScreen(
            mode: GameMode.ranked,
            session: session,
            botDifficulty: BotDifficulty.hard,
            opponentName: session.opponent.name,
            opponentCups: session.opponent.cups,
            opponentCountryCode: session.opponent.countryCode,
          ),
        ),
      );
    } on OnlineGameException catch (error) {
      if (!mounted || _cancelled) return;
      _timer?.cancel();
      setState(() => _error = _friendlyError(error.message));
    } catch (_) {
      if (!mounted || _cancelled) return;
      _timer?.cancel();
      setState(() => _error = _online ? 'دسترسی به سرور بازی ممکن نیست.' : 'اتصال اینترنت برقرار نیست');
    }
  }

  @override
  void dispose() {
    _cancelled = true;
    _timer?.cancel();
    NetworkStatus.instance.removeListener(_onNetworkChanged);
    _controller.dispose();
    if (!_starting) _onlineService.cancelMatchmaking();
    super.dispose();
  }

  void _cancel() {
    if (_starting) return;
    _cancelled = true;
    _timer?.cancel();
    _onlineService.cancelMatchmaking();
    Navigator.of(context).maybePop();
  }

  @override
  Widget build(BuildContext context) {
    final seconds = _elapsed.clamp(0, _searchSeconds);
    return PopScope(
      canPop: true,
      child: Scaffold(
        body: NeonBackground(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 22, 24, 34),
              child: Column(
                children: <Widget>[
                  const Spacer(flex: 2),
                  Stack(
                    alignment: Alignment.center,
                    children: <Widget>[
                      RotationTransition(
                        turns: _controller,
                        child: SizedBox.square(
                          dimension: 154,
                          child: CustomPaint(painter: _SearchRingPainter()),
                        ),
                      ),
                      PlayerAvatar(
                        avatar: _preferences.avatarChoice,
                        size: 78,
                        selected: true,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    '$seconds ثانیه',
                    style: const TextStyle(
                      fontSize: 29,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 17),
                  Text(
                    _error ?? 'در حال پیدا کردن حریف…',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _error == null ? AppColors.text : AppColors.red,
                      fontSize: _error == null ? 25 : 17,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(flex: 2),
                  if (_error != null) ...<Widget>[
                    SizedBox(
                      width: 260,
                      height: 52,
                      child: FilledButton.icon(
                        onPressed: _online ? _beginSearch : null,
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text(
                          'جست‌وجوی دوباره',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  _CancelSearchButton(
                    enabled: !_starting,
                    onPressed: _cancel,
                  ),
                  const Spacer(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CancelSearchButton extends StatefulWidget {
  const _CancelSearchButton({
    required this.enabled,
    required this.onPressed,
  });

  final bool enabled;
  final VoidCallback onPressed;

  @override
  State<_CancelSearchButton> createState() => _CancelSearchButtonState();
}

class _CancelSearchButtonState extends State<_CancelSearchButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.enabled ? widget.onPressed : null,
      onTapDown: widget.enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: widget.enabled ? (_) => setState(() => _pressed = false) : null,
      onTapCancel: widget.enabled ? () => setState(() => _pressed = false) : null,
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1,
        duration: const Duration(milliseconds: 110),
        child: Container(
          width: 252,
          height: 54,
          padding: const EdgeInsets.all(1.4),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: <Color>[
                AppColors.cyan,
                AppColors.purple,
                AppColors.orange,
              ],
            ),
            borderRadius: BorderRadius.circular(19),
            boxShadow: const <BoxShadow>[
              BoxShadow(
                color: Color(0x4433D5FF),
                blurRadius: 18,
                offset: Offset(0, 7),
              ),
            ],
          ),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xF00B1423),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  width: 29,
                  height: 29,
                  decoration: BoxDecoration(
                    color: AppColors.red.withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.close_rounded,
                    color: AppColors.red,
                    size: 19,
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'لغو جست‌وجو',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SearchRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.shortestSide / 2 - 8;
    final rect = Rect.fromCircle(center: center, radius: radius);
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = const Color(0xFF16253A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 12,
    );
    canvas.drawArc(
      rect,
      -math.pi / 2,
      math.pi * 2,
      false,
      Paint()
        ..shader = const SweepGradient(
          colors: <Color>[
            Color(0xFF2D7DFF),
            Color(0xFF25D9FF),
            Color(0xFF31E6A1),
            Color(0xFFFFD34E),
            Color(0xFFFF8B42),
            Color(0xFFFF4F8B),
            Color(0xFF9B6CFF),
            Color(0xFF2D7DFF),
          ],
        ).createShader(Offset.zero & size)
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 12,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
