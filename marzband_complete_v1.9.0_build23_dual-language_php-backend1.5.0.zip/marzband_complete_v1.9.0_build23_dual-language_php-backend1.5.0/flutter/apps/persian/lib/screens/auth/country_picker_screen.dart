import 'package:flutter/material.dart';

import '../../models/country.dart';
import '../../theme/app_theme.dart';

class CountryPickerScreen extends StatefulWidget {
  const CountryPickerScreen({super.key});

  @override
  State<CountryPickerScreen> createState() => _CountryPickerScreenState();
}

class _CountryPickerScreenState extends State<CountryPickerScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  bool _allowPop = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final normalized = _query.trim().toLowerCase();
    final countries = normalized.isEmpty
        ? Countries.all
        : Countries.all.where((country) {
            return country.name.toLowerCase().contains(normalized) ||
                country.code.toLowerCase().contains(normalized);
          }).toList(growable: false);

    return PopScope(
      canPop: _allowPop,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('انتخاب کشور'),
          leading: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
              child: TextField(
                controller: _searchController,
                onChanged: (value) => setState(() => _query = value),
                decoration: const InputDecoration(
                  hintText: 'جست‌وجوی کشورها',
                  prefixIcon: Icon(Icons.search_rounded),
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Expanded(
              child: ListView.separated(
                itemCount: countries.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final country = countries[index];
                  return ListTile(
                    onTap: () async {
                      setState(() => _allowPop = true);
                      await WidgetsBinding.instance.endOfFrame;
                      if (context.mounted) Navigator.of(context).pop(country);
                    },
                    leading: Text(country.flag, style: const TextStyle(fontSize: 27)),
                    title: Text(country.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                    trailing: Text(country.code, style: const TextStyle(color: AppColors.muted)),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
