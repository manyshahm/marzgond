import 'package:flutter/foundation.dart';

enum Player { blue, red }

enum GameMode { local, bot, ranked }

enum BotDifficulty { easy, normal, hard, extreme }

enum WallOrientation { horizontal, vertical }

@immutable
class Cell {
  const Cell(this.row, this.col);

  final int row;
  final int col;

  Cell translate(int dr, int dc) => Cell(row + dr, col + dc);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Cell && row == other.row && col == other.col;

  @override
  int get hashCode => Object.hash(row, col);

  @override
  String toString() => 'Cell($row,$col)';
}

@immutable
class Wall {
  const Wall({
    required this.row,
    required this.col,
    required this.orientation,
    required this.owner,
  });

  final int row;
  final int col;
  final WallOrientation orientation;
  final Player owner;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Wall &&
          row == other.row &&
          col == other.col &&
          orientation == other.orientation;

  @override
  int get hashCode => Object.hash(row, col, orientation);
}

@immutable
class MoveRecord {
  const MoveRecord.move({
    required this.player,
    required this.from,
    required this.to,
  })  : wall = null,
        isWall = false;

  const MoveRecord.wall({
    required this.player,
    required this.wall,
  })  : from = null,
        to = null,
        isWall = true;

  final Player player;
  final bool isWall;
  final Cell? from;
  final Cell? to;
  final Wall? wall;
}

extension PlayerUi on Player {
  String get label => this == Player.blue ? 'بازیکن اول' : 'بازیکن دوم';
  Player get opponent => this == Player.blue ? Player.red : Player.blue;
}

extension BotDifficultyUi on BotDifficulty {
  String get label {
    switch (this) {
      case BotDifficulty.easy:
        return 'آسان';
      case BotDifficulty.normal:
        return 'معمولی';
      case BotDifficulty.hard:
        return 'سخت';
      case BotDifficulty.extreme:
        return 'فوق‌سخت';
    }
  }

  String get description {
    switch (this) {
      case BotDifficulty.easy:
        return 'منطقی و قابل شکست با عمق جست‌وجوی محدود.';
      case BotDifficulty.normal:
        return 'پیش‌بینی پیشرفته و تحلیل مؤثر دیوارها.';
      case BotDifficulty.hard:
        return 'موتور کامل چندحرکتی با تنوع کنترل‌شده.';
      case BotDifficulty.extreme:
        return 'بیشترین قدرت موتور در محدوده زمانی.';
    }
  }
}
