import '../models/game_models.dart';

class GameHistoryEntry {
  const GameHistoryEntry({
    required this.id,
    required this.playedAt,
    required this.mode,
    required this.opponentName,
    required this.opponentCups,
    required this.winner,
    required this.finishReason,
    required this.durationSeconds,
    required this.cupBefore,
    required this.cupDelta,
    required this.cupAfter,
    required this.botDifficulty,
    required this.moves,
  });

  final String id;
  final DateTime playedAt;
  final GameMode mode;
  final String opponentName;
  final int? opponentCups;
  final Player winner;
  final String finishReason;
  final int durationSeconds;
  final int? cupBefore;
  final int? cupDelta;
  final int? cupAfter;
  final BotDifficulty? botDifficulty;
  final List<MoveRecord> moves;

  bool get didPlayerWin => winner == Player.blue;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'id': id,
      'playedAt': playedAt.toIso8601String(),
      'mode': mode.index,
      'opponentName': opponentName,
      'opponentCups': opponentCups,
      'winner': winner.index,
      'finishReason': finishReason,
      'durationSeconds': durationSeconds,
      'cupBefore': cupBefore,
      'cupDelta': cupDelta,
      'cupAfter': cupAfter,
      'botDifficulty': botDifficulty?.index,
      'moves': moves.map(_moveToJson).toList(growable: false),
    };
  }

  factory GameHistoryEntry.fromJson(Map<String, Object?> json) {
    final rawMoves = (json['moves'] as List<Object?>? ?? const <Object?>[]);
    return GameHistoryEntry(
      id: json['id'] as String? ?? '',
      playedAt: DateTime.tryParse(json['playedAt'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
      mode: GameMode.values[((json['mode'] as num? ?? 0).toInt().clamp(
            0,
            GameMode.values.length - 1,
          )) as int],
      opponentName: json['opponentName'] as String? ?? 'حریف',
      opponentCups: (json['opponentCups'] as num?)?.toInt(),
      winner: Player.values[((json['winner'] as num? ?? 0).toInt().clamp(
            0,
            Player.values.length - 1,
          )) as int],
      finishReason: json['finishReason'] as String? ?? 'مسابقه پایان یافت',
      durationSeconds: (json['durationSeconds'] as num? ?? 0).toInt(),
      cupBefore: (json['cupBefore'] as num?)?.toInt(),
      cupDelta: (json['cupDelta'] as num?)?.toInt(),
      cupAfter: (json['cupAfter'] as num?)?.toInt(),
      botDifficulty: json['botDifficulty'] == null
          ? null
          : BotDifficulty.values[((json['botDifficulty'] as num).toInt().clamp(
                    0,
                    BotDifficulty.values.length - 1,
                  )) as int],
      moves: rawMoves
          .whereType<Map<Object?, Object?>>()
          .map((item) => _moveFromJson(item.cast<String, Object?>()))
          .toList(growable: false),
    );
  }

  static Map<String, Object?> _moveToJson(MoveRecord move) {
    if (move.isWall) {
      final wall = move.wall!;
      return <String, Object?>{
        'type': 'wall',
        'player': move.player.index,
        'row': wall.row,
        'col': wall.col,
        'orientation': wall.orientation.index,
      };
    }
    return <String, Object?>{
      'type': 'move',
      'player': move.player.index,
      'fromRow': move.from!.row,
      'fromCol': move.from!.col,
      'toRow': move.to!.row,
      'toCol': move.to!.col,
    };
  }

  static MoveRecord _moveFromJson(Map<String, Object?> json) {
    final player = Player.values[((json['player'] as num? ?? 0).toInt().clamp(
          0,
          Player.values.length - 1,
        )) as int];
    if (json['type'] == 'wall') {
      final orientation = WallOrientation.values[((json['orientation'] as num? ?? 0).toInt().clamp(
              0,
              WallOrientation.values.length - 1,
            )) as int];
      return MoveRecord.wall(
        player: player,
        wall: Wall(
          row: (json['row'] as num? ?? 0).toInt(),
          col: (json['col'] as num? ?? 0).toInt(),
          orientation: orientation,
          owner: player,
        ),
      );
    }
    return MoveRecord.move(
      player: player,
      from: Cell(
        (json['fromRow'] as num? ?? 0).toInt(),
        (json['fromCol'] as num? ?? 0).toInt(),
      ),
      to: Cell(
        (json['toRow'] as num? ?? 0).toInt(),
        (json['toCol'] as num? ?? 0).toInt(),
      ),
    );
  }
}
