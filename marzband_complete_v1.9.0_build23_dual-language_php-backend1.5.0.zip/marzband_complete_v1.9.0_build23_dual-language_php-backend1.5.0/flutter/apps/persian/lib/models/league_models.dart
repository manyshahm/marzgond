import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class CupTier {
  const CupTier({
    required this.key,
    required this.name,
    required this.minimum,
    required this.maximum,
    required this.color,
    required this.assetPath,
    required this.subtitle,
    required this.winCups,
    required this.lossCups,
    required this.winCoins,
  });

  final String key;
  final String name;
  final int minimum;
  final int? maximum;
  final Color color;
  final String assetPath;
  final String subtitle;
  final int winCups;
  final int lossCups;
  final int winCoins;

  String get rangeLabel => maximum == null
      ? '$minimum+ کاپ'
      : '$minimum تا $maximum کاپ';

  bool contains(int cups) =>
      cups >= minimum && (maximum == null || cups <= maximum!);

  int progressValue(int cups) {
    if (!contains(cups)) return cups < minimum ? 0 : 100;
    if (maximum == null) return 100;
    final span = maximum! - minimum + 1;
    return (((cups - minimum) / span) * 100).clamp(0, 100).round();
  }

  int cupsToNext(int cups) {
    if (maximum == null) return 0;
    return (maximum! + 1 - cups).clamp(0, maximum! + 1) as int;
  }

  static const List<CupTier> all = <CupTier>[
    CupTier(
      key: 'bronze',
      name: 'برنزی',
      subtitle: 'آغاز مسیر پیشرفت',
      minimum: 0,
      maximum: 499,
      color: Color(0xFFC17B48),
      assetPath: 'assets/images/leagues/bronze.webp',
      winCups: 30,
      lossCups: 20,
      winCoins: 10,
    ),
    CupTier(
      key: 'silver',
      name: 'نقره‌ای',
      subtitle: 'استراتژی خود را تقویت کنید',
      minimum: 500,
      maximum: 1499,
      color: Color(0xFFB6C4D7),
      assetPath: 'assets/images/leagues/silver.webp',
      winCups: 27,
      lossCups: 23,
      winCoins: 20,
    ),
    CupTier(
      key: 'gold',
      name: 'طلایی',
      subtitle: 'میدان را کنترل کنید',
      minimum: 1500,
      maximum: 2499,
      color: AppColors.gold,
      assetPath: 'assets/images/leagues/gold.webp',
      winCups: 25,
      lossCups: 25,
      winCoins: 30,
    ),
    CupTier(
      key: 'diamond',
      name: 'الماس',
      subtitle: 'استادان برتر دیوار',
      minimum: 2500,
      maximum: 3999,
      color: AppColors.cyan,
      assetPath: 'assets/images/leagues/diamond.webp',
      winCups: 22,
      lossCups: 28,
      winCoins: 40,
    ),
    CupTier(
      key: 'legend',
      name: 'افسانه‌ای',
      subtitle: 'آخرین مرز',
      minimum: 4000,
      maximum: null,
      color: AppColors.purple,
      assetPath: 'assets/images/leagues/legend.webp',
      winCups: 20,
      lossCups: 30,
      winCoins: 50,
    ),
  ];

  static CupTier forCups(int cups) {
    return all.firstWhere(
      (tier) => tier.contains(cups),
      orElse: () => all.last,
    );
  }

  static CupTier byKey(String key) {
    return all.firstWhere(
      (tier) => tier.key == key.toLowerCase(),
      orElse: () => all.first,
    );
  }
}

class LeaderboardEntry {
  const LeaderboardEntry({
    required this.rank,
    required this.name,
    required this.cups,
    required this.isCurrentPlayer,
    required this.countryCode,
    this.avatarKey = 'guest',
  });

  final int rank;
  final String name;
  final int cups;
  final bool isCurrentPlayer;
  final String countryCode;
  final String avatarKey;

  factory LeaderboardEntry.fromMap(Map<String, Object?> map) {
    return LeaderboardEntry(
      rank: (map['rank'] as num? ?? 0).toInt(),
      name: map['name'] as String? ?? 'بازیکن',
      cups: (map['cups'] as num? ?? 0).toInt(),
      isCurrentPlayer: map['isCurrentPlayer'] == true,
      countryCode: map['countryCode'] as String? ?? 'IR',
      avatarKey: map['avatarKey'] as String? ?? 'guest',
    );
  }
}
