import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../config/economy_config.dart';
import '../services/api_client.dart';
import '../services/local_storage.dart';
import '../services/network_status.dart';
import 'auth_state.dart';
import '../theme/app_theme.dart';

enum AvatarChoice {
  guest,
  rookieBoy,
  rookieGirl,
  strategist,
  explorer,
  cyberSoldier,
  cyberGuardian,
  stormHero,
  warriorQueen,
  fireSage,
  arcaneQueen,
}

const List<AvatarChoice> storeAvatarChoices = <AvatarChoice>[
  AvatarChoice.rookieBoy,
  AvatarChoice.rookieGirl,
  AvatarChoice.strategist,
  AvatarChoice.explorer,
  AvatarChoice.cyberSoldier,
  AvatarChoice.cyberGuardian,
  AvatarChoice.stormHero,
  AvatarChoice.warriorQueen,
  AvatarChoice.fireSage,
  AvatarChoice.arcaneQueen,
];

extension AvatarChoiceUi on AvatarChoice {
  String get label {
    switch (this) {
      case AvatarChoice.guest:
        return 'پیش‌فرض';
      case AvatarChoice.rookieBoy:
        return 'پیشاهنگ تازه‌کار';
      case AvatarChoice.rookieGirl:
        return 'نگهبان تازه‌کار';
      case AvatarChoice.strategist:
        return 'استراتژیست جوان';
      case AvatarChoice.explorer:
        return 'کاوشگر مسیر';
      case AvatarChoice.cyberSoldier:
        return 'سرباز سایبری';
      case AvatarChoice.cyberGuardian:
        return 'نگهبان سایبری';
      case AvatarChoice.stormHero:
        return 'قهرمان طوفان';
      case AvatarChoice.warriorQueen:
        return 'ملکه جنگجو';
      case AvatarChoice.fireSage:
        return 'حکیم آتش';
      case AvatarChoice.arcaneQueen:
        return 'ملکه اسرار';
    }
  }

  int get price {
    switch (this) {
      case AvatarChoice.guest:
        return 0;
      case AvatarChoice.rookieBoy:
        return 1000;
      case AvatarChoice.rookieGirl:
        return 1500;
      case AvatarChoice.strategist:
        return 2500;
      case AvatarChoice.explorer:
        return 3500;
      case AvatarChoice.cyberSoldier:
        return 5000;
      case AvatarChoice.cyberGuardian:
        return 7000;
      case AvatarChoice.stormHero:
        return 9000;
      case AvatarChoice.warriorQueen:
        return 11000;
      case AvatarChoice.fireSage:
        return 13000;
      case AvatarChoice.arcaneQueen:
        return 15000;
    }
  }

  String get assetPath {
    switch (this) {
      case AvatarChoice.guest:
        return 'assets/images/home/default_profile.webp';
      case AvatarChoice.rookieBoy:
        return 'assets/images/avatars/avatar_01.webp';
      case AvatarChoice.rookieGirl:
        return 'assets/images/avatars/avatar_02.webp';
      case AvatarChoice.strategist:
        return 'assets/images/avatars/avatar_03.webp';
      case AvatarChoice.explorer:
        return 'assets/images/avatars/avatar_04.webp';
      case AvatarChoice.cyberSoldier:
        return 'assets/images/avatars/avatar_05.webp';
      case AvatarChoice.cyberGuardian:
        return 'assets/images/avatars/avatar_06.webp';
      case AvatarChoice.stormHero:
        return 'assets/images/avatars/avatar_07.webp';
      case AvatarChoice.warriorQueen:
        return 'assets/images/avatars/avatar_08.webp';
      case AvatarChoice.fireSage:
        return 'assets/images/avatars/avatar_09.webp';
      case AvatarChoice.arcaneQueen:
        return 'assets/images/avatars/avatar_10.webp';
    }
  }

  IconData get icon {
    switch (this) {
      case AvatarChoice.guest:
        return Icons.person_rounded;
      case AvatarChoice.rookieBoy:
      case AvatarChoice.rookieGirl:
        return Icons.explore_rounded;
      case AvatarChoice.strategist:
        return Icons.psychology_rounded;
      case AvatarChoice.explorer:
        return Icons.hiking_rounded;
      case AvatarChoice.cyberSoldier:
      case AvatarChoice.cyberGuardian:
        return Icons.security_rounded;
      case AvatarChoice.stormHero:
      case AvatarChoice.warriorQueen:
        return Icons.workspace_premium_rounded;
      case AvatarChoice.fireSage:
        return Icons.local_fire_department_rounded;
      case AvatarChoice.arcaneQueen:
        return Icons.auto_awesome_rounded;
    }
  }

  Color get accent {
    switch (this) {
      case AvatarChoice.guest:
        return AppColors.blue;
      case AvatarChoice.rookieBoy:
      case AvatarChoice.rookieGirl:
        return AppColors.cyan;
      case AvatarChoice.strategist:
      case AvatarChoice.explorer:
        return AppColors.gold;
      case AvatarChoice.cyberSoldier:
      case AvatarChoice.cyberGuardian:
        return AppColors.blue;
      case AvatarChoice.stormHero:
        return AppColors.orange;
      case AvatarChoice.warriorQueen:
        return AppColors.gold;
      case AvatarChoice.fireSage:
        return AppColors.orange;
      case AvatarChoice.arcaneQueen:
        return AppColors.purple;
    }
  }
}

enum WallSkinChoice {
  classic,
  ocean,
  flame,
  gold,
  cyber,
  emerald,
  frost,
  rose,
  shadow,
  plasma,
  crystal,
  silver,
}

extension WallSkinChoiceUi on WallSkinChoice {
  String get label {
    switch (this) {
      case WallSkinChoice.classic:
        return 'کلاسیک';
      case WallSkinChoice.ocean:
        return 'اقیانوس';
      case WallSkinChoice.flame:
        return 'شعله';
      case WallSkinChoice.gold:
        return 'طلایی';
      case WallSkinChoice.cyber:
        return 'سایبری';
      case WallSkinChoice.emerald:
        return 'زمرد';
      case WallSkinChoice.frost:
        return 'یخی';
      case WallSkinChoice.rose:
        return 'رز';
      case WallSkinChoice.shadow:
        return 'سایه';
      case WallSkinChoice.plasma:
        return 'پلاسما';
      case WallSkinChoice.crystal:
        return 'کریستال';
      case WallSkinChoice.silver:
        return 'نقره‌ای';
    }
  }

  int get price {
    switch (this) {
      case WallSkinChoice.classic:
        return 0;
      case WallSkinChoice.ocean:
        return 500;
      case WallSkinChoice.flame:
        return 800;
      case WallSkinChoice.gold:
        return 1250;
      case WallSkinChoice.cyber:
        return 1750;
      case WallSkinChoice.emerald:
        return 2200;
      case WallSkinChoice.frost:
        return 2600;
      case WallSkinChoice.rose:
        return 3000;
      case WallSkinChoice.shadow:
        return 3500;
      case WallSkinChoice.plasma:
        return 4200;
      case WallSkinChoice.crystal:
        return 5000;
      case WallSkinChoice.silver:
        return 6000;
    }
  }

  List<Color> get gradientColors {
    switch (this) {
      case WallSkinChoice.classic:
        return const <Color>[Color(0xFF16A8FF), Color(0xFF0D7EDC)];
      case WallSkinChoice.ocean:
        return const <Color>[Color(0xFF35E4FF), Color(0xFF0873D1)];
      case WallSkinChoice.flame:
        return const <Color>[Color(0xFFFFB13B), Color(0xFFFF3B4D)];
      case WallSkinChoice.gold:
        return const <Color>[Color(0xFFFFE07A), Color(0xFFFF9A24)];
      case WallSkinChoice.cyber:
        return const <Color>[Color(0xFF8C66D9), Color(0xFF35E4FF)];
      case WallSkinChoice.emerald:
        return const <Color>[Color(0xFF31E879), Color(0xFF069B72)];
      case WallSkinChoice.frost:
        return const <Color>[Color(0xFFEAF8FF), Color(0xFF5DBDFF)];
      case WallSkinChoice.rose:
        return const <Color>[Color(0xFFFF79C9), Color(0xFFB949FF)];
      case WallSkinChoice.shadow:
        return const <Color>[Color(0xFF63708B), Color(0xFF171D2B)];
      case WallSkinChoice.plasma:
        return const <Color>[Color(0xFFFF4BD8), Color(0xFF5B63FF), Color(0xFF35E4FF)];
      case WallSkinChoice.crystal:
        return const <Color>[Color(0xFFD7F7FF), Color(0xFF6EEBFF), Color(0xFF9275FF)];
      case WallSkinChoice.silver:
        return const <Color>[Color(0xFFF3F6FA), Color(0xFF9EADBF), Color(0xFF566579)];
    }
  }

  List<Color> get opponentGradientColors {
    switch (this) {
      case WallSkinChoice.classic:
        return const <Color>[Color(0xFFFF7A24), Color(0xFFFF3B4D)];
      case WallSkinChoice.ocean:
        return const <Color>[Color(0xFFFF5D78), Color(0xFFFF934D)];
      case WallSkinChoice.flame:
        return const <Color>[Color(0xFF16A8FF), Color(0xFF35E4FF)];
      case WallSkinChoice.gold:
        return const <Color>[Color(0xFF9E6BFF), Color(0xFF6F3DDB)];
      case WallSkinChoice.cyber:
        return const <Color>[Color(0xFF35E4FF), Color(0xFF16A8FF)];
      case WallSkinChoice.emerald:
        return const <Color>[Color(0xFFFFB13B), Color(0xFFFF7A24)];
      case WallSkinChoice.frost:
        return const <Color>[Color(0xFFFF769B), Color(0xFFFF3B4D)];
      case WallSkinChoice.rose:
        return const <Color>[Color(0xFF35E4FF), Color(0xFF16A8FF)];
      case WallSkinChoice.shadow:
        return const <Color>[Color(0xFFFF7A24), Color(0xFFFFB13B)];
      case WallSkinChoice.plasma:
        return const <Color>[Color(0xFFFFB13B), Color(0xFFFF3B4D), Color(0xFFFF4BD8)];
      case WallSkinChoice.crystal:
        return const <Color>[Color(0xFFFFC86B), Color(0xFFFF7A24), Color(0xFFFF4B78)];
      case WallSkinChoice.silver:
        return const <Color>[Color(0xFFFF7A24), Color(0xFFB56A2F), Color(0xFF6C3A22)];
    }
  }

  Color get primaryColor => gradientColors.first;
  Color get pawnColor => gradientColors.last;
  Color get opponentColor => opponentGradientColors.first;
}

class PlayerPreferences extends ChangeNotifier {
  PlayerPreferences._();

  static final PlayerPreferences instance = PlayerPreferences._();

  static const String _cupsKey = 'player_cups';
  static const String _coinsKey = 'player_coins';
  static const String _avatarKey = 'player_avatar_choice';
  static const String _wallSkinKey = 'player_wall_skin_choice';
  static const String _ownedAvatarsKey = 'owned_avatars';
  static const String _ownedWallsKey = 'owned_wall_skins';

  AvatarChoice _avatarChoice = AvatarChoice.guest;
  WallSkinChoice _wallSkinChoice = WallSkinChoice.classic;
  int _cups = 0;
  int _coins = 200;
  bool _initialized = false;
  bool _syncing = false;
  bool _dailyCanClaim = false;
  int _dailyRewardDay = 1;
  int _dailyRewardCoins = 10;
  int _dailyStreak = 0;
  bool _wheelCanSpin = false;
  DateTime? _wheelNextSpinAt;
  int _lastWheelPrize = 0;
  int _wins = 0;
  int _losses = 0;
  int _matchesPlayed = 0;
  int _realMatches = 0;
  int _botMatches = 0;
  Duration _serverClockOffset = Duration.zero;

  final Set<AvatarChoice> _ownedAvatars = <AvatarChoice>{AvatarChoice.guest};
  final Set<WallSkinChoice> _ownedWalls = <WallSkinChoice>{WallSkinChoice.classic};

  AvatarChoice get avatarChoice => _avatarChoice;
  WallSkinChoice get wallSkinChoice => _wallSkinChoice;
  Color get playerColor => _wallSkinChoice.pawnColor;
  Color get opponentColor => _wallSkinChoice.opponentColor;
  Color get playerWallColor => _wallSkinChoice.primaryColor;
  Color get opponentWallColor => _wallSkinChoice.opponentColor;
  List<Color> get playerWallGradient => _wallSkinChoice.gradientColors;
  List<Color> get opponentWallGradient => _wallSkinChoice.opponentGradientColors;
  int get cups => _cups;
  int get coins => _coins;
  bool get initialized => _initialized;
  bool get syncing => _syncing;

  bool get hasPendingDailyReward => _dailyCanClaim;
  int get pendingDailyRewardDay => _dailyRewardDay;
  int get pendingDailyRewardCoins => _dailyRewardCoins;
  int get dailyStreak => _dailyStreak;
  bool get canSpinWheelToday => _wheelCanSpin || wheelRemaining == Duration.zero;
  int get pendingWheelPrize => 0;
  int get lastWheelPrize => _lastWheelPrize;
  int get wins => _wins;
  int get losses => _losses;
  int get matchesPlayed => _matchesPlayed;
  int get realMatches => _realMatches;
  int get botMatches => _botMatches;
  DateTime get _serverNow => DateTime.now().add(_serverClockOffset);
  Duration get wheelRemaining {
    final next = _wheelNextSpinAt;
    if (_wheelCanSpin || next == null) return Duration.zero;
    final remaining = next.difference(_serverNow);
    return remaining.isNegative ? Duration.zero : remaining;
  }

  bool ownsAvatar(AvatarChoice choice) => _ownedAvatars.contains(choice);
  bool ownsWall(WallSkinChoice choice) => _ownedWalls.contains(choice);

  Future<void> initialize() async {
    if (_initialized) return;
    await _readCache();
    AuthState.instance.addListener(_handleAuthChanged);
    _initialized = true;
    notifyListeners();
    if (AuthState.instance.isLoggedIn) unawaited(syncFromServer());
  }

  Future<void> _readCache() async {
    try {
      _avatarChoice = _enumFromRaw(
        await LocalStorage.readString(_avatarKey),
        AvatarChoice.values,
        AvatarChoice.guest,
      );
      _wallSkinChoice = _enumFromRaw(
        await LocalStorage.readString(_wallSkinKey),
        WallSkinChoice.values,
        WallSkinChoice.classic,
      );
      _cups = int.tryParse(await LocalStorage.readString(_cupsKey) ?? '') ?? 0;
      _coins = int.tryParse(await LocalStorage.readString(_coinsKey) ?? '') ?? 200;
      _readOwned(
        await LocalStorage.readString(_ownedAvatarsKey),
        AvatarChoice.values,
        _ownedAvatars,
      );
      _readOwned(
        await LocalStorage.readString(_ownedWallsKey),
        WallSkinChoice.values,
        _ownedWalls,
      );
      _ownedAvatars.add(AvatarChoice.guest);
      _ownedWalls.add(WallSkinChoice.classic);
      if (!_ownedAvatars.contains(_avatarChoice)) _avatarChoice = AvatarChoice.guest;
      if (!_ownedWalls.contains(_wallSkinChoice)) _wallSkinChoice = WallSkinChoice.classic;
    } catch (_) {
      _resetGuestState(notify: false);
    }
  }

  void _handleAuthChanged() {
    if (AuthState.instance.isLoggedIn) {
      unawaited(syncFromServer());
    } else {
      _resetGuestState();
    }
  }

  void _resetGuestState({bool notify = true}) {
    _avatarChoice = AvatarChoice.guest;
    _wallSkinChoice = WallSkinChoice.classic;
    _cups = 0;
    _coins = 200;
    _dailyCanClaim = false;
    _dailyRewardDay = 1;
    _dailyRewardCoins = 10;
    _dailyStreak = 0;
    _wheelCanSpin = false;
    _wheelNextSpinAt = null;
    _lastWheelPrize = 0;
    _wins = 0;
    _losses = 0;
    _matchesPlayed = 0;
    _realMatches = 0;
    _botMatches = 0;
    _ownedAvatars
      ..clear()
      ..add(AvatarChoice.guest);
    _ownedWalls
      ..clear()
      ..add(WallSkinChoice.classic);
    if (notify) notifyListeners();
  }

  Future<bool> syncFromServer() async {
    final auth = AuthState.instance;
    if (!auth.isLoggedIn || auth.authToken.isEmpty || _syncing) return false;
    _syncing = true;
    notifyListeners();
    try {
      final payload = await ApiClient.post(
        '/account_me.php',
        <String, Object?>{'token': auth.authToken},
      );
      _updateServerTime(payload['serverTimeMillis']);
      await applyServerSnapshot(payload['user']);
      return true;
    } catch (_) {
      return false;
    } finally {
      _syncing = false;
      notifyListeners();
    }
  }

  Future<void> applyServerSnapshot(Object? raw) async {
    if (raw is! Map<Object?, Object?>) return;
    final data = raw.cast<String, Object?>();
    _cups = ((data['cups'] as num? ?? _cups).toInt()).clamp(0, 999999999) as int;
    _coins = ((data['coins'] as num? ?? _coins).toInt()).clamp(0, 999999999) as int;
    _avatarChoice = _avatarFromName(data['avatarKey'] as String?);
    _wallSkinChoice = _wallFromName(data['wallSkinKey'] as String?);

    _ownedAvatars
      ..clear()
      ..add(AvatarChoice.guest);
    final avatarRaw = data['ownedAvatars'];
    if (avatarRaw is List<Object?>) {
      for (final value in avatarRaw) {
        _ownedAvatars.add(_avatarFromName(value as String?));
      }
    }
    _ownedWalls
      ..clear()
      ..add(WallSkinChoice.classic);
    final wallRaw = data['ownedWalls'];
    if (wallRaw is List<Object?>) {
      for (final value in wallRaw) {
        _ownedWalls.add(_wallFromName(value as String?));
      }
    }
    if (!_ownedAvatars.contains(_avatarChoice)) _avatarChoice = AvatarChoice.guest;
    if (!_ownedWalls.contains(_wallSkinChoice)) _wallSkinChoice = WallSkinChoice.classic;

    final dailyRaw = data['daily'];
    if (dailyRaw is Map<Object?, Object?>) {
      final daily = dailyRaw.cast<String, Object?>();
      _dailyCanClaim = daily['canClaim'] == true;
      _dailyRewardDay = ((daily['day'] as num? ?? 1).toInt()).clamp(1, 10) as int;
      _dailyRewardCoins = ((daily['rewardCoins'] as num? ?? 10).toInt()).clamp(0, 1000) as int;
      _dailyStreak = ((daily['streak'] as num? ?? 0).toInt()).clamp(0, 10) as int;
    }
    final statsRaw = data['stats'];
    if (statsRaw is Map<Object?, Object?>) {
      final stats = statsRaw.cast<String, Object?>();
      _wins = (stats['wins'] as num? ?? 0).toInt();
      _losses = (stats['losses'] as num? ?? 0).toInt();
      _matchesPlayed = (stats['matchesPlayed'] as num? ?? 0).toInt();
      _realMatches = (stats['realMatches'] as num? ?? 0).toInt();
      _botMatches = (stats['botMatches'] as num? ?? 0).toInt();
    }
    final wheelRaw = data['wheel'];
    if (wheelRaw is Map<Object?, Object?>) {
      final wheel = wheelRaw.cast<String, Object?>();
      _wheelCanSpin = wheel['canSpin'] == true;
      _wheelNextSpinAt = DateTime.tryParse(wheel['nextSpinAt'] as String? ?? '')?.toLocal();
    }

    await _saveCache();
    notifyListeners();
  }

  T _enumFromRaw<T>(String? raw, List<T> values, T fallback) {
    final index = int.tryParse(raw ?? '');
    if (index == null || index < 0 || index >= values.length) return fallback;
    return values[index];
  }

  void _readOwned<T>(String? raw, List<T> values, Set<T> target) {
    if (raw == null || raw.trim().isEmpty) return;
    for (final token in raw.split(',')) {
      final index = int.tryParse(token);
      if (index != null && index >= 0 && index < values.length) target.add(values[index]);
    }
  }

  AvatarChoice _avatarFromName(String? name) {
    return AvatarChoice.values.firstWhere(
      (choice) => choice.name == name,
      orElse: () => AvatarChoice.guest,
    );
  }

  WallSkinChoice _wallFromName(String? name) {
    return WallSkinChoice.values.firstWhere(
      (choice) => choice.name == name,
      orElse: () => WallSkinChoice.classic,
    );
  }

  void _updateServerTime(Object? raw) {
    final serverMillis = (raw as num?)?.toInt();
    if (serverMillis == null || serverMillis <= 0) return;
    _serverClockOffset = DateTime.fromMillisecondsSinceEpoch(serverMillis)
        .difference(DateTime.now());
  }

  Future<void> _saveCache() async {
    await Future.wait(<Future<void>>[
      LocalStorage.writeString(_cupsKey, '$_cups'),
      LocalStorage.writeString(_coinsKey, '$_coins'),
      LocalStorage.writeString(_avatarKey, '${_avatarChoice.index}'),
      LocalStorage.writeString(_wallSkinKey, '${_wallSkinChoice.index}'),
      _saveOwned(_ownedAvatarsKey, _ownedAvatars.map((item) => item.index)),
      _saveOwned(_ownedWallsKey, _ownedWalls.map((item) => item.index)),
    ]);
  }

  Future<void> _saveOwned(String key, Iterable<int> indexes) {
    final sorted = indexes.toList()..sort();
    return LocalStorage.writeString(key, sorted.join(','));
  }

  String _requestId(String prefix) {
    return '$prefix-${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 32)}';
  }

  Future<Map<String, Object?>?> _action(
    String action, {
    Map<String, Object?> extra = const <String, Object?>{},
  }) async {
    final auth = AuthState.instance;
    if (!auth.isLoggedIn || auth.authToken.isEmpty || !NetworkStatus.instance.isOnline) return null;
    try {
      final payload = await ApiClient.post(
        '/account_action.php',
        <String, Object?>{
          'token': auth.authToken,
          'action': action,
          'requestId': _requestId(action),
          ...extra,
        },
      );
      _updateServerTime(payload['serverTimeMillis']);
      await applyServerSnapshot(payload['user']);
      return payload;
    } catch (_) {
      return null;
    }
  }

  Future<void> setAvatar(AvatarChoice choice) async {
    if (!ownsAvatar(choice) || _avatarChoice == choice) return;
    final payload = await _action('select_avatar', extra: <String, Object?>{'itemKey': choice.name});
    if (payload == null) return;
  }

  Future<bool> buyAvatar(AvatarChoice choice) async {
    if (ownsAvatar(choice)) {
      await setAvatar(choice);
      return _avatarChoice == choice;
    }
    final payload = await _action('buy_avatar', extra: <String, Object?>{'itemKey': choice.name});
    return payload != null && ownsAvatar(choice);
  }

  Future<void> setWallSkin(WallSkinChoice choice) async {
    if (!ownsWall(choice) || _wallSkinChoice == choice) return;
    await _action('select_wall', extra: <String, Object?>{'itemKey': choice.name});
  }

  Future<bool> buyWallSkin(WallSkinChoice choice) async {
    if (ownsWall(choice)) {
      await setWallSkin(choice);
      return _wallSkinChoice == choice;
    }
    final payload = await _action('buy_wall', extra: <String, Object?>{'itemKey': choice.name});
    return payload != null && ownsWall(choice);
  }

  Future<int> claimDailyReward({bool doubled = false}) async {
    final payload = await _action('claim_daily');
    return (payload?['rewardCoins'] as num? ?? 0).toInt();
  }

  Future<int> beginWheelSpin() async {
    final payload = await _action('spin_wheel');
    final prize = (payload?['prize'] as num? ?? 0).toInt();
    if (prize > 0) {
      _lastWheelPrize = prize;
      notifyListeners();
    }
    return prize;
  }

  Future<int> claimWheelPrize({bool doubled = false}) async => 0;

  Future<bool> trySpendCoins(int amount) async => false;

  Future<void> addCoins(int amount) async {
    if (amount != EconomyConfig.rewardedAdCoins) return;
    await _action('reward_ad');
  }

  Future<int> doubleMatchReward(String matchId) async {
    if (matchId.trim().isEmpty) return 0;
    final payload = await _action(
      'double_match_reward',
      extra: <String, Object?>{'matchId': matchId},
    );
    return (payload?['rewardCoins'] as num? ?? 0).toInt();
  }

  Future<void> addCups(int delta) async => setCups(_cups + delta);

  Future<void> setCups(int value) async {
    final next = value.clamp(0, 999999999) as int;
    if (next == _cups) return;
    _cups = next;
    await LocalStorage.writeString(_cupsKey, '$_cups');
    notifyListeners();
  }
}
