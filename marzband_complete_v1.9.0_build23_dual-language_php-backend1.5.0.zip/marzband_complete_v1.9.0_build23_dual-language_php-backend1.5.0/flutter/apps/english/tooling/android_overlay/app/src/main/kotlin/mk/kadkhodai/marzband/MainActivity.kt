package mk.kadkhodai.marzband

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
