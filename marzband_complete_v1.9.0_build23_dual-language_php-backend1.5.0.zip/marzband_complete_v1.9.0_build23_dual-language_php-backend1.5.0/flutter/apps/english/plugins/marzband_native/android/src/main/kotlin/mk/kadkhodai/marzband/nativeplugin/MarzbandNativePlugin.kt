package mk.kadkhodai.marzband.nativeplugin

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MarzbandNativePlugin : FlutterPlugin, MethodCallHandler {
    private lateinit var channel: MethodChannel
    private lateinit var preferences: SharedPreferences
    private lateinit var applicationContext: Context
    private val executor: ExecutorService = Executors.newCachedThreadPool()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        applicationContext = binding.applicationContext
        preferences = applicationContext.getSharedPreferences(
            "marzband_local_storage",
            Context.MODE_PRIVATE,
        )
        channel = MethodChannel(binding.binaryMessenger, "mk.kadkhodai.marzband/storage")
        channel.setMethodCallHandler(this)
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
        executor.shutdownNow()
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        val key = call.argument<String>("key")
        when (call.method) {
            "readString" -> {
                if (key.isNullOrBlank()) {
                    result.error("invalid_key", "Storage key is required.", null)
                    return
                }
                result.success(if (preferences.contains(key)) preferences.getString(key, null) else null)
            }

            "writeString" -> {
                val value = call.argument<String>("value")
                if (key.isNullOrBlank() || value == null) {
                    result.error("invalid_arguments", "Key and string value are required.", null)
                    return
                }
                preferences.edit().putString(key, value).apply()
                result.success(null)
            }

            "readBool" -> {
                if (key.isNullOrBlank()) {
                    result.error("invalid_key", "Storage key is required.", null)
                    return
                }
                result.success(if (preferences.contains(key)) preferences.getBoolean(key, false) else null)
            }

            "writeBool" -> {
                val value = call.argument<Boolean>("value")
                if (key.isNullOrBlank() || value == null) {
                    result.error("invalid_arguments", "Key and boolean value are required.", null)
                    return
                }
                preferences.edit().putBoolean(key, value).apply()
                result.success(null)
            }

            "httpPostJson" -> httpPostJson(call, result)
            "isNetworkAvailable" -> result.success(isNetworkAvailable())
            else -> result.notImplemented()
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val manager = applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun httpPostJson(call: MethodCall, result: Result) {
        val url = call.argument<String>("url")
        val body = call.argument<String>("body") ?: "{}"
        val timeoutMs = (call.argument<Number>("timeoutMs")?.toInt() ?: 12000)
            .coerceIn(1000, 60000)

        if (url.isNullOrBlank() || !url.startsWith("https://")) {
            result.error("invalid_url", "A valid HTTPS URL is required.", null)
            return
        }

        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val bytes = body.toByteArray(StandardCharsets.UTF_8)
                connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = timeoutMs
                    readTimeout = timeoutMs
                    instanceFollowRedirects = true
                    useCaches = false
                    doInput = true
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Connection", "close")
                    setRequestProperty("User-Agent", "Wallfront-Android/1.7.0")
                    setFixedLengthStreamingMode(bytes.size)
                }
                connection.outputStream.use { stream ->
                    stream.write(bytes)
                    stream.flush()
                }
                val statusCode = connection.responseCode
                val stream = if (statusCode in 200..399) connection.inputStream else connection.errorStream
                val responseBody = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() } ?: ""
                mainHandler.post {
                    result.success(
                        mapOf(
                            "statusCode" to statusCode,
                            "body" to responseBody,
                        ),
                    )
                }
            } catch (error: Throwable) {
                mainHandler.post {
                    result.error(
                        "network_error",
                        error.message ?: error.javaClass.simpleName,
                        error.javaClass.name,
                    )
                }
            } finally {
                connection?.disconnect()
            }
        }
    }
}
