# Marzband / Wallfront 1.9.0+23 — English

Flutter source for the English release variant.

- Package Name: `mk.kadkhodai.marzband`
- API: `https://persian-melody.ir/marzband/api`
- Shared Backend: PHP `1.5.0`
- Release signing: existing project keystore
- Variant version: `1.9.0+23`

This directory is built by the repository workflow. Do not mix localized
assets or Dart files between `apps/english` and `apps/persian`.
