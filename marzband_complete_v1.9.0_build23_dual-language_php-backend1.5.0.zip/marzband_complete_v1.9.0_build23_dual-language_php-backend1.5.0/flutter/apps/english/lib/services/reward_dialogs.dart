import 'package:flutter/material.dart';

import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import 'rewarded_ad_service.dart';

enum _RewardChoice { normal, doubleReward }

abstract final class RewardDialogs {
  static Future<int> showDailyReward(
    BuildContext context,
    PlayerPreferences preferences,
  ) async {
    while (context.mounted && preferences.hasPendingDailyReward) {
      final day = preferences.pendingDailyRewardDay;
      final coins = preferences.pendingDailyRewardCoins;
      final choice = await showDialog<_RewardChoice>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.calendar_month_rounded, color: AppColors.gold, size: 42),
          title: Text('Daily Login — Day $day'),
          content: Text(
            '$coins coins are ready. Claim them now or double the reward with a completed video.',
            textAlign: TextAlign.center,
            style: const TextStyle(height: 1.6),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.normal),
              child: Text('Claim $coins Coins'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.doubleReward),
              icon: const Icon(Icons.ondemand_video_rounded),
              label: Text('Double: ${coins * 2}'),
            ),
          ],
        ),
      );
      if (choice == _RewardChoice.normal) return preferences.claimDailyReward();
      if (choice == _RewardChoice.doubleReward) {
        final rewarded = await RewardedAdService.show(context);
        if (!context.mounted) return 0;
        if (rewarded) return preferences.claimDailyReward(doubled: true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('The video was not completed. Your original reward is still available.')),
        );
      }
    }
    return 0;
  }

  static Future<int> showWheelReward(
    BuildContext context,
    PlayerPreferences preferences,
  ) async {
    while (context.mounted && preferences.pendingWheelPrize > 0) {
      final coins = preferences.pendingWheelPrize;
      final choice = await showDialog<_RewardChoice>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(Icons.casino_rounded, color: AppColors.purple, size: 42),
          title: const Text('Wheel Reward'),
          content: Text(
            'The wheel landed on $coins coins. Claim it now or double it with a completed video.',
            textAlign: TextAlign.center,
            style: const TextStyle(height: 1.6),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.normal),
              child: Text('Claim $coins'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop(_RewardChoice.doubleReward),
              icon: const Icon(Icons.ondemand_video_rounded),
              label: Text('Double: ${coins * 2}'),
            ),
          ],
        ),
      );
      if (choice == _RewardChoice.normal) return preferences.claimWheelPrize();
      if (choice == _RewardChoice.doubleReward) {
        final rewarded = await RewardedAdService.show(context);
        if (!context.mounted) return 0;
        if (rewarded) return preferences.claimWheelPrize(doubled: true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('The video was not completed. Your wheel reward is still available.')),
        );
      }
    }
    return 0;
  }
}
