import 'package:flutter/services.dart';

abstract final class LocalStorage {
  static const MethodChannel _channel = MethodChannel(
    'mk.kadkhodai.marzband/storage',
  );

  static Future<String?> readString(String key) {
    return _channel.invokeMethod<String>('readString', <String, Object?>{
      'key': key,
    });
  }

  static Future<void> writeString(String key, String value) {
    return _channel.invokeMethod<void>('writeString', <String, Object?>{
      'key': key,
      'value': value,
    });
  }

  static Future<bool?> readBool(String key) {
    return _channel.invokeMethod<bool>('readBool', <String, Object?>{
      'key': key,
    });
  }

  static Future<void> writeBool(String key, bool value) {
    return _channel.invokeMethod<void>('writeBool', <String, Object?>{
      'key': key,
      'value': value,
    });
  }

}
