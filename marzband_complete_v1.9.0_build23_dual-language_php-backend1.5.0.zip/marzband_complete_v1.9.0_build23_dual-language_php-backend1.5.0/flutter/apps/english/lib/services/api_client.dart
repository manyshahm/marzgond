import 'dart:convert';

import 'package:flutter/services.dart';

import '../config/network_config.dart';
import 'network_status.dart';

class ApiClientException implements Exception {
  const ApiClientException({
    required this.message,
    this.code,
    this.statusCode,
  });

  final String message;
  final String? code;
  final int? statusCode;

  @override
  String toString() => message;
}

abstract final class ApiClient {
  static const MethodChannel _channel = MethodChannel(
    'mk.kadkhodai.marzband/storage',
  );

  static Future<Map<String, Object?>> post(
    String path,
    Map<String, Object?> body, {
    Duration? timeout,
  }) async {
    final uri = Uri.parse('${NetworkConfig.apiBase}$path');
    try {
      final result = await _channel.invokeMapMethod<String, Object?>(
        'httpPostJson',
        <String, Object?>{
          'url': uri.toString(),
          'body': jsonEncode(body),
          'timeoutMs': (timeout ?? NetworkConfig.connectionTimeout).inMilliseconds,
        },
      );
      final statusCode = (result?['statusCode'] as num?)?.toInt() ?? 0;
      final responseText = result?['body'] as String? ?? '';
      Object? decoded;
      try {
        decoded = jsonDecode(responseText.isEmpty ? '{}' : responseText);
      } on FormatException {
        throw ApiClientException(
          message: 'The server returned an invalid response.',
          code: 'invalid_response',
          statusCode: statusCode,
        );
      }
      final payload = decoded is Map<Object?, Object?>
          ? decoded.cast<String, Object?>()
          : <String, Object?>{};
      if (statusCode < 200 || statusCode >= 300 || payload['ok'] == false) {
        final code = payload['error'] as String?;
        throw ApiClientException(
          message: _messageForCode(code, statusCode),
          code: code,
          statusCode: statusCode,
        );
      }
      return payload;
    } on ApiClientException {
      rethrow;
    } on PlatformException catch (error) {
      throw ApiClientException(
        message: NetworkStatus.instance.isOnline
            ? 'Unable to reach the game server.'
            : 'No internet connection',
        code: error.code,
      );
    } catch (_) {
      throw ApiClientException(
        message: NetworkStatus.instance.isOnline
            ? 'Unable to reach the game server.'
            : 'No internet connection',
        code: 'network_error',
      );
    }
  }

  static String _messageForCode(String? code, int statusCode) {
    switch (code) {
      case 'authentication_required':
        return 'Your account session is no longer valid. Sign in again.';
      case 'invalid_credentials':
        return 'Incorrect email or password.';
      case 'email_already_registered':
        return 'This email is already registered. Sign in instead.';
      case 'invalid_name':
        return 'Enter a valid player name.';
      case 'invalid_email':
        return 'Enter a valid email address.';
      case 'weak_password':
        return 'Password must contain at least 8 characters.';
      case 'account_not_found':
        return 'No account was found for this email.';
      case 'invalid_recovery_code':
        return 'The recovery code is incorrect or expired.';
      case 'account_already_in_match':
        return 'This account already has an active match.';
      case 'daily_already_claimed':
        return 'Today’s daily reward has already been claimed.';
      case 'wheel_cooldown':
        return 'The fortune wheel is still on cooldown.';
      case 'not_enough_coins':
      case 'insufficient_balance':
        return 'There are not enough coins for this operation.';
      case 'item_not_owned':
        return 'This item is not owned by the account.';
      case 'invalid_item':
        return 'The selected store item is invalid.';
      case 'storage_unavailable':
      case 'storage_lock_unavailable':
        return 'The game server storage is temporarily unavailable.';
      default:
        if (statusCode == 404) return 'The requested server endpoint was not found.';
        if (statusCode >= 500) return 'The game server is temporarily unavailable.';
        return code?.isNotEmpty == true ? code! : 'Server error.';
    }
  }
}
