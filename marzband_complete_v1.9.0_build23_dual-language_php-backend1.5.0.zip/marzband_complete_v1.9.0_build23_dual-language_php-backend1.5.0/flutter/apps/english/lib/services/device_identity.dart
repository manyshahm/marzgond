import 'dart:math';

import 'local_storage.dart';

abstract final class DeviceIdentity {
  static const String _deviceIdKey = 'online_device_id_v1';

  static Future<String> load() async {
    final existing = await LocalStorage.readString(_deviceIdKey);
    if (existing != null && existing.length >= 12) return existing;
    final random = Random.secure();
    final suffix = List<int>.generate(18, (_) => random.nextInt(256))
        .map((value) => value.toRadixString(16).padLeft(2, '0'))
        .join();
    final id =
        'wf-${DateTime.now().microsecondsSinceEpoch.toRadixString(16)}-$suffix';
    await LocalStorage.writeString(_deviceIdKey, id);
    return id;
  }
}
