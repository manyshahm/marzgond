import 'package:flutter/material.dart';

abstract final class AppNavigation {
  static void goHome(BuildContext context) {
    Navigator.of(context).pushNamedAndRemoveUntil('/home', (route) => false);
  }
}
