import 'dart:async';

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Single integration point for rewarded video ads.
///
/// Until ad-network identifiers are configured, this build uses an internal demo.
/// When the production SDK is connected, replace the show method with the official reward callback.
abstract final class RewardedAdService {
  static const bool isDemoMode = true;

  static Future<bool> show(BuildContext context) async {
    return await Navigator.of(context).push<bool>(
          MaterialPageRoute<bool>(
            fullscreenDialog: true,
            builder: (_) => const _RewardedAdDemoScreen(),
          ),
        ) ??
        false;
  }
}

class _RewardedAdDemoScreen extends StatefulWidget {
  const _RewardedAdDemoScreen();

  @override
  State<_RewardedAdDemoScreen> createState() => _RewardedAdDemoScreenState();
}

class _RewardedAdDemoScreenState extends State<_RewardedAdDemoScreen> {
  static const int _durationSeconds = 5;
  Timer? _timer;
  int _remaining = _durationSeconds;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_remaining <= 1) {
        timer.cancel();
        setState(() => _remaining = 0);
      } else {
        setState(() => _remaining--);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final completed = _remaining == 0;
    return PopScope(
      canPop: true,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: const Text('Rewarded Video'),
          leading: IconButton(
            onPressed: completed ? null : () => Navigator.of(context).pop(false),
            icon: const Icon(Icons.close_rounded),
          ),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: <Widget>[
                const Spacer(),
                Container(
                  width: 112,
                  height: 112,
                  decoration: BoxDecoration(
                    color: AppColors.cyan.withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.cyan.withValues(alpha: 0.55)),
                  ),
                  child: const Icon(Icons.ondemand_video_rounded, color: AppColors.cyan, size: 54),
                ),
                const SizedBox(height: 24),
                Text(
                  completed ? 'Video Completed' : 'Watch until the end to receive the reward.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 12),
                Text(
                  completed ? 'Your reward is ready.' : '$_remaining seconds remaining',
                  style: const TextStyle(color: AppColors.muted, fontSize: 17),
                ),
                const SizedBox(height: 18),
                const Text(
                  'This internal demo simulates the rewarded-video integration point.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.6),
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: FilledButton.icon(
                    onPressed: completed ? () => Navigator.of(context).pop(true) : null,
                    icon: const Icon(Icons.card_giftcard_rounded),
                    label: const Text('Claim Reward'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
