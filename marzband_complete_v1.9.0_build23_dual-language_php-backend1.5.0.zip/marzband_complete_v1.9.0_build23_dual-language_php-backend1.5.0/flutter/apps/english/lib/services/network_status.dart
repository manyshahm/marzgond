import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class NetworkStatus extends ChangeNotifier {
  NetworkStatus._();

  static final NetworkStatus instance = NetworkStatus._();
  static const MethodChannel _channel = MethodChannel(
    'mk.kadkhodai.marzband/storage',
  );

  Timer? _timer;
  bool _initialized = false;
  bool _online = true;
  bool _checking = false;

  bool get initialized => _initialized;
  bool get isOnline => _online;

  Future<void> initialize() async {
    if (_initialized) return;
    await refresh();
    _initialized = true;
    _timer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => unawaited(refresh()),
    );
  }

  Future<bool> refresh() async {
    if (_checking) return _online;
    _checking = true;
    try {
      final value = await _channel.invokeMethod<bool>('isNetworkAvailable');
      final next = value ?? false;
      if (next != _online) {
        _online = next;
        notifyListeners();
      }
    } on PlatformException {
      if (_online) {
        _online = false;
        notifyListeners();
      }
    } finally {
      _checking = false;
    }
    return _online;
  }

  void disposeService() {
    _timer?.cancel();
    _timer = null;
  }
}
