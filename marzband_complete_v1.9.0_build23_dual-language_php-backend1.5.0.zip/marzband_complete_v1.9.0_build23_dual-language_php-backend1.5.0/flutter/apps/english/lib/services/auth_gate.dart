import 'package:flutter/material.dart';

import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../services/network_status.dart';
import '../state/auth_state.dart';
import '../theme/app_theme.dart';

abstract final class AuthGate {
  static Future<bool> ensureLoggedIn(BuildContext context) async {
    if (AuthState.instance.isLoggedIn) return true;
    if (!NetworkStatus.instance.isOnline) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No internet connection')),
      );
      return false;
    }
    final action = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          padding: const EdgeInsets.fromLTRB(22, 24, 22, 18),
          decoration: BoxDecoration(
            color: const Color(0xFF0B1324),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.cyan.withValues(alpha: 0.42)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.cyan.withValues(alpha: 0.12),
                  border: Border.all(color: AppColors.cyan.withValues(alpha: 0.65)),
                ),
                child: const Icon(Icons.lock_person_rounded, color: AppColors.cyan, size: 34),
              ),
              const SizedBox(height: 16),
              const Text(
                'Account Required',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 9),
              const Text(
                'Sign in or create an account to use online play and your profile. Offline play remains available without an account.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, height: 1.5),
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton.icon(
                  onPressed: () => Navigator.of(dialogContext).pop('register'),
                  icon: const Icon(Icons.person_add_alt_1_rounded),
                  label: const Text('Create Account'),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.blue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.of(dialogContext).pop('login'),
                  icon: const Icon(Icons.login_rounded),
                  label: const Text('Sign In'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.cyan,
                    side: BorderSide(color: AppColors.cyan.withValues(alpha: 0.7)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop('later'),
                child: const Text('Maybe Later', style: TextStyle(color: AppColors.muted)),
              ),
            ],
          ),
        ),
      ),
    );
    if (!context.mounted || action == null || action == 'later') return false;
    final bool? success;
    if (action == 'login') {
      success = await Navigator.of(context).push<bool>(
        MaterialPageRoute<bool>(builder: (_) => const LoginScreen()),
      );
    } else {
      success = await Navigator.of(context).push<bool>(
        MaterialPageRoute<bool>(builder: (_) => const RegisterScreen()),
      );
    }
    return success == true && AuthState.instance.isLoggedIn;
  }
}
