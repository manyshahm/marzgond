import 'dart:async';

import 'package:flutter/material.dart';

import 'app.dart';
import 'network/online_game_service.dart';
import 'services/network_status.dart';
import 'state/auth_state.dart';
import 'state/game_history_store.dart';
import 'state/player_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NetworkStatus.instance.initialize();
  await AuthState.instance.initialize();
  await PlayerPreferences.instance.initialize();
  await GameHistoryStore.instance.initialize();
  AuthState.instance.addListener(_syncPresenceWithAuth);
  runApp(const MarzbandApp());
  _syncPresenceWithAuth();
}

void _syncPresenceWithAuth() {
  if (AuthState.instance.isLoggedIn) {
    unawaited(OnlineGameService.instance.initializePresence());
  }
}
