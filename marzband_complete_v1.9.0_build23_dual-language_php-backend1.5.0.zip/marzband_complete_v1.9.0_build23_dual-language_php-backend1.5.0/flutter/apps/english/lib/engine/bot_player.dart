import 'dart:math';

import '../models/game_models.dart';
import 'game_engine.dart';

Map<String, Object?> computeBotAction(Map<String, Object?> request) {
  final engine = GameEngine.fromSnapshot(
    (request['engine'] as Map<Object?, Object?>).cast<String, Object?>(),
  );
  final difficultyIndex = ((request['difficulty'] as num? ?? 0)
      .toInt()
      .clamp(0, BotDifficulty.values.length - 1)) as int;
  final bot = BotPlayer(difficulty: BotDifficulty.values[difficultyIndex]);
  return bot.choose(engine).toMap();
}

class BotPlayer {
  BotPlayer({required this.difficulty, Random? random})
      : _random = random ?? Random();

  final BotDifficulty difficulty;
  final Random _random;

  late _AiProfile _profile;
  late _PlayerStyle _opponentStyle;
  DateTime? _deadline;
  Player? _root;
  int _visitedNodes = 0;
  final Map<String, int> _transposition = <String, int>{};

  BotAction choose(GameEngine engine) {
    if (engine.isFinished) return const BotAction.none();

    _profile = _AiProfile.forDifficulty(difficulty, engine.turnNumber);
    _deadline = DateTime.now().add(_profile.searchBudget);
    _root = engine.turn;
    _opponentStyle = _PlayerStyle.fromHistory(
      engine.history,
      engine.turn.opponent,
    );
    _visitedNodes = 0;
    _transposition.clear();

    final forcedWin = _immediateWinningAction(engine, engine.turn);
    if (forcedWin != null) return forcedWin;

    final rootActions = _legalActions(
      engine,
      rootNode: true,
      forceWideWallScan: _hasImmediateWinningMove(
        engine,
        engine.turn.opponent,
      ),
    );
    if (rootActions.isEmpty) return safeFallback(engine);

    final safeActions = _removeImmediateLosingActions(engine, rootActions);
    final candidates = safeActions.isNotEmpty ? safeActions : rootActions;
    final immediateRanked = _rankImmediate(
      engine,
      candidates,
      engine.turn,
    );
    if (immediateRanked.isEmpty) return safeFallback(engine);

    switch (difficulty) {
      case BotDifficulty.easy:
        return _chooseEasy(engine, immediateRanked);
      case BotDifficulty.normal:
        return _chooseNormal(engine, immediateRanked);
      case BotDifficulty.hard:
        return _chooseHardWithVariety(engine, immediateRanked);
      case BotDifficulty.extreme:
        return _chooseDeep(engine, immediateRanked);
    }
  }

  static BotAction safeFallback(GameEngine engine) {
    final player = engine.turn;
    final legal = engine.legalMoves(player).toList(growable: false);
    if (legal.isEmpty) return const BotAction.none();

    BotAction best = BotAction.move(legal.first);
    var bestScore = -1000000000;
    for (final move in legal) {
      final copy = engine.clone();
      if (!copy.move(move)) continue;
      if (copy.winner == player) return BotAction.move(move);
      final ownPath = copy.shortestPathLength(player) ?? 99;
      final opponentPath = copy.shortestPathLength(player.opponent) ?? 99;
      final progress = _progressOf(move, player);
      final score = (opponentPath - ownPath) * 1000 + progress * 40;
      if (score > bestScore) {
        bestScore = score;
        best = BotAction.move(move);
      }
    }
    return best;
  }

  bool get _timedOut {
    _visitedNodes++;
    if ((_visitedNodes & 31) != 0) return false;
    return _deadline != null && DateTime.now().isAfter(_deadline!);
  }

  BotAction _chooseEasy(
    GameEngine engine,
    List<_ScoredAction> immediateRanked,
  ) {
    final ranked = _iterativeSearch(engine, immediateRanked);
    if (ranked.length <= 1) return ranked.first.action;

    final close = ranked
        .where(
          (entry) => entry.score >= ranked.first.score - _profile.choiceWindow,
        )
        .take(_profile.topChoiceCount)
        .toList(growable: false);
    if (close.length <= 1) return ranked.first.action;

    // Easy remains rational but is deliberately less precise. It chooses only
    // among safe, near-best actions so it never performs a visibly absurd move.
    final roll = _random.nextDouble();
    if (roll < 0.48) return close.first.action;
    if (roll < 0.78 && close.length > 1) return close[1].action;
    if (roll < 0.94 && close.length > 2) return close[2].action;
    return close[_random.nextInt(close.length)].action;
  }

  BotAction _chooseHardWithVariety(
    GameEngine engine,
    List<_ScoredAction> immediateRanked,
  ) {
    final ranked = _iterativeSearch(engine, immediateRanked);
    if (ranked.length <= 1) return ranked.first.action;
    final close = ranked
        .where((entry) => entry.score >= ranked.first.score - 45)
        .take(3)
        .toList(growable: false);
    if (close.length <= 1 || _random.nextDouble() < 0.88) {
      return ranked.first.action;
    }
    // Variety is allowed only between almost equivalent strategic choices.
    return close[1 + _random.nextInt(close.length - 1)].action;
  }

  BotAction _chooseNormal(
    GameEngine engine,
    List<_ScoredAction> immediateRanked,
  ) {
    return _iterativeSearch(engine, immediateRanked).first.action;
  }

  BotAction _chooseDeep(
    GameEngine engine,
    List<_ScoredAction> immediateRanked,
  ) {
    return _iterativeSearch(engine, immediateRanked).first.action;
  }

  List<_ScoredAction> _iterativeSearch(
    GameEngine engine,
    List<_ScoredAction> immediateRanked,
  ) {
    var bestCompleted = immediateRanked;
    BotAction? preferred = immediateRanked.first.action;

    // Depth 3 means: bot move -> strongest probable user reply -> bot reply.
    // Every level therefore evaluates both sides instead of using a static
    // one-ply score. Stronger levels continue deeper until their deadline.
    for (var depth = 3; depth <= _profile.maxDepth; depth++) {
      if (_deadline != null && DateTime.now().isAfter(_deadline!)) break;
      final result = _searchRoot(
        engine,
        depth: depth,
        rootLimit: _rootLimitForDepth(depth),
        rootCandidates: immediateRanked.map((entry) => entry.action).toList(),
        preferredAction: preferred,
      );
      if (!result.completed || result.ranked.isEmpty) break;
      bestCompleted = result.ranked;
      preferred = result.ranked.first.action;
    }

    return bestCompleted;
  }

  int _rootLimitForDepth(int depth) {
    if (depth <= 2) return _profile.rootActionLimit;
    if (depth == 3) return max(12, _profile.rootActionLimit - 4);
    if (depth == 4) return max(9, _profile.rootActionLimit - 8);
    if (depth == 5) return max(7, _profile.rootActionLimit - 12);
    return max(6, _profile.rootActionLimit - 15);
  }

  _RootSearchResult _searchRoot(
    GameEngine engine, {
    required int depth,
    required int rootLimit,
    List<BotAction>? rootCandidates,
    BotAction? preferredAction,
  }) {
    final root = _root ?? engine.turn;
    final actions = rootCandidates ??
        _legalActions(
          engine,
          rootNode: true,
          forceWideWallScan: _hasImmediateWinningMove(
            engine,
            engine.turn.opponent,
          ),
        );
    final ordered = _rankImmediate(engine, actions, root)
        .take(rootLimit)
        .toList(growable: true);
    if (preferredAction != null) {
      final preferredIndex = ordered.indexWhere(
        (entry) => entry.action == preferredAction,
      );
      if (preferredIndex > 0) {
        final preferred = ordered.removeAt(preferredIndex);
        ordered.insert(0, preferred);
      }
    }
    if (ordered.isEmpty) {
      return const _RootSearchResult(completed: true, ranked: <_ScoredAction>[]);
    }

    var alpha = -1000000000;
    const beta = 1000000000;
    final results = <_ScoredAction>[];

    for (final entry in ordered) {
      if (_timedOut) {
        return _RootSearchResult(completed: false, ranked: results);
      }
      final next = engine.clone();
      if (!_apply(next, entry.action)) continue;
      final value = _minimax(
        next,
        root: root,
        depth: depth - 1,
        alpha: alpha,
        beta: beta,
        extensionLeft: _profile.tacticalExtensions,
      );
      if (_deadline != null && DateTime.now().isAfter(_deadline!)) {
        return _RootSearchResult(completed: false, ranked: results);
      }
      results.add(_ScoredAction(entry.action, value));
      alpha = max(alpha, value);
    }

    results.sort((a, b) => b.score.compareTo(a.score));
    return _RootSearchResult(completed: true, ranked: results);
  }

  int _minimax(
    GameEngine engine, {
    required Player root,
    required int depth,
    required int alpha,
    required int beta,
    required int extensionLeft,
  }) {
    if (_timedOut || engine.winner != null) {
      return _evaluate(engine, root);
    }

    var remainingDepth = depth;
    var remainingExtensions = extensionLeft;
    if (remainingDepth <= 0) {
      if (remainingExtensions > 0 && _isTacticalPosition(engine)) {
        remainingDepth = 1;
        remainingExtensions--;
      } else {
        return _evaluate(engine, root);
      }
    }

    final key = _stateKey(
      engine,
      remainingDepth,
      root,
      remainingExtensions,
    );
    final cached = _transposition[key];
    if (cached != null) return cached;

    final maximizing = engine.turn == root;
    final actions = _legalActions(
      engine,
      rootNode: false,
      forceWideWallScan: false,
    );
    if (actions.isEmpty) return _evaluate(engine, root);

    final ordered = _rankImmediate(engine, actions, root)
        .take(_branchLimit(remainingDepth))
        .toList(growable: false);
    if (ordered.isEmpty) return _evaluate(engine, root);

    var localAlpha = alpha;
    var localBeta = beta;
    var cutOff = false;

    if (maximizing) {
      var value = -1000000000;
      for (final entry in ordered) {
        if (_timedOut) return value == -1000000000 ? _evaluate(engine, root) : value;
        final next = engine.clone();
        if (!_apply(next, entry.action)) continue;
        value = max(
          value,
          _minimax(
            next,
            root: root,
            depth: remainingDepth - 1,
            alpha: localAlpha,
            beta: localBeta,
            extensionLeft: remainingExtensions,
          ),
        );
        localAlpha = max(localAlpha, value);
        if (localAlpha >= localBeta) {
          cutOff = true;
          break;
        }
      }
      if (!cutOff && !_timedOut && _profile.useTransposition) {
        _transposition[key] = value;
      }
      return value;
    }

    var value = 1000000000;
    for (final entry in ordered) {
      if (_timedOut) return value == 1000000000 ? _evaluate(engine, root) : value;
      final next = engine.clone();
      if (!_apply(next, entry.action)) continue;
      value = min(
        value,
        _minimax(
          next,
          root: root,
          depth: remainingDepth - 1,
          alpha: localAlpha,
          beta: localBeta,
          extensionLeft: remainingExtensions,
        ),
      );
      localBeta = min(localBeta, value);
      if (localAlpha >= localBeta) {
        cutOff = true;
        break;
      }
    }
    if (!cutOff && !_timedOut && _profile.useTransposition) {
      _transposition[key] = value;
    }
    return value;
  }

  int _branchLimit(int depth) {
    if (depth >= 5) return _profile.deepBranchLimit;
    if (depth == 4) return max(_profile.deepBranchLimit + 1, 8);
    if (depth == 3) return _profile.middleBranchLimit;
    return _profile.shallowBranchLimit;
  }

  List<BotAction> _removeImmediateLosingActions(
    GameEngine engine,
    List<BotAction> actions,
  ) {
    final safe = <BotAction>[];
    for (final action in actions) {
      final copy = engine.clone();
      if (!_apply(copy, action)) continue;
      if (copy.winner == engine.turn) {
        safe.add(action);
        continue;
      }
      if (!_hasImmediateWinningMove(copy, copy.turn)) {
        safe.add(action);
      }
    }
    return safe;
  }

  List<BotAction> _legalActions(
    GameEngine engine, {
    required bool rootNode,
    required bool forceWideWallScan,
  }) {
    final actions = <BotAction>[
      for (final move in engine.legalMoves()) BotAction.move(move),
    ];

    if (engine.wallsOf(engine.turn) > 0) {
      final wallLimit = rootNode
          ? _profile.rootWallLimit
          : _profile.childWallLimit;
      actions.addAll(
        _candidateWalls(
          engine,
          maximum: wallLimit,
          scanAll: forceWideWallScan ||
              (rootNode && _profile.scanAllWallsAtRoot),
        ),
      );
    }

    return actions;
  }

  List<_ScoredAction> _rankImmediate(
    GameEngine engine,
    Iterable<BotAction> actions,
    Player root,
  ) {
    final scored = <_ScoredAction>[];
    for (final action in actions) {
      final score = _immediateActionScore(engine, action, root);
      if (score <= -900000000) continue;
      scored.add(_ScoredAction(action, score));
    }
    final maximizing = engine.turn == root;
    scored.sort(
      (a, b) => maximizing
          ? b.score.compareTo(a.score)
          : a.score.compareTo(b.score),
    );
    return scored;
  }

  List<BotAction> _candidateWalls(
    GameEngine engine, {
    required int maximum,
    required bool scanAll,
  }) {
    if (engine.wallsOf(engine.turn) <= 0) return const <BotAction>[];

    final actor = engine.turn;
    final opponent = actor.opponent;
    final beforeOwn = engine.shortestPathLength(actor) ?? 99;
    final beforeOpponent = engine.shortestPathLength(opponent) ?? 99;
    final beforeOpponentOptions = _shortestStepOptions(engine, opponent);
    final keys = <_WallKey>{};

    void add(int row, int col, WallOrientation orientation) {
      if (row < 0 || row > 7 || col < 0 || col > 7) return;
      keys.add(_WallKey(row, col, orientation));
    }

    void addAroundCell(Cell cell, {int radius = 1}) {
      for (var row = cell.row - radius; row <= cell.row + radius; row++) {
        for (var col = cell.col - radius; col <= cell.col + radius; col++) {
          add(row, col, WallOrientation.horizontal);
          add(row, col, WallOrientation.vertical);
        }
      }
    }

    void addPathBlockers(List<Cell> path, {required int take}) {
      if (path.length < 2) return;
      final usable = min(path.length - 1, take);
      for (var index = 0; index < usable; index++) {
        final a = path[index];
        final b = path[index + 1];
        if (a.row == b.row) {
          final col = min(a.col, b.col);
          add(a.row, col, WallOrientation.vertical);
          add(a.row - 1, col, WallOrientation.vertical);
        } else {
          final row = min(a.row, b.row);
          add(row, a.col, WallOrientation.horizontal);
          add(row, a.col - 1, WallOrientation.horizontal);
        }
        addAroundCell(b);
      }
    }

    final opponentPath = engine.shortestPath(opponent);
    final ownPath = engine.shortestPath(actor);
    addPathBlockers(opponentPath, take: scanAll ? 12 : 8);
    addPathBlockers(ownPath, take: scanAll ? 8 : 5);
    addAroundCell(engine.positionOf(opponent), radius: scanAll ? 2 : 1);
    addAroundCell(engine.positionOf(actor), radius: 1);

    if (scanAll) {
      for (var row = 0; row <= 7; row++) {
        for (var col = 0; col <= 7; col++) {
          add(row, col, WallOrientation.horizontal);
          add(row, col, WallOrientation.vertical);
        }
      }
    }

    final ranked = <_ScoredAction>[];
    for (final key in keys) {
      if (_deadline != null && DateTime.now().isAfter(_deadline!)) break;
      if (!engine.canPlaceWall(
        row: key.row,
        col: key.col,
        orientation: key.orientation,
      )) {
        continue;
      }

      final copy = engine.clone();
      copy.walls.add(
        Wall(
          row: key.row,
          col: key.col,
          orientation: key.orientation,
          owner: actor,
        ),
      );

      final afterOwn = copy.shortestPathLength(actor) ?? 99;
      final afterOpponent = copy.shortestPathLength(opponent) ?? 99;
      final opponentDelta = afterOpponent - beforeOpponent;
      final ownDelta = afterOwn - beforeOwn;
      final opponentWasThreatening = _hasImmediateWinningMove(engine, opponent);
      final stopsImmediateWin = opponentWasThreatening &&
          !_hasImmediateWinningMove(copy, opponent);
      final afterOpponentOptions = opponentDelta > 0 || stopsImmediateWin
          ? _shortestStepOptions(copy, opponent)
          : beforeOpponentOptions;
      final optionReduction = beforeOpponentOptions - afterOpponentOptions;

      var score = opponentDelta * 2200 - ownDelta * 2500;
      score += optionReduction * 180;
      score += stopsImmediateWin ? 90000 : 0;
      score += _wallProximityScore(key, engine.positionOf(opponent));
      score += _opponentStyle.lanePressureBonus(key);
      if (opponentDelta <= 0 && !stopsImmediateWin) score -= 1100;
      if (ownDelta > opponentDelta) score -= 900;
      if (engine.wallsOf(actor) <= _profile.minimumWallReserve &&
          !stopsImmediateWin) {
        score -= 1200;
      }

      if (score >= _profile.minimumCandidateWallScore || scanAll) {
        ranked.add(
          _ScoredAction(
            BotAction.wall(key.row, key.col, key.orientation),
            score,
          ),
        );
      }
    }

    ranked.sort((a, b) => b.score.compareTo(a.score));
    return ranked.take(maximum).map((entry) => entry.action).toList(growable: false);
  }

  int _wallProximityScore(_WallKey wall, Cell opponent) {
    final centerRow = wall.row + 0.5;
    final centerCol = wall.col + 0.5;
    final distance = (centerRow - opponent.row).abs() +
        (centerCol - opponent.col).abs();
    return max(0, (8 - distance * 2).round()) * 20;
  }

  int _immediateActionScore(
    GameEngine engine,
    BotAction action,
    Player root,
  ) {
    final actor = engine.turn;
    final beforeOwnPath = engine.shortestPathLength(actor) ?? 99;
    final beforeOpponentPath = engine.shortestPathLength(actor.opponent) ?? 99;
    final beforeOwnPosition = engine.positionOf(actor);
    final beforeOpponentThreat = _hasImmediateWinningMove(engine, actor.opponent);

    final copy = engine.clone();
    if (!_apply(copy, action)) return -1000000000;
    if (copy.winner == actor) {
      return actor == root ? 900000000 : -900000000;
    }

    final afterOwnPath = copy.shortestPathLength(actor) ?? 99;
    final afterOpponentPath = copy.shortestPathLength(actor.opponent) ?? 99;
    final ownDelta = afterOwnPath - beforeOwnPath;
    final opponentDelta = afterOpponentPath - beforeOpponentPath;
    final afterActorPosition = copy.positionOf(actor);
    final progressDelta = _progressOf(afterActorPosition, actor) -
        _progressOf(beforeOwnPosition, actor);
    final blocksImmediateThreat = beforeOpponentThreat &&
        !_hasImmediateWinningMove(copy, actor.opponent);
    final givesOpponentImmediateWin = _hasImmediateWinningMove(copy, copy.turn);

    var actorScore = 0;
    actorScore += -ownDelta * 2100;
    actorScore += opponentDelta * 1850;
    actorScore += progressDelta * 260;
    actorScore += blocksImmediateThreat ? 120000 : 0;
    actorScore -= givesOpponentImmediateWin ? 180000 : 0;

    // When evaluating the human side, use observed play style only as a small
    // prediction prior. Minimax still protects against the objectively best
    // reply, while likely replies are ordered and valued slightly earlier.
    if (actor == root.opponent) {
      actorScore += _predictedOpponentActionBonus(engine, action, actor);
    }

    if (action.isWall) {
      actorScore -= 170;
      if (opponentDelta <= 0) actorScore -= 1200;
      if (ownDelta > opponentDelta) actorScore -= 1500;
      if (engine.wallsOf(actor) <= _profile.minimumWallReserve &&
          !blocksImmediateThreat) {
        actorScore -= 1000;
      }
    } else if (progressDelta < 0 && ownDelta >= 0) {
      actorScore -= 1800;
    }

    final evaluation = _evaluate(copy, root);
    final signedActorScore = actor == root ? actorScore : -actorScore;
    return evaluation + signedActorScore;
  }

  int _evaluate(GameEngine engine, Player root) {
    if (engine.winner == root) return 500000000 - engine.turnNumber;
    if (engine.winner == root.opponent) return -500000000 + engine.turnNumber;

    final ownPath = engine.shortestPathLength(root) ?? 99;
    final opponentPath = engine.shortestPathLength(root.opponent) ?? 99;
    final ownWalls = engine.wallsOf(root);
    final opponentWalls = engine.wallsOf(root.opponent);
    final ownPosition = engine.positionOf(root);
    final opponentPosition = engine.positionOf(root.opponent);
    final ownProgress = _progressOf(ownPosition, root);
    final opponentProgress = _progressOf(opponentPosition, root.opponent);
    final ownWinningMoves = _winningMoveCount(engine, root);
    final opponentWinningMoves = _winningMoveCount(engine, root.opponent);
    final ownOptions = _shortestStepOptions(engine, root);
    final opponentOptions = _shortestStepOptions(engine, root.opponent);
    final ownMobility = engine.legalMoves(root).length;
    final opponentMobility = engine.legalMoves(root.opponent).length;

    var score = 0;
    score += (opponentPath - ownPath) * 1250;
    score += (ownProgress - opponentProgress) * 75;
    score += (ownWalls - opponentWalls) * 42;
    score += (ownOptions - opponentOptions) * 26;
    score += (ownMobility - opponentMobility) * 11;
    score += ownWinningMoves * 90000;
    score -= opponentWinningMoves * 110000;

    if (ownPath <= 2) score += 18000;
    if (opponentPath <= 2) score -= 23000;
    if (ownPath <= 4 && ownWalls > 0) score += ownWalls * 40;
    if (opponentPath <= 4 && ownWalls == 0) score -= 2600;
    if (_opponentStyle.forwardRate >= 0.72 && opponentPath <= 5) {
      score -= ((_opponentStyle.forwardRate - 0.65) * 4200).round();
    }
    if (_opponentStyle.wallRate >= 0.42) {
      score += ownOptions * 34;
      score += ownWalls * 28;
    }
    if (engine.turn == root) score += 30;

    return score;
  }

  int _predictedOpponentActionBonus(
    GameEngine engine,
    BotAction action,
    Player actor,
  ) {
    if (action.isWall) {
      return (_opponentStyle.wallRate * 260).round();
    }
    if (!action.isMove) return 0;

    final from = engine.positionOf(actor);
    final to = action.cell!;
    final progress = _progressOf(to, actor) - _progressOf(from, actor);
    final forwardPreference =
        (max(0, progress) * _opponentStyle.forwardRate * 240).round();
    final laneDistance = (to.col - _opponentStyle.averageColumn).abs();
    final lanePreference = max(0, (4.5 - laneDistance).round()) * 18;
    return forwardPreference + lanePreference;
  }

  bool _isTacticalPosition(GameEngine engine) {
    final bluePath = engine.shortestPathLength(Player.blue) ?? 99;
    final redPath = engine.shortestPathLength(Player.red) ?? 99;
    return bluePath <= 3 ||
        redPath <= 3 ||
        _hasImmediateWinningMove(engine, Player.blue) ||
        _hasImmediateWinningMove(engine, Player.red);
  }

  BotAction? _immediateWinningAction(GameEngine engine, Player player) {
    if (engine.turn != player) return null;
    for (final move in engine.legalMoves(player)) {
      if (_isGoal(move, player)) return BotAction.move(move);
    }
    return null;
  }

  bool _hasImmediateWinningMove(GameEngine engine, Player player) {
    return _winningMoveCount(engine, player) > 0;
  }

  int _winningMoveCount(GameEngine engine, Player player) {
    var count = 0;
    for (final move in engine.legalMoves(player)) {
      if (_isGoal(move, player)) count++;
    }
    return count;
  }

  bool _isGoal(Cell cell, Player player) {
    return player == Player.blue
        ? cell.row == 0
        : cell.row == GameEngine.boardSize - 1;
  }

  int _shortestStepOptions(GameEngine engine, Player player) {
    final current = engine.shortestPathLength(player);
    if (current == null || current <= 0) return 0;
    var best = 999;
    var count = 0;
    final original = engine.positionOf(player);

    for (final move in engine.legalMoves(player)) {
      if (player == Player.blue) {
        engine.blue = move;
      } else {
        engine.red = move;
      }
      final length = engine.shortestPathLength(player) ?? 999;
      if (length < best) {
        best = length;
        count = 1;
      } else if (length == best) {
        count++;
      }
    }

    if (player == Player.blue) {
      engine.blue = original;
    } else {
      engine.red = original;
    }
    return count;
  }

  bool _apply(GameEngine engine, BotAction action) {
    if (action.isMove) return engine.move(action.cell!);
    if (action.isWall) {
      return engine.placeWall(
        row: action.row!,
        col: action.col!,
        orientation: action.orientation!,
      );
    }
    return false;
  }

  String _stateKey(
    GameEngine engine,
    int depth,
    Player root,
    int extensionLeft,
  ) {
    final sortedWalls = engine.walls.toList(growable: false)
      ..sort((a, b) {
        final row = a.row.compareTo(b.row);
        if (row != 0) return row;
        final col = a.col.compareTo(b.col);
        if (col != 0) return col;
        return a.orientation.index.compareTo(b.orientation.index);
      });
    final wallKey = sortedWalls
        .map((wall) => '${wall.row}${wall.col}${wall.orientation.index}')
        .join('.');
    return '${engine.blue.row},${engine.blue.col}|'
        '${engine.red.row},${engine.red.col}|'
        '${engine.turn.index}|${engine.blueWalls},${engine.redWalls}|'
        '$wallKey|$depth|$extensionLeft|${root.index}';
  }

  static int _progressOf(Cell cell, Player player) {
    return player == Player.blue
        ? GameEngine.boardSize - 1 - cell.row
        : cell.row;
  }
}

class BotAction {
  const BotAction._({this.cell, this.row, this.col, this.orientation});

  const BotAction.move(Cell cell) : this._(cell: cell);
  const BotAction.wall(int row, int col, WallOrientation orientation)
      : this._(row: row, col: col, orientation: orientation);
  const BotAction.none() : this._();

  final Cell? cell;
  final int? row;
  final int? col;
  final WallOrientation? orientation;

  bool get isMove => cell != null;
  bool get isWall => row != null && col != null && orientation != null;

  Map<String, Object?> toMap() {
    if (isMove) {
      return <String, Object?>{
        'type': 'move',
        'row': cell!.row,
        'col': cell!.col,
      };
    }
    if (isWall) {
      return <String, Object?>{
        'type': 'wall',
        'row': row,
        'col': col,
        'orientation': orientation!.index,
      };
    }
    return const <String, Object?>{'type': 'none'};
  }

  factory BotAction.fromMap(Map<String, Object?> map) {
    if (map['type'] == 'move') {
      return BotAction.move(
        Cell(
          (map['row'] as num? ?? 0).toInt(),
          (map['col'] as num? ?? 0).toInt(),
        ),
      );
    }
    if (map['type'] == 'wall') {
      final orientationIndex = ((map['orientation'] as num? ?? 0)
          .toInt()
          .clamp(0, WallOrientation.values.length - 1)) as int;
      return BotAction.wall(
        (map['row'] as num? ?? 0).toInt(),
        (map['col'] as num? ?? 0).toInt(),
        WallOrientation.values[orientationIndex],
      );
    }
    return const BotAction.none();
  }

  @override
  bool operator ==(Object other) {
    return other is BotAction &&
        other.cell == cell &&
        other.row == row &&
        other.col == col &&
        other.orientation == orientation;
  }

  @override
  int get hashCode => Object.hash(cell, row, col, orientation);
}

class _AiProfile {
  const _AiProfile({
    required this.searchBudget,
    required this.maxDepth,
    required this.rootActionLimit,
    required this.shallowBranchLimit,
    required this.middleBranchLimit,
    required this.deepBranchLimit,
    required this.rootWallLimit,
    required this.childWallLimit,
    required this.topChoiceCount,
    required this.choiceWindow,
    required this.minimumWallReserve,
    required this.minimumCandidateWallScore,
    required this.scanAllWallsAtRoot,
    required this.useTransposition,
    required this.tacticalExtensions,
  });

  final Duration searchBudget;
  final int maxDepth;
  final int rootActionLimit;
  final int shallowBranchLimit;
  final int middleBranchLimit;
  final int deepBranchLimit;
  final int rootWallLimit;
  final int childWallLimit;
  final int topChoiceCount;
  final int choiceWindow;
  final int minimumWallReserve;
  final int minimumCandidateWallScore;
  final bool scanAllWallsAtRoot;
  final bool useTransposition;
  final int tacticalExtensions;

  factory _AiProfile.forDifficulty(BotDifficulty difficulty, int turnNumber) {
    switch (difficulty) {
      case BotDifficulty.easy:
        return _AiProfile(
          searchBudget: const Duration(milliseconds: 340),
          maxDepth: 3,
          rootActionLimit: 18,
          shallowBranchLimit: 11,
          middleBranchLimit: 8,
          deepBranchLimit: 6,
          rootWallLimit: 16,
          childWallLimit: 8,
          topChoiceCount: 4,
          choiceWindow: 720,
          minimumWallReserve: 3,
          minimumCandidateWallScore: 20,
          scanAllWallsAtRoot: false,
          useTransposition: true,
          tacticalExtensions: 1,
        );
      case BotDifficulty.normal:
        return _AiProfile(
          searchBudget: const Duration(milliseconds: 780),
          maxDepth: turnNumber > 24 ? 5 : 4,
          rootActionLimit: 29,
          shallowBranchLimit: 17,
          middleBranchLimit: 12,
          deepBranchLimit: 8,
          rootWallLimit: 32,
          childWallLimit: 15,
          topChoiceCount: 2,
          choiceWindow: 120,
          minimumWallReserve: 2,
          minimumCandidateWallScore: -300,
          scanAllWallsAtRoot: true,
          useTransposition: true,
          tacticalExtensions: 1,
        );
      case BotDifficulty.hard:
        return _AiProfile(
          searchBudget: const Duration(milliseconds: 1020),
          maxDepth: turnNumber > 20 ? 6 : 5,
          rootActionLimit: 35,
          shallowBranchLimit: 20,
          middleBranchLimit: 15,
          deepBranchLimit: 10,
          rootWallLimit: 42,
          childWallLimit: 19,
          topChoiceCount: 1,
          choiceWindow: 0,
          minimumWallReserve: 1,
          minimumCandidateWallScore: -650,
          scanAllWallsAtRoot: true,
          useTransposition: true,
          tacticalExtensions: 2,
        );
      case BotDifficulty.extreme:
        return _AiProfile(
          searchBudget: const Duration(milliseconds: 1220),
          maxDepth: turnNumber > 16 ? 7 : 6,
          rootActionLimit: 44,
          shallowBranchLimit: 24,
          middleBranchLimit: 18,
          deepBranchLimit: 12,
          rootWallLimit: 56,
          childWallLimit: 24,
          topChoiceCount: 1,
          choiceWindow: 0,
          minimumWallReserve: 1,
          minimumCandidateWallScore: -1000,
          scanAllWallsAtRoot: true,
          useTransposition: true,
          tacticalExtensions: 2,
        );
    }
  }

}


class _PlayerStyle {
  const _PlayerStyle({
    required this.forwardRate,
    required this.wallRate,
    required this.averageColumn,
  });

  const _PlayerStyle.neutral()
      : forwardRate = 0.5,
        wallRate = 0.25,
        averageColumn = 4.0;

  final double forwardRate;
  final double wallRate;
  final double averageColumn;

  factory _PlayerStyle.fromHistory(
    List<MoveRecord> history,
    Player player,
  ) {
    final records = history
        .where((record) => record.player == player)
        .toList(growable: false);
    if (records.length < 3) return const _PlayerStyle.neutral();

    var moveCount = 0;
    var forwardMoves = 0;
    var wallCount = 0;
    var columnTotal = 0.0;

    for (final record in records) {
      if (record.isWall) {
        wallCount++;
        continue;
      }
      moveCount++;
      final from = record.from!;
      final to = record.to!;
      columnTotal += to.col;
      final progress = BotPlayer._progressOf(to, player) -
          BotPlayer._progressOf(from, player);
      if (progress > 0) forwardMoves++;
    }

    final total = max(1, records.length);
    return _PlayerStyle(
      forwardRate: moveCount == 0 ? 0.5 : forwardMoves / moveCount,
      wallRate: wallCount / total,
      averageColumn: moveCount == 0 ? 4.0 : columnTotal / moveCount,
    );
  }

  int lanePressureBonus(_WallKey wall) {
    final wallCenter = wall.col + 0.5;
    final distance = (wallCenter - averageColumn).abs();
    return max(0, (4.5 - distance).round()) * 24;
  }
}

class _ScoredAction {
  const _ScoredAction(this.action, this.score);

  final BotAction action;
  final int score;
}

class _RootSearchResult {
  const _RootSearchResult({required this.completed, required this.ranked});

  final bool completed;
  final List<_ScoredAction> ranked;
}

class _WallKey {
  const _WallKey(this.row, this.col, this.orientation);

  final int row;
  final int col;
  final WallOrientation orientation;

  @override
  bool operator ==(Object other) {
    return other is _WallKey &&
        other.row == row &&
        other.col == col &&
        other.orientation == orientation;
  }

  @override
  int get hashCode => Object.hash(row, col, orientation);
}
