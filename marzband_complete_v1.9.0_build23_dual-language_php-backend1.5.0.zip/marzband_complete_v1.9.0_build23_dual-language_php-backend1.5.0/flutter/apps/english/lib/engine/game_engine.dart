import 'dart:collection';

import '../models/game_models.dart';

class GameEngine {
  GameEngine({this.mode = GameMode.local});

  static const int boardSize = 9;
  static const int initialWalls = 10;

  final GameMode mode;

  Cell blue = const Cell(8, 4);
  Cell red = const Cell(0, 4);
  Player turn = Player.blue;
  Player? winner;
  int blueWalls = initialWalls;
  int redWalls = initialWalls;
  int turnNumber = 1;
  final List<Wall> walls = <Wall>[];
  final List<MoveRecord> history = <MoveRecord>[];

  Cell positionOf(Player player) => player == Player.blue ? blue : red;

  GameEngine clone() {
    final copy = GameEngine(mode: mode)
      ..blue = blue
      ..red = red
      ..turn = turn
      ..winner = winner
      ..blueWalls = blueWalls
      ..redWalls = redWalls
      ..turnNumber = turnNumber;
    copy.walls.addAll(walls);
    copy.history.addAll(history);
    return copy;
  }

  int wallsOf(Player player) =>
      player == Player.blue ? blueWalls : redWalls;

  Map<String, Object?> toSnapshot() {
    return <String, Object?>{
      'mode': mode.index,
      'blueRow': blue.row,
      'blueCol': blue.col,
      'redRow': red.row,
      'redCol': red.col,
      'turn': turn.index,
      'winner': winner?.index,
      'blueWalls': blueWalls,
      'redWalls': redWalls,
      'turnNumber': turnNumber,
      'walls': walls
          .map(
            (wall) => <String, Object?>{
              'row': wall.row,
              'col': wall.col,
              'orientation': wall.orientation.index,
              'owner': wall.owner.index,
            },
          )
          .toList(growable: false),
      'history': history.map((record) {
        if (record.isWall) {
          final wall = record.wall!;
          return <String, Object?>{
            'type': 'wall',
            'player': record.player.index,
            'row': wall.row,
            'col': wall.col,
            'orientation': wall.orientation.index,
          };
        }
        return <String, Object?>{
          'type': 'move',
          'player': record.player.index,
          'fromRow': record.from!.row,
          'fromCol': record.from!.col,
          'toRow': record.to!.row,
          'toCol': record.to!.col,
        };
      }).toList(growable: false),
    };
  }

  factory GameEngine.fromSnapshot(Map<String, Object?> snapshot) {
    int indexOf(Object? value, int maximum) {
      return ((value as num? ?? 0).toInt().clamp(0, maximum)) as int;
    }

    final mode = GameMode.values[indexOf(
      snapshot['mode'],
      GameMode.values.length - 1,
    )];
    final engine = GameEngine(mode: mode)
      ..blue = Cell(
        (snapshot['blueRow'] as num? ?? 8).toInt(),
        (snapshot['blueCol'] as num? ?? 4).toInt(),
      )
      ..red = Cell(
        (snapshot['redRow'] as num? ?? 0).toInt(),
        (snapshot['redCol'] as num? ?? 4).toInt(),
      )
      ..turn = Player.values[indexOf(
        snapshot['turn'],
        Player.values.length - 1,
      )]
      ..winner = snapshot['winner'] == null
          ? null
          : Player.values[indexOf(
              snapshot['winner'],
              Player.values.length - 1,
            )]
      ..blueWalls = (snapshot['blueWalls'] as num? ?? initialWalls).toInt()
      ..redWalls = (snapshot['redWalls'] as num? ?? initialWalls).toInt()
      ..turnNumber = (snapshot['turnNumber'] as num? ?? 1).toInt();

    final rawWalls = snapshot['walls'];
    if (rawWalls is List<Object?>) {
      for (final raw in rawWalls.whereType<Map<Object?, Object?>>()) {
        final wall = raw.cast<String, Object?>();
        engine.walls.add(
          Wall(
            row: (wall['row'] as num? ?? 0).toInt(),
            col: (wall['col'] as num? ?? 0).toInt(),
            orientation: WallOrientation.values[indexOf(
              wall['orientation'],
              WallOrientation.values.length - 1,
            )],
            owner: Player.values[indexOf(
              wall['owner'],
              Player.values.length - 1,
            )],
          ),
        );
      }
    }

    final rawHistory = snapshot['history'];
    if (rawHistory is List<Object?>) {
      for (final raw in rawHistory.whereType<Map<Object?, Object?>>()) {
        final record = raw.cast<String, Object?>();
        final player = Player.values[indexOf(
          record['player'],
          Player.values.length - 1,
        )];
        if (record['type'] == 'wall') {
          final wall = Wall(
            row: (record['row'] as num? ?? 0).toInt(),
            col: (record['col'] as num? ?? 0).toInt(),
            orientation: WallOrientation.values[indexOf(
              record['orientation'],
              WallOrientation.values.length - 1,
            )],
            owner: player,
          );
          engine.history.add(MoveRecord.wall(player: player, wall: wall));
        } else if (record['type'] == 'move') {
          engine.history.add(
            MoveRecord.move(
              player: player,
              from: Cell(
                (record['fromRow'] as num? ?? 0).toInt(),
                (record['fromCol'] as num? ?? 0).toInt(),
              ),
              to: Cell(
                (record['toRow'] as num? ?? 0).toInt(),
                (record['toCol'] as num? ?? 0).toInt(),
              ),
            ),
          );
        }
      }
    }
    return engine;
  }

  bool get isFinished => winner != null;

  bool isInside(Cell cell) =>
      cell.row >= 0 &&
      cell.row < boardSize &&
      cell.col >= 0 &&
      cell.col < boardSize;

  Set<Cell> legalMoves([Player? forPlayer]) {
    final player = forPlayer ?? turn;
    final origin = positionOf(player);
    final opponent = positionOf(player.opponent);
    final result = <Cell>{};
    const directions = <(int, int)>[(1, 0), (-1, 0), (0, 1), (0, -1)];

    for (final (dr, dc) in directions) {
      final adjacent = origin.translate(dr, dc);
      if (!isInside(adjacent) || isBlocked(origin, adjacent)) {
        continue;
      }
      if (adjacent != opponent) {
        result.add(adjacent);
        continue;
      }

      final beyond = adjacent.translate(dr, dc);
      if (isInside(beyond) && !isBlocked(adjacent, beyond)) {
        result.add(beyond);
        continue;
      }

      final sideDirections = dr == 0
          ? const <(int, int)>[(1, 0), (-1, 0)]
          : const <(int, int)>[(0, 1), (0, -1)];
      for (final (sdr, sdc) in sideDirections) {
        final diagonal = adjacent.translate(sdr, sdc);
        if (isInside(diagonal) && !isBlocked(adjacent, diagonal)) {
          result.add(diagonal);
        }
      }
    }
    return result;
  }

  bool expireTurn() {
    if (isFinished) return false;
    _switchTurn();
    return true;
  }

  bool resign([Player? player]) {
    if (isFinished) return false;
    winner = (player ?? turn).opponent;
    return true;
  }

  bool move(Cell destination) {
    if (isFinished || !legalMoves().contains(destination)) {
      return false;
    }
    final player = turn;
    final from = positionOf(player);
    if (player == Player.blue) {
      blue = destination;
    } else {
      red = destination;
    }
    history.add(MoveRecord.move(player: player, from: from, to: destination));
    _resolveWinOrSwitch();
    return true;
  }

  bool canPlaceWall({
    required int row,
    required int col,
    required WallOrientation orientation,
    Player? forPlayer,
  }) {
    final player = forPlayer ?? turn;
    if (isFinished || wallsOf(player) <= 0) return false;
    if (row < 0 || row > 7 || col < 0 || col > 7) return false;

    final candidate = Wall(
      row: row,
      col: col,
      orientation: orientation,
      owner: player,
    );

    for (final existing in walls) {
      if (existing.orientation == orientation) {
        if (orientation == WallOrientation.horizontal &&
            existing.row == row &&
            (existing.col - col).abs() <= 1) {
          return false;
        }
        if (orientation == WallOrientation.vertical &&
            existing.col == col &&
            (existing.row - row).abs() <= 1) {
          return false;
        }
      } else if (existing.row == row && existing.col == col) {
        return false;
      }
    }

    walls.add(candidate);
    final blueHasPath = shortestPathLength(Player.blue) != null;
    final redHasPath = shortestPathLength(Player.red) != null;
    walls.removeLast();
    return blueHasPath && redHasPath;
  }

  bool placeWall({
    required int row,
    required int col,
    required WallOrientation orientation,
  }) {
    if (!canPlaceWall(row: row, col: col, orientation: orientation)) {
      return false;
    }
    final player = turn;
    final wall = Wall(
      row: row,
      col: col,
      orientation: orientation,
      owner: player,
    );
    walls.add(wall);
    if (player == Player.blue) {
      blueWalls--;
    } else {
      redWalls--;
    }
    history.add(MoveRecord.wall(player: player, wall: wall));
    _switchTurn();
    return true;
  }

  bool isBlocked(Cell a, Cell b) {
    final dr = b.row - a.row;
    final dc = b.col - a.col;
    if (dr.abs() + dc.abs() != 1) return true;

    if (dc == 1) {
      return walls.any(
        (wall) =>
            wall.orientation == WallOrientation.vertical &&
            wall.col == a.col &&
            (wall.row == a.row || wall.row == a.row - 1),
      );
    }
    if (dc == -1) {
      return walls.any(
        (wall) =>
            wall.orientation == WallOrientation.vertical &&
            wall.col == b.col &&
            (wall.row == a.row || wall.row == a.row - 1),
      );
    }
    if (dr == 1) {
      return walls.any(
        (wall) =>
            wall.orientation == WallOrientation.horizontal &&
            wall.row == a.row &&
            (wall.col == a.col || wall.col == a.col - 1),
      );
    }
    return walls.any(
      (wall) =>
          wall.orientation == WallOrientation.horizontal &&
          wall.row == b.row &&
          (wall.col == a.col || wall.col == a.col - 1),
    );
  }

  int? shortestPathLength(Player player) {
    final start = positionOf(player);
    final targetRow = player == Player.blue ? 0 : boardSize - 1;
    final queue = Queue<(Cell, int)>()..add((start, 0));
    final visited = <Cell>{start};
    const directions = <(int, int)>[(1, 0), (-1, 0), (0, 1), (0, -1)];

    while (queue.isNotEmpty) {
      final (cell, distance) = queue.removeFirst();
      if (cell.row == targetRow) return distance;
      for (final (dr, dc) in directions) {
        final next = cell.translate(dr, dc);
        if (!isInside(next) || visited.contains(next) || isBlocked(cell, next)) {
          continue;
        }
        visited.add(next);
        queue.add((next, distance + 1));
      }
    }
    return null;
  }

  List<Cell> shortestPath(Player player) {
    final start = positionOf(player);
    final targetRow = player == Player.blue ? 0 : boardSize - 1;
    final queue = Queue<Cell>()..add(start);
    final visited = <Cell>{start};
    final parent = <Cell, Cell>{};
    const directions = <(int, int)>[(1, 0), (-1, 0), (0, 1), (0, -1)];

    Cell? target;
    while (queue.isNotEmpty) {
      final cell = queue.removeFirst();
      if (cell.row == targetRow) {
        target = cell;
        break;
      }
      for (final (dr, dc) in directions) {
        final next = cell.translate(dr, dc);
        if (!isInside(next) || visited.contains(next) || isBlocked(cell, next)) {
          continue;
        }
        visited.add(next);
        parent[next] = cell;
        queue.add(next);
      }
    }
    if (target == null) return const <Cell>[];

    final path = <Cell>[target];
    var cursor = target;
    while (cursor != start) {
      cursor = parent[cursor]!;
      path.add(cursor);
    }
    return path.reversed.toList(growable: false);
  }

  void _resolveWinOrSwitch() {
    if (blue.row == 0) {
      winner = Player.blue;
      return;
    }
    if (red.row == boardSize - 1) {
      winner = Player.red;
      return;
    }
    _switchTurn();
  }

  void _switchTurn() {
    turn = turn.opponent;
    turnNumber++;
  }
}
