import 'dart:async';
import 'dart:math';

import '../config/network_config.dart';
import '../models/game_models.dart';
import '../services/api_client.dart';
import '../services/device_identity.dart';
import '../state/auth_state.dart';
import '../state/player_preferences.dart';
import 'online_match_models.dart';

class OnlineGameException implements Exception {
  const OnlineGameException(this.message);
  final String message;
  @override
  String toString() => message;
}

class OnlineGameService {
  OnlineGameService._();

  static final OnlineGameService instance = OnlineGameService._();
  final StreamController<OnlineStateEvent> _stateController =
      StreamController<OnlineStateEvent>.broadcast();
  final StreamController<OnlineFinishedEvent> _finishedController =
      StreamController<OnlineFinishedEvent>.broadcast();
  final StreamController<String> _reactionController =
      StreamController<String>.broadcast();
  final StreamController<bool> _opponentConnectionController =
      StreamController<bool>.broadcast();
  final StreamController<String> _errorController =
      StreamController<String>.broadcast();

  Timer? _presenceTimer;
  Timer? _matchPollTimer;
  bool _searching = false;
  bool _searchCancelled = false;
  bool _matchPollInFlight = false;
  bool _reachable = false;
  int _lastRevision = -1;
  int _lastReactionSeq = 0;
  bool? _lastOpponentConnected;
  String? _activeMatchId;
  OnlineMatchKind? _activeKind;

  Stream<OnlineStateEvent> get states => _stateController.stream;
  Stream<OnlineFinishedEvent> get finished => _finishedController.stream;
  Stream<String> get reactions => _reactionController.stream;
  Stream<bool> get opponentConnection => _opponentConnectionController.stream;
  Stream<String> get errors => _errorController.stream;
  bool get isConnected => _reachable;

  Future<void> initializePresence() async {
    if (!AuthState.instance.isLoggedIn) return;
    await _sendPresence(silent: true);
    _presenceTimer ??= Timer.periodic(
      NetworkConfig.presenceInterval,
      (_) {
        if (AuthState.instance.isLoggedIn) {
          unawaited(_sendPresence(silent: true));
        }
      },
    );
  }

  Future<OnlineMatchSession> findMatch() async {
    if (_searching) {
      throw const OnlineGameException('A matchmaking search is already active.');
    }
    _searching = true;
    _searchCancelled = false;
    final started = DateTime.now();
    final requestId = _requestId('queue');

    try {
      var payload = await _post(
        '/matchmaking_join.php',
        <String, Object?>{
          ...await _profilePayload(),
          'requestId': requestId,
        },
      );

      while (true) {
        if (_searchCancelled) {
          throw const OnlineGameException('Search cancelled.');
        }
        final session = _sessionFromMatchmaking(payload);
        if (session != null) return session;

        if (DateTime.now().difference(started) >
            NetworkConfig.matchmakingTimeout) {
          throw const OnlineGameException(
            'The server did not answer. Check your connection and try again.',
          );
        }

        await Future<void>.delayed(NetworkConfig.pollInterval);
        payload = await _post(
          '/matchmaking_status.php',
          await _profilePayload(),
        );
      }
    } finally {
      _searching = false;
    }
  }

  OnlineMatchSession? _sessionFromMatchmaking(Map<String, Object?> payload) {
    final status = payload['status'] as String? ?? '';
    if (status != 'matched' && status != 'bot') {
      if (status == 'cancelled') {
        throw const OnlineGameException('Search cancelled.');
      }
      return null;
    }
    final raw = payload['session'];
    if (raw is! Map<Object?, Object?>) {
      throw const OnlineGameException('The matchmaking response is incomplete.');
    }
    final kind = status == 'matched'
        ? OnlineMatchKind.real
        : OnlineMatchKind.bot;
    final session = OnlineMatchSession.fromPayload(
      raw.cast<String, Object?>(),
      kind: kind,
    );
    if (session.matchId.isEmpty) {
      throw const OnlineGameException('The match identifier is missing.');
    }
    _activeMatchId = session.matchId;
    _activeKind = kind;
    if (kind == OnlineMatchKind.real) _startMatchPolling(session.matchId);
    return session;
  }

  void cancelMatchmaking() {
    _searchCancelled = true;
    unawaited(_postSilently('/matchmaking_cancel.php', _profilePayload));
  }

  void sendMove(String matchId, Cell destination) {
    unawaited(
      _sendAction(matchId, <String, Object?>{
        'type': 'move',
        'destination': <String, int>{
          'row': destination.row,
          'col': destination.col,
        },
      }),
    );
  }

  void sendWall(
    String matchId,
    int row,
    int col,
    WallOrientation orientation,
  ) {
    unawaited(
      _sendAction(matchId, <String, Object?>{
        'type': 'wall',
        'row': row,
        'col': col,
        'orientation': orientation == WallOrientation.horizontal
            ? 'horizontal'
            : 'vertical',
      }),
    );
  }

  Future<void> _sendAction(
    String matchId,
    Map<String, Object?> action,
  ) async {
    try {
      final payload = await _post(
        '/match_action.php',
        <String, Object?>{
          ...await _profilePayload(),
          'matchId': matchId,
          'requestId': _requestId('action'),
          'action': action,
        },
      );
      _handleMatchPayload(payload);
    } on OnlineGameException catch (error) {
      _errorController.add(error.message);
    } catch (_) {
      _errorController.add('The action could not be sent to the server.');
    }
  }

  void sendReaction(String matchId, String reaction) {
    unawaited(
      _postSilently(
        '/match_reaction.php',
        () async => <String, Object?>{
          ...await _profilePayload(),
          'matchId': matchId,
          'reaction': reaction,
        },
      ),
    );
  }

  void resign(String matchId) {
    unawaited(_endMatch(matchId, 'resigned', emitResult: true));
  }

  void leaveMatch(String matchId) {
    unawaited(_endMatch(matchId, 'left', emitResult: false));
    clearActiveMatch(matchId);
  }

  void cancelBotMatch(String matchId) {
    unawaited(_endMatch(matchId, 'bot_cancelled', emitResult: false));
    clearActiveMatch(matchId);
  }

  Future<void> _endMatch(
    String matchId,
    String reason, {
    required bool emitResult,
  }) async {
    try {
      final payload = await _post(
        '/match_end.php',
        <String, Object?>{
          ...await _profilePayload(),
          'matchId': matchId,
          'reason': reason,
        },
      );
      if (emitResult) {
        final raw = payload['finished'];
        if (raw is Map<Object?, Object?>) {
          _emitFinished(raw.cast<String, Object?>());
        }
      }
    } on OnlineGameException catch (error) {
      if (emitResult) _errorController.add(error.message);
    }
  }

  Future<OnlineFinishedEvent> reportBotResult({
    required String matchId,
    required bool won,
    required int movesCount,
    required String reason,
  }) async {
    final payload = await _post(
      '/bot_result.php',
      <String, Object?>{
        ...await _profilePayload(),
        'matchId': matchId,
        'won': won,
        'movesCount': movesCount,
        'reason': reason,
      },
    );
    final raw = payload['result'];
    if (raw is! Map<Object?, Object?>) {
      throw const OnlineGameException('The match result could not be saved.');
    }
    final event = OnlineFinishedEvent.fromPayload(
      raw.cast<String, Object?>(),
    );
    await PlayerPreferences.instance.syncFromServer();
    clearActiveMatch(matchId);
    return event;
  }

  void clearActiveMatch(String matchId) {
    if (_activeMatchId != matchId) return;
    _activeMatchId = null;
    _activeKind = null;
    _lastRevision = -1;
    _lastReactionSeq = 0;
    _lastOpponentConnected = null;
    _matchPollTimer?.cancel();
    _matchPollTimer = null;
  }

  void _startMatchPolling(String matchId) {
    _matchPollTimer?.cancel();
    _lastRevision = -1;
    _lastReactionSeq = 0;
    _lastOpponentConnected = null;
    unawaited(_pollMatch(matchId));
    _matchPollTimer = Timer.periodic(
      NetworkConfig.pollInterval,
      (_) => _pollMatch(matchId),
    );
  }

  Future<void> _pollMatch(String matchId) async {
    if (_matchPollInFlight ||
        _activeMatchId != matchId ||
        _activeKind != OnlineMatchKind.real) {
      return;
    }
    _matchPollInFlight = true;
    try {
      final payload = await _post(
        '/match_poll.php',
        <String, Object?>{
          ...await _profilePayload(),
          'matchId': matchId,
          'reactionSeq': _lastReactionSeq,
        },
      );
      _handleMatchPayload(payload);
    } on OnlineGameException catch (error) {
      _errorController.add(error.message);
    } catch (_) {
      _reachable = false;
    } finally {
      _matchPollInFlight = false;
    }
  }

  void _handleMatchPayload(Map<String, Object?> payload) {
    final status = payload['status'] as String? ?? '';
    if (status == 'finished') {
      final raw = payload['finished'];
      if (raw is Map<Object?, Object?>) {
        _emitFinished(raw.cast<String, Object?>());
      }
      return;
    }
    if (status != 'active') return;

    final revision = (payload['revision'] as num? ?? 0).toInt();
    final stateRaw = payload['state'];
    final matchId = payload['matchId'] as String? ?? _activeMatchId ?? '';
    final connected = payload['opponentConnected'] != false;

    if (_lastOpponentConnected != connected) {
      _lastOpponentConnected = connected;
      _opponentConnectionController.add(connected);
    }

    if (revision != _lastRevision && stateRaw is Map<Object?, Object?>) {
      _lastRevision = revision;
      _stateController.add(
        OnlineStateEvent(
          matchId: matchId,
          state: stateRaw.cast<String, Object?>(),
          turnEndsAt: _dateFromServerValue(payload['turnEndsAt']),
          opponentConnected: connected,
        ),
      );
    }

    final reactionRaw = payload['reaction'];
    if (reactionRaw is Map<Object?, Object?>) {
      final reaction = reactionRaw.cast<String, Object?>();
      final seq = (reaction['seq'] as num? ?? 0).toInt();
      final value = reaction['value'] as String? ?? '';
      if (seq > _lastReactionSeq) {
        _lastReactionSeq = seq;
        if (value.isNotEmpty) _reactionController.add(value);
      }
    }
  }

  void _emitFinished(Map<String, Object?> payload) {
    final event = OnlineFinishedEvent.fromPayload(payload);
    unawaited(PlayerPreferences.instance.syncFromServer());
    _finishedController.add(event);
    clearActiveMatch(event.matchId);
  }

  Future<void> _sendPresence({required bool silent}) async {
    try {
      final payload = await _post('/presence.php', await _profilePayload());
      await PlayerPreferences.instance.applyServerSnapshot(payload['user']);
    } catch (_) {
      if (!silent) rethrow;
    }
  }

  Future<Map<String, Object?>> _profilePayload() async {
    final auth = AuthState.instance;
    final preferences = PlayerPreferences.instance;
    return <String, Object?>{
      'deviceId': await _loadDeviceId(),
      'token': auth.authToken,
      'name': auth.name,
      'countryCode': auth.countryCode,
      'avatarKey': preferences.avatarChoice.name,
      'cups': preferences.cups,
      'registered': auth.hasRegisteredAccount,
    };
  }

  Future<Map<String, Object?>> _post(
    String path,
    Map<String, Object?> body,
  ) async {
    try {
      final payload = await ApiClient.post(path, body);
      _reachable = true;
      return payload;
    } on ApiClientException catch (error) {
      _reachable = false;
      throw OnlineGameException(error.message);
    } catch (_) {
      _reachable = false;
      throw const OnlineGameException('Unable to reach the game server.');
    }
  }

  Future<void> _postSilently(
    String path,
    Future<Map<String, Object?>> Function() bodyBuilder,
  ) async {
    try {
      await _post(path, await bodyBuilder());
    } catch (_) {
      // A later presence or polling request retries automatically.
    }
  }

  String _messageForServerError(String? code) {
    switch (code) {
      case 'not_your_turn':
        return 'It is not your turn.';
      case 'invalid_action':
        return 'That move is not valid.';
      case 'match_not_found':
        return 'The match could not be found.';
      case 'match_access_denied':
        return 'This match is no longer available.';
      default:
        return code?.isNotEmpty == true ? code! : 'Server error.';
    }
  }

  String _requestId(String prefix) {
    final random = Random.secure();
    return '$prefix-${DateTime.now().microsecondsSinceEpoch.toRadixString(16)}-'
        '${random.nextInt(1 << 32).toRadixString(16)}';
  }

  Future<String> _loadDeviceId() => DeviceIdentity.load();
}

DateTime? _dateFromServerValue(Object? value) {
  final milliseconds = (value as num?)?.toInt();
  if (milliseconds == null || milliseconds <= 0) return null;
  return DateTime.fromMillisecondsSinceEpoch(milliseconds);
}
