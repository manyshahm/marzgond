import '../state/player_preferences.dart';

enum OnlineMatchKind { real, bot }

class OnlineOpponent {
  const OnlineOpponent({
    required this.name,
    required this.countryCode,
    required this.avatarKey,
    required this.cups,
  });

  final String name;
  final String countryCode;
  final String avatarKey;
  final int cups;

  AvatarChoice get avatarChoice {
    for (final choice in AvatarChoice.values) {
      if (choice.name == avatarKey) return choice;
    }
    return AvatarChoice.guest;
  }

  factory OnlineOpponent.fromMap(Map<String, Object?> map) {
    return OnlineOpponent(
      name: map['name'] as String? ?? 'Opponent',
      countryCode: map['countryCode'] as String? ?? 'US',
      avatarKey: map['avatarKey'] as String? ?? 'guest',
      cups: (map['cups'] as num? ?? 0).toInt(),
    );
  }
}

class OnlineMatchSession {
  const OnlineMatchSession({
    required this.matchId,
    required this.kind,
    required this.opponent,
    required this.initialState,
    required this.turnEndsAt,
  });

  final String matchId;
  final OnlineMatchKind kind;
  final OnlineOpponent opponent;
  final Map<String, Object?>? initialState;
  final DateTime? turnEndsAt;

  bool get isReal => kind == OnlineMatchKind.real;
  bool get isBot => kind == OnlineMatchKind.bot;

  factory OnlineMatchSession.fromPayload(
    Map<String, Object?> payload, {
    required OnlineMatchKind kind,
  }) {
    final opponentRaw = payload['opponent'];
    final stateRaw = payload['state'];
    return OnlineMatchSession(
      matchId: payload['matchId'] as String? ?? '',
      kind: kind,
      opponent: OnlineOpponent.fromMap(
        opponentRaw is Map<Object?, Object?>
            ? opponentRaw.cast<String, Object?>()
            : const <String, Object?>{},
      ),
      initialState: stateRaw is Map<Object?, Object?>
          ? stateRaw.cast<String, Object?>()
          : null,
      turnEndsAt: _dateFromMilliseconds(payload['turnEndsAt']),
    );
  }
}

class OnlineStateEvent {
  const OnlineStateEvent({
    required this.matchId,
    required this.state,
    required this.turnEndsAt,
    required this.opponentConnected,
  });

  final String matchId;
  final Map<String, Object?> state;
  final DateTime? turnEndsAt;
  final bool opponentConnected;

  factory OnlineStateEvent.fromPayload(Map<String, Object?> payload) {
    final stateRaw = payload['state'];
    return OnlineStateEvent(
      matchId: payload['matchId'] as String? ?? '',
      state: stateRaw is Map<Object?, Object?>
          ? stateRaw.cast<String, Object?>()
          : const <String, Object?>{},
      turnEndsAt: _dateFromMilliseconds(payload['turnEndsAt']),
      opponentConnected: payload['opponentConnected'] != false,
    );
  }
}

class OnlineFinishedEvent {
  const OnlineFinishedEvent({
    required this.matchId,
    required this.state,
    required this.won,
    required this.finishReason,
    required this.cupBefore,
    required this.cupDelta,
    required this.cupAfter,
    required this.coinBefore,
    required this.coinDelta,
    required this.coinAfter,
    required this.league,
    required this.durationSeconds,
  });

  final String matchId;
  final Map<String, Object?>? state;
  final bool won;
  final String finishReason;
  final int cupBefore;
  final int cupDelta;
  final int cupAfter;
  final int coinBefore;
  final int coinDelta;
  final int coinAfter;
  final String league;
  final int durationSeconds;

  factory OnlineFinishedEvent.fromPayload(Map<String, Object?> payload) {
    final stateRaw = payload['state'];
    return OnlineFinishedEvent(
      matchId: payload['matchId'] as String? ?? '',
      state: stateRaw is Map<Object?, Object?>
          ? stateRaw.cast<String, Object?>()
          : null,
      won: payload['won'] == true,
      finishReason: payload['finishReason'] as String? ?? 'completed',
      cupBefore: (payload['cupBefore'] as num? ?? 0).toInt(),
      cupDelta: (payload['cupDelta'] as num? ?? 0).toInt(),
      cupAfter: (payload['cupAfter'] as num? ?? 0).toInt(),
      coinBefore: (payload['coinBefore'] as num? ?? 0).toInt(),
      coinDelta: (payload['coinDelta'] as num? ?? 0).toInt(),
      coinAfter: (payload['coinAfter'] as num? ?? 0).toInt(),
      league: payload['league'] as String? ?? 'Bronze',
      durationSeconds: (payload['durationSeconds'] as num? ?? 0).toInt(),
    );
  }
}

DateTime? _dateFromMilliseconds(Object? value) {
  final milliseconds = (value as num?)?.toInt();
  if (milliseconds == null || milliseconds <= 0) return null;
  return DateTime.fromMillisecondsSinceEpoch(milliseconds);
}
