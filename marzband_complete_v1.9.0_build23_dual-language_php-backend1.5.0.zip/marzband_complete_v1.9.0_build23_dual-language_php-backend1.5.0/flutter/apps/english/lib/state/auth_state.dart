import 'package:flutter/foundation.dart';

import '../models/country.dart';
import '../services/api_client.dart';
import '../services/device_identity.dart';
import '../services/local_storage.dart';
import '../services/network_status.dart';

class PasswordResetRequestResult {
  const PasswordResetRequestResult({
    required this.code,
    required this.expiresInSeconds,
  });

  final String code;
  final int expiresInSeconds;
}

class AuthState extends ChangeNotifier {
  AuthState._();

  static final AuthState instance = AuthState._();

  static const String _loggedInKey = 'auth_logged_in';
  static const String _rememberKey = 'auth_remember_me';
  static const String _nameKey = 'auth_name';
  static const String _emailKey = 'auth_email';
  static const String _tokenKey = 'auth_server_token_v2';
  static const String _countryKey = 'auth_country_code';

  bool _initialized = false;
  bool _loggedIn = false;
  bool _rememberMe = true;
  String _name = '';
  String _email = '';
  String _token = '';
  String _countryCode = 'US';

  bool get initialized => _initialized;
  bool get isLoggedIn => _loggedIn;
  bool get rememberMe => _rememberMe;
  String get name => _name.isEmpty ? 'Guest Player' : _name;
  String get email => _email;
  String get authToken => _token;
  String get countryCode => _countryCode;
  CountryInfo get country => Countries.byCode(_countryCode);
  bool get hasRegisteredAccount => _token.isNotEmpty && _email.isNotEmpty;

  Future<void> initialize() async {
    if (_initialized) return;
    try {
      _name = await LocalStorage.readString(_nameKey) ?? '';
      _email = await LocalStorage.readString(_emailKey) ?? '';
      _token = await LocalStorage.readString(_tokenKey) ?? '';
      _countryCode = await LocalStorage.readString(_countryKey) ?? 'US';
      _rememberMe = await LocalStorage.readBool(_rememberKey) ?? true;
      final storedLogin = await LocalStorage.readBool(_loggedInKey) ?? false;
      _loggedIn = _rememberMe && storedLogin && hasRegisteredAccount;
      if (_loggedIn) {
        try {
          final payload = await ApiClient.post(
            '/account_me.php',
            <String, Object?>{'token': _token},
          );
          _applyUserPayload(payload['user']);
          await _persistProfile();
        } on ApiClientException catch (error) {
          if (error.statusCode == 401 || error.code == 'authentication_required') {
            await _clearSession();
          }
        }
      }
    } catch (_) {
      _loggedIn = false;
      _rememberMe = true;
      _token = '';
    }
    _initialized = true;
    notifyListeners();
  }

  Future<String?> register({
    required String name,
    required String email,
    required String password,
    required CountryInfo country,
  }) async {
    if (!NetworkStatus.instance.isOnline) return 'No internet connection.';
    final normalizedName = name.trim();
    final normalizedEmail = email.trim().toLowerCase();
    final validName = RegExp(r'^[A-Za-z0-9 ]+$').hasMatch(normalizedName);
    if (normalizedName.length < 2 || normalizedName.length > 24) {
      return 'Player name must be between 2 and 24 characters.';
    }
    if (!validName) return 'Use English letters, numbers, and spaces only.';
    if (!_isValidEmail(normalizedEmail)) return 'Enter a valid email address.';
    if (password.length < 8) return 'Password must contain at least 8 characters.';

    try {
      final payload = await ApiClient.post(
        '/account_register.php',
        <String, Object?>{
          'name': normalizedName,
          'email': normalizedEmail,
          'password': password,
          'countryCode': country.code,
          'deviceId': await DeviceIdentity.load(),
          'avatarKey': 'guest',
        },
      );
      _token = payload['token'] as String? ?? '';
      if (_token.isEmpty) return 'The server did not create an account session.';
      _applyUserPayload(payload['user']);
      _loggedIn = true;
      _rememberMe = true;
      await _persistSession(persistToken: true);
      notifyListeners();
      return null;
    } on ApiClientException catch (error) {
      return error.message;
    } catch (_) {
      return 'Unable to reach the account server.';
    }
  }

  Future<String?> login({
    required String email,
    required String password,
    required bool rememberMe,
  }) async {
    if (!NetworkStatus.instance.isOnline) return 'No internet connection.';
    final normalizedEmail = email.trim().toLowerCase();
    if (!_isValidEmail(normalizedEmail)) return 'Enter a valid email address.';
    if (password.isEmpty) return 'Enter your password.';
    try {
      final payload = await ApiClient.post(
        '/account_login.php',
        <String, Object?>{
          'email': normalizedEmail,
          'password': password,
          'deviceId': await DeviceIdentity.load(),
          'avatarKey': 'guest',
        },
      );
      _token = payload['token'] as String? ?? '';
      if (_token.isEmpty) return 'The server did not create an account session.';
      _applyUserPayload(payload['user']);
      _rememberMe = rememberMe;
      _loggedIn = true;
      await _persistSession(persistToken: rememberMe);
      notifyListeners();
      return null;
    } on ApiClientException catch (error) {
      return error.message;
    } catch (_) {
      return 'Unable to reach the account server.';
    }
  }

  Future<PasswordResetRequestResult> requestPasswordReset(String email) async {
    if (!NetworkStatus.instance.isOnline) {
      throw const ApiClientException(message: 'No internet connection.');
    }
    final normalizedEmail = email.trim().toLowerCase();
    if (!_isValidEmail(normalizedEmail)) {
      throw const ApiClientException(message: 'Enter a valid email address.');
    }
    final payload = await ApiClient.post(
      '/password_reset_request.php',
      <String, Object?>{'email': normalizedEmail},
    );
    return PasswordResetRequestResult(
      code: payload['recoveryCode'] as String? ?? '',
      expiresInSeconds: (payload['expiresInSeconds'] as num? ?? 900).toInt(),
    );
  }

  Future<String?> resetPassword({
    required String email,
    required String code,
    required String newPassword,
  }) async {
    if (!NetworkStatus.instance.isOnline) return 'No internet connection.';
    final normalizedEmail = email.trim().toLowerCase();
    if (!_isValidEmail(normalizedEmail)) return 'Enter a valid email address.';
    if (newPassword.length < 8) return 'Password must contain at least 8 characters.';
    try {
      await ApiClient.post(
        '/password_reset_confirm.php',
        <String, Object?>{
          'email': normalizedEmail,
          'code': code.trim(),
          'newPassword': newPassword,
        },
      );
      if (normalizedEmail == _email) await _clearSession();
      notifyListeners();
      return null;
    } on ApiClientException catch (error) {
      return error.message;
    } catch (_) {
      return 'Unable to reach the account server.';
    }
  }

  Future<void> updateCountry(CountryInfo country) async {
    _countryCode = country.code;
    await LocalStorage.writeString(_countryKey, _countryCode);
    if (_loggedIn && _token.isNotEmpty) {
      try {
        await ApiClient.post(
          '/account_update.php',
          <String, Object?>{
            'token': _token,
            'countryCode': _countryCode,
          },
        );
      } catch (_) {
        // The local selection remains and sync retries on the next account action.
      }
    }
    notifyListeners();
  }

  Future<void> logout() async {
    final token = _token;
    if (token.isNotEmpty) {
      try {
        await ApiClient.post(
          '/account_logout.php',
          <String, Object?>{'token': token},
        );
      } catch (_) {
        // Local logout must always complete.
      }
    }
    await _clearSession();
    notifyListeners();
  }

  Future<void> _persistSession({required bool persistToken}) async {
    await Future.wait(<Future<void>>[
      _persistProfile(),
      LocalStorage.writeString(_tokenKey, persistToken ? _token : ''),
      LocalStorage.writeBool(_loggedInKey, persistToken),
      LocalStorage.writeBool(_rememberKey, _rememberMe),
    ]);
  }

  Future<void> _persistProfile() async {
    await Future.wait(<Future<void>>[
      LocalStorage.writeString(_nameKey, _name),
      LocalStorage.writeString(_emailKey, _email),
      LocalStorage.writeString(_countryKey, _countryCode),
    ]);
  }

  Future<void> _clearSession() async {
    _loggedIn = false;
    _token = '';
    await Future.wait(<Future<void>>[
      LocalStorage.writeString(_tokenKey, ''),
      LocalStorage.writeBool(_loggedInKey, false),
    ]);
  }

  void _applyUserPayload(Object? raw) {
    if (raw is! Map<Object?, Object?>) return;
    final user = raw.cast<String, Object?>();
    _name = user['name'] as String? ?? _name;
    _email = user['email'] as String? ?? _email;
    _countryCode = user['countryCode'] as String? ?? _countryCode;
  }

  bool _isValidEmail(String value) {
    final at = value.indexOf('@');
    final dot = value.lastIndexOf('.');
    return at > 0 && dot > at + 1 && dot < value.length - 1;
  }
}
