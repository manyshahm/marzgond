import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../models/game_history.dart';
import '../services/local_storage.dart';

class GameHistoryStore extends ChangeNotifier {
  GameHistoryStore._();

  static final GameHistoryStore instance = GameHistoryStore._();
  static const int maximumEntries = 20;
  static const String _enabledKey = 'history_enabled';
  static const String _historyKey = 'match_history_v1';

  bool _enabled = true;
  bool _initialized = false;
  final List<GameHistoryEntry> _entries = <GameHistoryEntry>[];

  bool get enabled => _enabled;
  bool get initialized => _initialized;
  List<GameHistoryEntry> get entries => List.unmodifiable(_entries);

  Future<void> initialize() async {
    if (_initialized) return;
    try {
      _enabled = await LocalStorage.readBool(_enabledKey) ?? true;
      final raw = await LocalStorage.readString(_historyKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List<Object?>) {
          _entries
            ..clear()
            ..addAll(
              decoded
                  .whereType<Map<Object?, Object?>>()
                  .map(
                    (item) => GameHistoryEntry.fromJson(
                      item.cast<String, Object?>(),
                    ),
                  ),
            );
        }
      }
      if (_entries.length > maximumEntries) {
        _entries.removeRange(maximumEntries, _entries.length);
      }
    } catch (_) {
      _entries.clear();
      _enabled = true;
    }
    _initialized = true;
    notifyListeners();
  }

  Future<void> setEnabled(bool value) async {
    if (_enabled == value) return;
    _enabled = value;
    notifyListeners();
    await LocalStorage.writeBool(_enabledKey, value);
  }

  Future<void> add(GameHistoryEntry entry) async {
    if (!_enabled) return;
    _entries.insert(0, entry);
    if (_entries.length > maximumEntries) {
      _entries.removeRange(maximumEntries, _entries.length);
    }
    notifyListeners();
    await _persist();
  }

  Future<void> delete(String id) async {
    _entries.removeWhere((entry) => entry.id == id);
    notifyListeners();
    await _persist();
  }

  Future<void> clear() async {
    _entries.clear();
    notifyListeners();
    await _persist();
  }

  Future<void> _persist() async {
    final raw = jsonEncode(
      _entries.map((entry) => entry.toJson()).toList(growable: false),
    );
    await LocalStorage.writeString(_historyKey, raw);
  }
}
