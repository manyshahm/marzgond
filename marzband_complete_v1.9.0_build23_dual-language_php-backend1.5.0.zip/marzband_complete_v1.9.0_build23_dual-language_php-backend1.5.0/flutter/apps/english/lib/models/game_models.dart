import 'package:flutter/foundation.dart';

enum Player { blue, red }

enum GameMode { local, bot, ranked }

enum BotDifficulty { easy, normal, hard, extreme }

enum WallOrientation { horizontal, vertical }

@immutable
class Cell {
  const Cell(this.row, this.col);

  final int row;
  final int col;

  Cell translate(int dr, int dc) => Cell(row + dr, col + dc);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Cell && row == other.row && col == other.col;

  @override
  int get hashCode => Object.hash(row, col);

  @override
  String toString() => 'Cell($row,$col)';
}

@immutable
class Wall {
  const Wall({
    required this.row,
    required this.col,
    required this.orientation,
    required this.owner,
  });

  final int row;
  final int col;
  final WallOrientation orientation;
  final Player owner;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Wall &&
          row == other.row &&
          col == other.col &&
          orientation == other.orientation;

  @override
  int get hashCode => Object.hash(row, col, orientation);
}

@immutable
class MoveRecord {
  const MoveRecord.move({
    required this.player,
    required this.from,
    required this.to,
  })  : wall = null,
        isWall = false;

  const MoveRecord.wall({
    required this.player,
    required this.wall,
  })  : from = null,
        to = null,
        isWall = true;

  final Player player;
  final bool isWall;
  final Cell? from;
  final Cell? to;
  final Wall? wall;
}

extension PlayerUi on Player {
  String get label => this == Player.blue ? 'Player One' : 'Player Two';
  Player get opponent => this == Player.blue ? Player.red : Player.blue;
}

extension BotDifficultyUi on BotDifficulty {
  String get label {
    switch (this) {
      case BotDifficulty.easy:
        return 'Easy';
      case BotDifficulty.normal:
        return 'Normal';
      case BotDifficulty.hard:
        return 'Hard';
      case BotDifficulty.extreme:
        return 'Extreme';
    }
  }

  String get description {
    switch (this) {
      case BotDifficulty.easy:
        return 'Logical and beatable with limited search depth.';
      case BotDifficulty.normal:
        return 'Advanced prediction and effective wall analysis.';
      case BotDifficulty.hard:
        return 'Full multi-move engine with controlled variety.';
      case BotDifficulty.extreme:
        return 'Maximum engine strength within the time limit.';
    }
  }
}
