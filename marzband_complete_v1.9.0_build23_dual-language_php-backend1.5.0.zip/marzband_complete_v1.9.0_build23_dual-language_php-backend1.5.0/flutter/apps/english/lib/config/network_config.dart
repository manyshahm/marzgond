class NetworkConfig {
  const NetworkConfig._();

  static const String apiBase = String.fromEnvironment(
    'MARZBAND_API_BASE',
    defaultValue: 'https://persian-melody.ir/marzband/api',
  );

  static const Duration connectionTimeout = Duration(seconds: 8);
  static const Duration matchmakingTimeout = Duration(seconds: 12);
  static const Duration pollInterval = Duration(milliseconds: 250);
  static const Duration presenceInterval = Duration(seconds: 6);
}
