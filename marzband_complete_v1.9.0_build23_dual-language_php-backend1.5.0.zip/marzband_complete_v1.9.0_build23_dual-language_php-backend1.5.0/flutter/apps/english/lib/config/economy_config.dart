abstract final class EconomyConfig {
  static const int rewardedAdCoins = 20;
  static const List<int> wheelPrizes = <int>[10, 20, 30, 40, 50, 75, 100, 150];
}
