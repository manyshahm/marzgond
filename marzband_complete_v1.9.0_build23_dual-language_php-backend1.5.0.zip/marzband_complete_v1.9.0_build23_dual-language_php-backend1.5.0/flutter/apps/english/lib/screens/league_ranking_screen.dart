import 'package:flutter/material.dart';

import '../models/country.dart';
import '../models/league_models.dart';
import '../services/api_client.dart';
import '../services/network_status.dart';
import '../state/auth_state.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/player_avatar.dart';

class LeagueRankingScreen extends StatefulWidget {
  const LeagueRankingScreen({super.key});

  @override
  State<LeagueRankingScreen> createState() => _LeagueRankingScreenState();
}

class _LeagueRankingScreenState extends State<LeagueRankingScreen> {
  final PlayerPreferences _preferences = PlayerPreferences.instance;
  final NetworkStatus _network = NetworkStatus.instance;

  CupTier _selectedTier = CupTier.forCups(PlayerPreferences.instance.cups);
  List<LeaderboardEntry> _entries = const <LeaderboardEntry>[];
  List<LeaderboardEntry> _lastMonth = const <LeaderboardEntry>[];
  String? _lastMonthSeason;
  int? _currentRank;
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _preferences.addListener(_onPreferencesChanged);
    _network.addListener(_onNetworkChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _preferences.removeListener(_onPreferencesChanged);
    _network.removeListener(_onNetworkChanged);
    super.dispose();
  }

  void _onPreferencesChanged() {
    if (!mounted) return;
    setState(() {});
  }

  void _onNetworkChanged() {
    if (!mounted) return;
    setState(() {});
    if (_network.isOnline && _entries.isEmpty) _load();
  }

  Future<void> _load({CupTier? tier}) async {
    if (!_network.isOnline || !AuthState.instance.isLoggedIn || _loading) return;
    final nextTier = tier ?? _selectedTier;
    setState(() {
      _selectedTier = nextTier;
      _loading = true;
      _error = null;
    });
    try {
      final payload = await ApiClient.post(
        '/leaderboard.php',
        <String, Object?>{
          'token': AuthState.instance.authToken,
          'league': nextTier.key,
        },
      );
      final rawEntries = payload['entries'];
      final entries = <LeaderboardEntry>[];
      if (rawEntries is List<Object?>) {
        for (final raw in rawEntries) {
          if (raw is Map<Object?, Object?>) {
            entries.add(LeaderboardEntry.fromMap(raw.cast<String, Object?>()));
          }
        }
      }
      final lastRaw = payload['lastMonth'];
      final previous = <LeaderboardEntry>[];
      String? previousSeason;
      if (lastRaw is Map<Object?, Object?>) {
        final last = lastRaw.cast<String, Object?>();
        previousSeason = last['season'] as String?;
        final list = last['entries'];
        if (list is List<Object?>) {
          for (var index = 0; index < list.length; index++) {
            final raw = list[index];
            if (raw is Map<Object?, Object?>) {
              final map = raw.cast<String, Object?>();
              previous.add(
                LeaderboardEntry(
                  rank: index + 1,
                  name: map['name'] as String? ?? 'Player',
                  cups: (map['cups'] as num? ?? 0).toInt(),
                  isCurrentPlayer: false,
                  countryCode: map['countryCode'] as String? ?? 'IR',
                  avatarKey: map['avatarKey'] as String? ?? 'guest',
                ),
              );
            }
          }
        }
      }
      await _preferences.applyServerSnapshot(payload['currentUser']);
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _currentRank = (payload['currentRank'] as num?)?.toInt();
        _lastMonth = previous;
        _lastMonthSeason = previousSeason;
      });
    } on ApiClientException catch (error) {
      if (mounted) setState(() => _error = error.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Unable to load the ranking.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _showAllLeagues() async {
    await showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.82,
        maxChildSize: 0.94,
        minChildSize: 0.5,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
          children: <Widget>[
            const Text(
              'All Leagues',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 5),
            const Text(
              'Tap a league to view its ranking and reward rules.',
              style: TextStyle(color: AppColors.muted),
            ),
            const SizedBox(height: 16),
            for (final tier in CupTier.all) ...<Widget>[
              _LeagueCard(
                tier: tier,
                current: tier.contains(_preferences.cups),
                selected: tier.key == _selectedTier.key,
                onTap: () {
                  Navigator.of(context).pop();
                  _load(tier: tier);
                },
              ),
              const SizedBox(height: 10),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _showPreviousMonth() async {
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          _lastMonthSeason == null
              ? 'Previous Month Top Players'
              : 'Top Players — $_lastMonthSeason',
        ),
        content: SizedBox(
          width: 420,
          child: _lastMonth.isEmpty
              ? const Padding(
                  padding: EdgeInsets.symmetric(vertical: 26),
                  child: Text(
                    'No archived monthly ranking is available yet.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.muted),
                  ),
                )
              : ListView.separated(
                  shrinkWrap: true,
                  itemCount: _lastMonth.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) => _RankingRow(
                    entry: _lastMonth[index],
                    compact: true,
                  ),
                ),
        ),
        actions: <Widget>[
          FilledButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_network.isOnline) {
      return const SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(Icons.wifi_off_rounded, color: AppColors.muted, size: 56),
              SizedBox(height: 14),
              Text(
                'No internet connection',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
            ],
          ),
        ),
      );
    }

    final currentTier = CupTier.forCups(_preferences.cups);
    final showingCurrent = currentTier.key == _selectedTier.key;
    final progress = currentTier.progressValue(_preferences.cups);
    final currentEntry = showingCurrent
        ? _entries.where((entry) => entry.isCurrentPlayer).firstOrNull
        : null;
    final fallbackCurrent = showingCurrent && currentEntry == null
        ? LeaderboardEntry(
            rank: _currentRank ?? 0,
            name: AuthState.instance.name,
            cups: _preferences.cups,
            isCurrentPlayer: true,
            countryCode: AuthState.instance.countryCode,
            avatarKey: _preferences.avatarChoice.name,
          )
        : currentEntry;
    final displayEntries = <LeaderboardEntry>[..._entries];
    if (showingCurrent &&
        fallbackCurrent != null &&
        !displayEntries.any((entry) => entry.isCurrentPlayer)) {
      displayEntries.add(fallbackCurrent);
    }
    displayEntries.sort((a, b) {
      if (a.rank <= 0 && b.rank <= 0) return b.cups.compareTo(a.cups);
      if (a.rank <= 0) return 1;
      if (b.rank <= 0) return -1;
      return a.rank.compareTo(b.rank);
    });
    final pinCurrent = showingCurrent &&
        fallbackCurrent != null &&
        (fallbackCurrent.rank <= 0 || fallbackCurrent.rank > 7);

    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 88),
        child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF0D172A),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: _selectedTier.color.withValues(alpha: 0.62),
                ),
              ),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Container(
                        width: 72,
                        height: 72,
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: _selectedTier.color.withValues(alpha: 0.14),
                          shape: BoxShape.circle,
                        ),
                        child: Image.asset(_selectedTier.assetPath),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              _selectedTier.name,
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              _selectedTier.rangeLabel,
                              style: TextStyle(
                                color: _selectedTier.color,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Win +${_selectedTier.winCups} cups • Loss -${_selectedTier.lossCups} • Win ${_selectedTier.winCoins} coins',
                              style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 12,
                                height: 1.45,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: _loading ? null : () => _load(),
                        icon: const Icon(Icons.refresh_rounded),
                      ),
                    ],
                  ),
                  if (showingCurrent) ...<Widget>[
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 13,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: _selectedTier.color.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(
                          color: _selectedTier.color.withValues(alpha: 0.34),
                        ),
                      ),
                      child: Row(
                        children: <Widget>[
                          PlayerAvatar(
                            avatar: _preferences.avatarChoice,
                            size: 34,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              AuthState.instance.name.isEmpty
                                  ? 'Player'
                                  : AuthState.instance.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          Text(
                            '#${_currentRank ?? fallbackCurrent?.rank ?? 0}',
                            style: const TextStyle(
                              color: AppColors.muted,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(width: 10),
                          const Icon(
                            Icons.emoji_events_rounded,
                            color: AppColors.gold,
                            size: 17,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${_preferences.cups}',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ],
                      ),
                    ),
                  ],
                  if (showingCurrent && currentTier.maximum != null) ...<Widget>[
                    const SizedBox(height: 13),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(99),
                      child: LinearProgressIndicator(
                        value: progress / 100,
                        minHeight: 9,
                        backgroundColor: Colors.white10,
                        color: currentTier.color,
                      ),
                    ),
                  ],
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _showAllLeagues,
                          icon: const Icon(Icons.grid_view_rounded),
                          label: const Text('All Leagues'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _showPreviousMonth,
                          icon: const Icon(Icons.history_rounded),
                          label: const Text('Previous Month'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
              child: Text(
                _error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.red),
              ),
            ),
          Expanded(
            child: _loading && _entries.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : displayEntries.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 30),
                          child: Text(
                            _error ?? 'No players are ranked in this league yet.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _error == null ? AppColors.muted : AppColors.red,
                              fontWeight: FontWeight.w800,
                              height: 1.5,
                            ),
                          ),
                        ),
                      )
                    : Stack(
                        children: <Widget>[
                          ListView.builder(
                            padding: EdgeInsets.fromLTRB(
                              14,
                              2,
                              14,
                              pinCurrent ? 88 : 18,
                            ),
                            itemCount: displayEntries.length,
                            itemBuilder: (context, index) => _RankingRow(
                              entry: displayEntries[index],
                            ),
                          ),
                          if (pinCurrent)
                            Positioned(
                              left: 14,
                              right: 14,
                              bottom: 8,
                              child: _RankingRow(
                                entry: fallbackCurrent!,
                                floating: true,
                              ),
                            ),
                        ],
                      ),
          ),
        ],
          ),
      ),
    );
  }
}

class _LeagueCard extends StatelessWidget {
  const _LeagueCard({
    required this.tier,
    required this.current,
    required this.selected,
    required this.onTap,
  });

  final CupTier tier;
  final bool current;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0D172A),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: tier.color.withValues(alpha: selected ? 0.9 : 0.42),
              width: selected ? 1.7 : 1,
            ),
          ),
          child: Row(
            children: <Widget>[
              SizedBox(width: 56, height: 56, child: Image.asset(tier.assetPath)),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Text(
                          tier.name,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        if (current) ...<Widget>[
                          const SizedBox(width: 8),
                          Text(
                            'CURRENT',
                            style: TextStyle(
                              color: tier.color,
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(tier.rangeLabel, style: TextStyle(color: tier.color)),
                    const SizedBox(height: 4),
                    Text(
                      '+${tier.winCups} / -${tier.lossCups} cups • ${tier.winCoins} win coins',
                      style: const TextStyle(color: AppColors.muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: tier.color),
            ],
          ),
        ),
      ),
    );
  }
}

class _RankingRow extends StatelessWidget {
  const _RankingRow({
    required this.entry,
    this.floating = false,
    this.compact = false,
  });

  final LeaderboardEntry entry;
  final bool floating;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final tier = CupTier.forCups(entry.cups);
    final avatar = AvatarChoice.values.firstWhere(
      (choice) => choice.name == entry.avatarKey,
      orElse: () => AvatarChoice.guest,
    );
    return Container(
      margin: EdgeInsets.symmetric(vertical: compact ? 2 : 4),
      padding: EdgeInsets.symmetric(
        horizontal: 13,
        vertical: compact ? 7 : 9,
      ),
      decoration: BoxDecoration(
        color: entry.isCurrentPlayer
            ? const Color(0xFF10253B)
            : const Color(0xFF101A2B),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: entry.isCurrentPlayer
              ? tier.color.withValues(alpha: 0.9)
              : const Color(0xFF30405C),
          width: entry.isCurrentPlayer && floating ? 1.7 : 1,
        ),
        boxShadow: floating
            ? const <BoxShadow>[
                BoxShadow(color: Colors.black45, blurRadius: 18, offset: Offset(0, 7)),
              ]
            : null,
      ),
      child: Row(
        children: <Widget>[
          SizedBox(
            width: 38,
            child: Text(
              entry.rank > 0 ? '${entry.rank}' : '—',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: entry.rank > 0 && entry.rank <= 3
                    ? AppColors.gold
                    : AppColors.text,
                fontSize: 17,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 8),
          PlayerAvatar(avatar: avatar, size: compact ? 36 : 42),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              entry.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontWeight: entry.isCurrentPlayer
                    ? FontWeight.w900
                    : FontWeight.w700,
              ),
            ),
          ),
          Text(
            Countries.byCode(entry.countryCode).flag,
            style: const TextStyle(fontSize: 18),
          ),
          const SizedBox(width: 6),
          const Icon(Icons.emoji_events_rounded, color: AppColors.gold, size: 18),
          const SizedBox(width: 4),
          Text('${entry.cups}', style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
