import 'package:flutter/material.dart';

import '../models/game_models.dart';
import '../theme/app_theme.dart';
import '../widgets/neon_background.dart';
import 'game_screen.dart';

class BotDifficultyScreen extends StatelessWidget {
  const BotDifficultyScreen({super.key});

  static const List<BotDifficulty> _visibleLevels = <BotDifficulty>[
    BotDifficulty.easy,
    BotDifficulty.hard,
  ];

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Choose Bot Difficulty'),
          backgroundColor: Colors.transparent,
          leading: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
        ),
        body: NeonBackground(
          child: SafeArea(
            top: false,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
              itemCount: _visibleLevels.length,
              separatorBuilder: (_, __) => const SizedBox(height: 14),
              itemBuilder: (context, index) {
                final difficulty = _visibleLevels[index];
                final hard = difficulty == BotDifficulty.hard;
                final color = hard ? AppColors.red : const Color(0xFF31E879);
                return Card(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => GameScreen(
                            mode: GameMode.bot,
                            botDifficulty: difficulty,
                          ),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 66,
                            height: 66,
                            decoration: BoxDecoration(
                              color: color.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(21),
                              border: Border.all(
                                color: color.withValues(alpha: 0.65),
                              ),
                            ),
                            child: Icon(
                              hard
                                  ? Icons.local_fire_department_rounded
                                  : Icons.sentiment_satisfied_alt_rounded,
                              color: color,
                              size: 36,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  hard ? 'Hard' : 'Easy',
                                  style: TextStyle(
                                    color: color,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 7),
                                Text(
                                  hard
                                      ? 'Multi-move prediction, defense, and advanced wall play'
                                      : 'Logical and beatable, without pointless moves',
                                  style: const TextStyle(
                                    color: AppColors.muted,
                                    height: 1.6,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right_rounded),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
