import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../engine/bot_player.dart';
import '../engine/game_engine.dart';
import '../models/country.dart';
import '../models/game_history.dart';
import '../models/game_models.dart';
import '../models/league_models.dart';
import '../state/auth_state.dart';
import '../state/game_history_store.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/game_board.dart';
import '../widgets/game_background.dart';
import '../widgets/player_avatar.dart';
import 'replay_screen.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({
    required this.mode,
    this.botDifficulty = BotDifficulty.normal,
    this.opponentName,
    this.opponentCups,
    this.opponentCountryCode,
    super.key,
  });

  final GameMode mode;
  final BotDifficulty botDifficulty;
  final String? opponentName;
  final int? opponentCups;
  final String? opponentCountryCode;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  static const int _turnDurationSeconds = 30;

  late final GameEngine _engine;
  final Random _random = Random();
  final PlayerPreferences _preferences = PlayerPreferences.instance;

  Timer? _timer;
  Timer? _reactionTimer;
  var _seconds = _turnDurationSeconds;
  var _botThinking = false;
  var _draggingWall = false;
  var _emojiBadge = 2;
  String? _blueReaction;
  String? _redReaction;
  String? _finishReason;
  bool _rankApplied = false;
  bool _historySaved = false;
  bool _winnerDialogOpen = false;
  bool _allowRoutePop = false;
  late final DateTime _startedAt;
  GameHistoryEntry? _latestHistory;
  int? _cupBefore;
  int? _cupDelta;
  int? _cupAfter;

  @override
  void initState() {
    super.initState();
    _startedAt = DateTime.now();
    _engine = GameEngine(mode: widget.mode);
    if (widget.mode != GameMode.local) {
      _startTimer();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _reactionTimer?.cancel();
    super.dispose();
  }

  Color get _primaryColor => _preferences.playerColor;
  Color get _secondaryColor => _preferences.opponentColor;

  bool get _isHumanTurn =>
      widget.mode == GameMode.local || _engine.turn == Player.blue;

  bool get _canInteract =>
      !_botThinking && !_engine.isFinished && _isHumanTurn;

  String get _playerDisplayName =>
      AuthState.instance.isLoggedIn ? AuthState.instance.name : 'Guest Player';

  String get _playerCountryFlag => AuthState.instance.country.flag;

  String get _opponentCountryFlag =>
      Countries.byCode(widget.opponentCountryCode ?? 'TR').flag;

  String get _opponentDisplayName {
    if (widget.mode == GameMode.ranked) {
      return widget.opponentName ?? 'Opponent';
    }
    if (widget.mode == GameMode.bot) {
      return 'Opponent ${widget.botDifficulty.label}';
    }
    return 'Player Two';
  }

  int get _opponentDisplayCups =>
      widget.opponentCups ?? max(0, _preferences.cups - 20);

  void _startTimer() {
    _timer?.cancel();
    _seconds = _turnDurationSeconds;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _engine.isFinished) return;
      setState(() => _seconds--);
      if (_seconds <= 0) {
        setState(() {
          _engine.expireTurn();
          _seconds = _turnDurationSeconds;
          _draggingWall = false;
        });
        _scheduleBotIfNeeded();
      }
    });
  }

  void _onMove(Cell cell) {
    if (!_canInteract || _draggingWall) return;
    if (!_engine.move(cell)) return;
    setState(() {});
    _afterAction();
  }

  void _onWall(int row, int col, WallOrientation orientation) {
    if (!_canInteract) return;
    final success = _engine.placeWall(
      row: row,
      col: col,
      orientation: orientation,
    );
    if (!success) {
      setState(() => _draggingWall = false);
      return;
    }
    setState(() => _draggingWall = false);
    _afterAction();
  }

  void _afterAction() {
    if (widget.mode != GameMode.local) {
      _seconds = _turnDurationSeconds;
    }
    if (_engine.winner != null) {
      _timer?.cancel();
      WidgetsBinding.instance.addPostFrameCallback((_) => _showWinner());
      return;
    }
    _scheduleBotIfNeeded();
  }

  Future<void> _scheduleBotIfNeeded() async {
    if (widget.mode == GameMode.local ||
        _engine.turn != Player.red ||
        _engine.isFinished ||
        _botThinking) {
      return;
    }

    setState(() => _botThinking = true);
    final targetDelay = switch (widget.botDifficulty) {
      BotDifficulty.easy => Duration.zero,
      BotDifficulty.normal => Duration.zero,
      BotDifficulty.hard => Duration.zero,
      BotDifficulty.extreme =>
        Duration(milliseconds: 1000 + _random.nextInt(501)),
    };
    final computeTimeout = switch (widget.botDifficulty) {
      BotDifficulty.easy => const Duration(milliseconds: 850),
      BotDifficulty.normal => const Duration(milliseconds: 1050),
      BotDifficulty.hard => const Duration(milliseconds: 1300),
      BotDifficulty.extreme => const Duration(milliseconds: 1480),
    };
    final started = DateTime.now();

    BotAction action;
    try {
      final result = await compute<Map<String, Object?>, Map<String, Object?>>(
        computeBotAction,
        <String, Object?>{
          'engine': _engine.toSnapshot(),
          'difficulty': widget.botDifficulty.index,
        },
      ).timeout(computeTimeout);
      action = BotAction.fromMap(result);
    } catch (_) {
      action = BotPlayer.safeFallback(_engine.clone());
    }

    final elapsed = DateTime.now().difference(started);
    if (elapsed < targetDelay) {
      await Future<void>.delayed(targetDelay - elapsed);
    }
    if (!mounted) return;
    if (_engine.isFinished || _engine.turn != Player.red) {
      setState(() => _botThinking = false);
      return;
    }

    var applied = false;
    if (action.isMove) {
      applied = _engine.move(action.cell!);
    } else if (action.isWall) {
      applied = _engine.placeWall(
        row: action.row!,
        col: action.col!,
        orientation: action.orientation!,
      );
    }
    if (!applied && !_engine.isFinished && _engine.turn == Player.red) {
      final fallback = BotPlayer.safeFallback(_engine.clone());
      if (fallback.isMove) {
        _engine.move(fallback.cell!);
      } else if (fallback.isWall) {
        _engine.placeWall(
          row: fallback.row!,
          col: fallback.col!,
          orientation: fallback.orientation!,
        );
      }
    }
    if (!mounted) return;
    setState(() {
      _botThinking = false;
      _seconds = _turnDurationSeconds;
    });
    if (_engine.winner != null) {
      _timer?.cancel();
      await _showWinner();
    }
  }

  String _formatTime(int seconds) {
    final safe = seconds.clamp(0, 5999);
    final minutes = safe ~/ 60;
    final remainder = safe % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainder.toString().padLeft(2, '0')}';
  }

  void _applyRankResultIfNeeded() {
    if (widget.mode != GameMode.ranked || _rankApplied || _engine.winner == null) {
      return;
    }
    _rankApplied = true;
    final before = _preferences.cups;
    final won = _engine.winner == Player.blue;
    final tier = CupTier.forCups(before);
    final delta = won ? tier.winCups : -tier.lossCups;

    _preferences.addCups(delta);
    _cupBefore = before;
    _cupDelta = delta;
    _cupAfter = _preferences.cups;
  }

  Future<GameHistoryEntry> _recordHistory() async {
    if (_historySaved && _latestHistory != null) return _latestHistory!;
    final winner = _engine.winner ?? Player.red;
    final entry = GameHistoryEntry(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      playedAt: DateTime.now(),
      mode: widget.mode,
      opponentName: _opponentDisplayName,
      opponentCups: widget.mode == GameMode.ranked ? _opponentDisplayCups : null,
      winner: winner,
      finishReason: _finishReason ??
          'Match ended in ${_engine.history.length} moves.',
      durationSeconds: DateTime.now().difference(_startedAt).inSeconds,
      cupBefore: _cupBefore,
      cupDelta: _cupDelta,
      cupAfter: _cupAfter,
      botDifficulty: widget.mode == GameMode.bot ? widget.botDifficulty : null,
      moves: List<MoveRecord>.unmodifiable(_engine.history),
    );
    _historySaved = true;
    _latestHistory = entry;
    await GameHistoryStore.instance.add(entry);
    return entry;
  }

  Future<void> _showWinner() async {
    if (!mounted || _engine.winner == null || _winnerDialogOpen) return;
    _winnerDialogOpen = true;
    _applyRankResultIfNeeded();
    final entry = await _recordHistory();
    if (!mounted) return;

    final winner = _engine.winner!;
    final winnerName = winner == Player.blue ? _playerDisplayName : _opponentDisplayName;
    final result = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 28),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  color: AppColors.gold.withValues(alpha: 0.14),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.card_giftcard_rounded,
                  color: AppColors.gold,
                  size: 34,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '$winnerName wins!',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 5),
              Text(
                entry.finishReason,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.muted, height: 1.6),
              ),
              if (_cupDelta != null) ...<Widget>[
                const SizedBox(height: 10),
                Text(
                  'Cups: $_cupBefore ${_cupDelta! >= 0 ? '+' : ''}$_cupDelta ← $_cupAfter',
                  style: TextStyle(
                    color: _cupDelta! >= 0 ? AppColors.gold : AppColors.red,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
              const SizedBox(height: 14),
              SizedBox(
                height: 220,
                child: GameBoard(
                  engine: _engine,
                  interactive: false,
                  onMove: (_) {},
                  onWall: (_, __, ___) {},
                  primaryColor: _primaryColor,
                  secondaryColor: _secondaryColor,
                  primaryWallColor: _preferences.playerWallColor,
                  secondaryWallColor: _preferences.opponentWallColor,
                  primaryWallGradient: _preferences.playerWallGradient,
                  secondaryWallGradient: _preferences.opponentWallGradient,
                  activeColor: _primaryColor,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => Navigator.of(context).pop('replay'),
                  icon: const Icon(Icons.play_circle_outline_rounded),
                  label: const Text('Replay Match'),
                ),
              ),
              const SizedBox(height: 9),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.of(context).pop('menu'),
                  icon: const Icon(Icons.home_rounded),
                  label: const Text(
                    'Menu',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    _winnerDialogOpen = false;
    if (!mounted) return;
    if (result == 'replay') {
      await Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => ReplayScreen(entry: entry)),
      );
      if (mounted) await _showWinner();
    } else if (result == 'again') {
      if (widget.mode == GameMode.ranked) {
        _popToPrevious();
      } else {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute<void>(
            builder: (_) => GameScreen(
              mode: widget.mode,
              botDifficulty: widget.botDifficulty,
              opponentName: widget.opponentName,
              opponentCups: widget.opponentCups,
              opponentCountryCode: widget.opponentCountryCode,
            ),
          ),
        );
      }
    } else if (result == 'menu') {
      _popToPrevious();
    }
  }

  Future<void> _showHelp() async {
    await showDialog<void>(
      context: context,
      builder: (context) => const AlertDialog(
        title: Text('How to Play'),
        content: Text(
          'Reach the opposite edge before your opponent. On each turn, move your pawn or drag a horizontal or vertical wall onto the board. Green placement is valid; red placement is blocked.',
          style: TextStyle(height: 1.8),
        ),
      ),
    );
  }

  Future<void> _showChat() async {
    if (!_canInteract || _draggingWall) return;
    const messages = <String>[
      'Good luck!',
      'Nice move!',
      'I need to think…',
      'Your turn.',
      'Have fun!',
    ];
    final selected = await showModalBottomSheet<String>(
      context: context,
      useSafeArea: true,
      backgroundColor: AppColors.surface,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text(
              'Quick Chat',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            for (final message in messages)
              ListTile(
                title: Text(message),
                leading: const Icon(Icons.chat_bubble_outline_rounded),
                onTap: () => Navigator.of(context).pop(message),
              ),
          ],
        ),
      ),
    );
    if (selected != null && mounted) _showReaction(selected);
  }

  Future<void> _showEmoji() async {
    if (!_canInteract || _draggingWall) return;
    setState(() => _emojiBadge = 0);
    const emojis = <String>['🔥', '👏', '😄', '😎', '🤔', '⚡', '🏆', '💪'];
    final selected = await showModalBottomSheet<String>(
      context: context,
      useSafeArea: true,
      backgroundColor: AppColors.surface,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text(
              'Emoji',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 16),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 12,
              runSpacing: 12,
              children: emojis.map((emoji) {
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => Navigator.of(context).pop(emoji),
                  child: Container(
                    width: 62,
                    height: 62,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppColors.surfaceAlt,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(emoji, style: const TextStyle(fontSize: 31)),
                  ),
                );
              }).toList(growable: false),
            ),
          ],
        ),
      ),
    );
    if (selected != null && mounted) _showReaction(selected);
  }

  void _showReaction(String reaction) {
    _reactionTimer?.cancel();
    setState(() {
      if (_engine.turn == Player.blue) {
        _blueReaction = reaction;
      } else {
        _redReaction = reaction;
      }
    });
    _reactionTimer = Timer(const Duration(seconds: 3), () {
      if (!mounted) return;
      setState(() {
        _blueReaction = null;
        _redReaction = null;
      });
    });
  }

  Future<void> _resign() async {
    if (!_canInteract || _draggingWall) return;
    final losingPlayer = _engine.turn;
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Resign Match?'),
            content: Text(
              widget.mode == GameMode.local
                  ? '${losingPlayer.label} will lose the match.'
                  : 'Confirming ends the match in your opponent’s favor.',
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Keep Playing'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Resign'),
              ),
            ],
          ),
        ) ??
        false;
    if (!confirmed || !mounted) return;

    _engine.resign(losingPlayer);
    _finishReason = '${losingPlayer.label} resigned.';
    _timer?.cancel();
    setState(() {});
    await _showWinner();
  }



  Future<bool> _confirmLeave() async {
    if (_engine.isFinished) return true;
    if (_draggingWall) return false;

    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Leave Match?'),
            content: Text(
              widget.mode == GameMode.ranked
                  ? 'Leaving a ranked match counts as a loss and removes cups.'
                  : 'The current match will be abandoned.',
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Keep Playing'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Leave'),
              ),
            ],
          ),
        ) ??
        false;

    if (confirmed && widget.mode == GameMode.ranked) {
      _engine.resign(Player.blue);
      _finishReason = 'The player left the match.';
      _applyRankResultIfNeeded();
        await _recordHistory();
    }
    return confirmed;
  }

  void _popToPrevious() {
    if (!mounted || _allowRoutePop) return;
    setState(() => _allowRoutePop = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) Navigator.of(context).pop();
    });
  }

  Future<void> _handleBackToPrevious() async {
    final confirmed = await _confirmLeave();
    if (confirmed && mounted) _popToPrevious();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _allowRoutePop,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _handleBackToPrevious();
      },
      child: Scaffold(
        body: GameBackground(
          child: SafeArea(
            child: widget.mode == GameMode.local
                ? _buildLocalLayout()
                : _buildStandardLayout(),
          ),
        ),
      ),
    );
  }

  Widget _buildStandardLayout() {
    final blueTurn = _engine.turn == Player.blue;
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxHeight < 760;
        final topHeight = compact ? 148.0 : 172.0;
        final bottomHeight = compact ? 176.0 : 198.0;
        final gap = compact ? 6.0 : 9.0;

        return Padding(
          padding: EdgeInsets.fromLTRB(
            compact ? 8 : 12,
            compact ? 7 : 10,
            compact ? 8 : 12,
            compact ? 8 : 12,
          ),
          child: Column(
            children: <Widget>[
              SizedBox(
                height: topHeight,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Expanded(
                      flex: 4,
                      child: _PlayerPanel(
                        name: _playerDisplayName,
                        trophy: widget.mode == GameMode.ranked
                            ? _preferences.cups
                            : null,
                        league: widget.mode == GameMode.ranked
                            ? CupTier.forCups(_preferences.cups).name
                            : 'Practice',
                        walls: _engine.blueWalls,
                        active: blueTurn,
                        color: _primaryColor,
                        avatar: _preferences.avatarChoice,
                        reaction: _blueReaction,
                        compact: compact,
                        countryFlag: widget.mode == GameMode.ranked
                            ? _playerCountryFlag
                            : null,
                      ),
                    ),
                    SizedBox(width: gap),
                    Expanded(
                      flex: 3,
                      child: _MatchCenter(
                        seconds: _seconds,
                        status: _botThinking
                            ? 'Opponent is thinking'
                            : 'Time Remaining',
                        compact: compact,
                        formatTime: _formatTime,
                      ),
                    ),
                    SizedBox(width: gap),
                    Expanded(
                      flex: 4,
                      child: _PlayerPanel(
                        name: _opponentDisplayName,
                        trophy: widget.mode == GameMode.ranked
                            ? _opponentDisplayCups
                            : null,
                        league: widget.mode == GameMode.ranked
                            ? CupTier.forCups(_opponentDisplayCups).name
                            : widget.mode == GameMode.bot
                                ? 'Bot Match'
                                : 'Practice',
                        walls: _engine.redWalls,
                        active: !blueTurn,
                        color: _secondaryColor,
                        avatarIcon: widget.mode == GameMode.bot
                            ? Icons.smart_toy_rounded
                            : Icons.person_rounded,
                        reaction: _redReaction,
                        compact: compact,
                        countryFlag: widget.mode == GameMode.ranked
                            ? _opponentCountryFlag
                            : null,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: gap),
              Expanded(
                child: GameBoard(
                  engine: _engine,
                  interactive: _canInteract,
                  onMove: _onMove,
                  onWall: _onWall,
                  primaryColor: _primaryColor,
                  secondaryColor: _secondaryColor,
                  primaryWallColor: _preferences.playerWallColor,
                  secondaryWallColor: _preferences.opponentWallColor,
                  primaryWallGradient: _preferences.playerWallGradient,
                  secondaryWallGradient: _preferences.opponentWallGradient,
                  activeColor: _primaryColor,
                  previewVerticalOffsetCells: -1.15,
                ),
              ),
              SizedBox(height: gap),
              SizedBox(
                height: bottomHeight,
                child: _StandardBottomControls(
                  compact: compact,
                  playerColor: _primaryColor,
                  walls: _engine.blueWalls,
                  enabled: _canInteract,
                  draggingWall: _draggingWall,
                  emojiBadge: _emojiBadge,
                  onHelp: _showHelp,
                  onChat: _showChat,
                  onEmoji: _showEmoji,
                  onResign: _resign,
                  onWallDragStarted: _wallDragStarted,
                  onWallDragEnded: _wallDragEnded,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLocalLayout() {
    final redTurn = _engine.turn == Player.red;
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxHeight < 760;
        final trayHeight = compact ? 84.0 : 101.0;
        final gap = compact ? 5.0 : 8.0;

        return Padding(
          padding: EdgeInsets.fromLTRB(
            compact ? 8 : 12,
            compact ? 6 : 9,
            compact ? 8 : 12,
            compact ? 7 : 10,
          ),
          child: Column(
            children: <Widget>[
              SizedBox(
                height: trayHeight,
                child: RotatedBox(
                  quarterTurns: 2,
                  child: _LocalPlayerTray(
                    label: 'Player Two',
                    color: _secondaryColor,
                    walls: _engine.redWalls,
                    active: redTurn,
                    compact: compact,
                    enabled: redTurn && !_draggingWall && !_engine.isFinished,
                    feedbackYOffset: 64,
                    onWallDragStarted: _wallDragStarted,
                    onWallDragEnded: _wallDragEnded,
                  ),
                ),
              ),
              SizedBox(height: gap),
              Expanded(
                child: GameBoard(
                  engine: _engine,
                  interactive: _canInteract,
                  onMove: _onMove,
                  onWall: _onWall,
                  primaryColor: _primaryColor,
                  secondaryColor: _secondaryColor,
                  primaryWallColor: _preferences.playerWallColor,
                  secondaryWallColor: _preferences.opponentWallColor,
                  primaryWallGradient: _preferences.playerWallGradient,
                  secondaryWallGradient: _preferences.opponentWallGradient,
                  activeColor: redTurn ? _secondaryColor : _primaryColor,
                  previewVerticalOffsetCells: redTurn ? 1.15 : -1.15,
                ),
              ),
              SizedBox(height: gap),
              SizedBox(
                height: trayHeight,
                child: _LocalPlayerTray(
                  label: 'Player One',
                  color: _primaryColor,
                  walls: _engine.blueWalls,
                  active: !redTurn,
                  compact: compact,
                  enabled: !redTurn && !_draggingWall && !_engine.isFinished,
                  feedbackYOffset: -64,
                  onWallDragStarted: _wallDragStarted,
                  onWallDragEnded: _wallDragEnded,
                ),
              ),
              SizedBox(height: gap),
              SizedBox(
                height: compact ? 40 : 46,
                width: min<double>(constraints.maxWidth * 0.55, 280.0),
                child: OutlinedButton.icon(
                  onPressed: _canInteract && !_draggingWall ? _resign : null,
                  icon: const Icon(Icons.flag_rounded, size: 19),
                  label: const Text(
                    'Resign',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.gold,
                    side: BorderSide(
                      color: AppColors.gold.withValues(alpha: 0.65),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _wallDragStarted() {
    if (!_canInteract) return;
    setState(() => _draggingWall = true);
  }

  void _wallDragEnded() {
    if (!mounted) return;
    setState(() => _draggingWall = false);
  }
}

class _MatchCenter extends StatelessWidget {
  const _MatchCenter({
    required this.seconds,
    required this.status,
    required this.compact,
    required this.formatTime,
  });

  final int seconds;
  final String status;
  final bool compact;
  final String Function(int) formatTime;


  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Icon(
          Icons.account_tree_rounded,
          color: AppColors.cyan,
          size: compact ? 28 : 34,
        ),
        SizedBox(height: compact ? 3 : 6),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            'WALLFRONT',
            maxLines: 1,
            style: TextStyle(
              fontSize: compact ? 17 : 21,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        SizedBox(height: compact ? 5 : 8),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            formatTime(seconds),
            textDirection: TextDirection.ltr,
            style: TextStyle(
              fontSize: compact ? 28 : 36,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.2,
            ),
          ),
        ),
        Text(
          status,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: AppColors.muted,
            fontSize: compact ? 9 : 11,
          ),
        ),
      ],
    );
  }
}

class _PlayerPanel extends StatelessWidget {
  const _PlayerPanel({
    required this.name,
    required this.trophy,
    required this.league,
    required this.walls,
    required this.active,
    required this.color,
    this.avatar,
    this.avatarIcon,
    required this.reaction,
    required this.compact,
    this.countryFlag,
  });

  final String name;
  final int? trophy;
  final String league;
  final int walls;
  final bool active;
  final Color color;
  final AvatarChoice? avatar;
  final IconData? avatarIcon;
  final String? reaction;
  final bool compact;
  final String? countryFlag;

  @override
  Widget build(BuildContext context) {
    final avatarSize = compact ? 43.0 : 52.0;
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 240),
      opacity: active ? 1 : 0.52,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 240),
        padding: EdgeInsets.fromLTRB(
          compact ? 8 : 10,
          compact ? 7 : 9,
          compact ? 8 : 10,
          compact ? 7 : 9,
        ),
        decoration: BoxDecoration(
          color: active
              ? color.withValues(alpha: 0.14)
              : AppColors.surface.withValues(alpha: 0.9),
          borderRadius: BorderRadius.circular(compact ? 18 : 24),
          border: Border.all(
            color: active ? color : const Color(0xFF263650),
            width: active ? 1.8 : 1,
          ),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Center(
                  child: avatar != null
                      ? PlayerAvatar(
                          avatar: avatar!,
                          size: avatarSize,
                          selected: active,
                        )
                      : CircleAvatar(
                          radius: avatarSize / 2,
                          backgroundColor: color.withValues(alpha: 0.16),
                          child: Icon(
                            avatarIcon ?? Icons.person_rounded,
                            color: color,
                            size: compact ? 24 : 29,
                          ),
                        ),
                ),
                SizedBox(height: compact ? 3 : 5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    if (countryFlag != null) ...<Widget>[
                      Text(
                        countryFlag!,
                        style: TextStyle(fontSize: compact ? 12 : 15),
                      ),
                      const SizedBox(width: 4),
                    ],
                    Flexible(
                      child: Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.w900,
                          fontSize: compact ? 12 : 15,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: compact ? 2 : 3),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        league,
                        style: TextStyle(
                          color: AppColors.muted,
                          fontSize: compact ? 9 : 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      if (trophy != null) ...<Widget>[
                        const SizedBox(width: 5),
                        const Icon(
                          Icons.emoji_events_outlined,
                          color: AppColors.gold,
                          size: 14,
                        ),
                        const SizedBox(width: 2),
                        Text(
                          '$trophy',
                          style: TextStyle(
                            color: AppColors.muted,
                            fontSize: compact ? 9 : 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                SizedBox(height: compact ? 4 : 6),
                _WallCountInline(
                  walls: walls,
                  color: color,
                  compact: compact,
                ),
              ],
            ),
            if (reaction != null)
              Positioned(
                left: 0,
                right: 0,
                bottom: -10,
                child: Center(
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 150),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xEE101827),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: color),
                    ),
                    child: Text(
                      reaction!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _WallCountInline extends StatelessWidget {
  const _WallCountInline({
    required this.walls,
    required this.color,
    required this.compact,
  });

  final int walls;
  final Color color;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 6 : 8,
        vertical: compact ? 4 : 6,
      ),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.25),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Walls',
            style: TextStyle(
              color: AppColors.muted,
              fontSize: compact ? 8 : 10,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(width: 5),
          Container(
            width: compact ? 5 : 6,
            height: compact ? 18 : 22,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(99),
            ),
          ),
          const SizedBox(width: 5),
          Text(
            '$walls',
            style: TextStyle(
              fontWeight: FontWeight.w900,
              color: color,
              fontSize: compact ? 14 : 18,
            ),
          ),
        ],
      ),
    );
  }
}

class _StandardBottomControls extends StatelessWidget {
  const _StandardBottomControls({
    required this.compact,
    required this.playerColor,
    required this.walls,
    required this.enabled,
    required this.draggingWall,
    required this.emojiBadge,
    required this.onHelp,
    required this.onChat,
    required this.onEmoji,
    required this.onResign,
    required this.onWallDragStarted,
    required this.onWallDragEnded,
  });

  final bool compact;
  final Color playerColor;
  final int walls;
  final bool enabled;
  final bool draggingWall;
  final int emojiBadge;
  final VoidCallback onHelp;
  final VoidCallback onChat;
  final VoidCallback onEmoji;
  final VoidCallback onResign;
  final VoidCallback onWallDragStarted;
  final VoidCallback onWallDragEnded;


  @override
  Widget build(BuildContext context) {
    final gap = compact ? 6.0 : 9.0;
    return Column(
      children: <Widget>[
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                child: _ControlButton(
                  label: 'Help',
                  icon: Icons.help_outline_rounded,
                  color: AppColors.muted,
                  enabled: !draggingWall,
                  onPressed: onHelp,
                  compact: compact,
                ),
              ),
              SizedBox(width: gap),
              Expanded(
                child: _WallDragControl(
                  label: 'Horizontal',
                  orientation: WallOrientation.horizontal,
                  color: playerColor,
                  enabled: enabled && walls > 0,
                  compact: compact,
                  feedbackYOffset: -64,
                  onDragStarted: onWallDragStarted,
                  onDragEnded: onWallDragEnded,
                ),
              ),
              SizedBox(width: gap),
              Expanded(
                child: _WallDragControl(
                  label: 'Vertical',
                  orientation: WallOrientation.vertical,
                  color: playerColor,
                  enabled: enabled && walls > 0,
                  compact: compact,
                  feedbackYOffset: -64,
                  onDragStarted: onWallDragStarted,
                  onDragEnded: onWallDragEnded,
                ),
              ),
              SizedBox(width: gap),
              Expanded(
                child: _ControlButton(
                  label: 'Resign',
                  icon: Icons.flag_rounded,
                  color: AppColors.gold,
                  enabled: enabled && !draggingWall,
                  onPressed: onResign,
                  compact: compact,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: gap),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                flex: 2,
                child: _ControlButton(
                  label: 'Chat',
                  icon: Icons.chat_bubble_outline_rounded,
                  color: AppColors.gold,
                  enabled: enabled && !draggingWall,
                  onPressed: onChat,
                  compact: compact,
                ),
              ),
              SizedBox(width: gap),
              Expanded(
                flex: 5,
                child: _WallStockCard(
                  walls: walls,
                  color: playerColor,
                  compact: compact,
                ),
              ),
              SizedBox(width: gap),
              Expanded(
                flex: 2,
                child: _ControlButton(
                  label: 'Emoji',
                  icon: Icons.emoji_emotions_outlined,
                  color: AppColors.gold,
                  enabled: enabled && !draggingWall,
                  badge: emojiBadge,
                  onPressed: onEmoji,
                  compact: compact,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _LocalPlayerTray extends StatelessWidget {
  const _LocalPlayerTray({
    required this.label,
    required this.color,
    required this.walls,
    required this.active,
    required this.compact,
    required this.enabled,
    required this.feedbackYOffset,
    required this.onWallDragStarted,
    required this.onWallDragEnded,
  });

  final String label;
  final Color color;
  final int walls;
  final bool active;
  final bool compact;
  final bool enabled;
  final double feedbackYOffset;
  final VoidCallback onWallDragStarted;
  final VoidCallback onWallDragEnded;


  @override
  Widget build(BuildContext context) {
    final gap = compact ? 6.0 : 9.0;
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 220),
      opacity: active ? 1 : 0.42,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: EdgeInsets.all(compact ? 6 : 8),
        decoration: BoxDecoration(
          color: active
              ? color.withValues(alpha: 0.1)
              : AppColors.surface.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(compact ? 18 : 22),
          border: Border.all(
            color: active ? color : const Color(0xFF263650),
            width: active ? 1.7 : 1,
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Expanded(
              flex: 3,
              child: _LocalWallCount(
                label: label,
                walls: walls,
                color: color,
                compact: compact,
              ),
            ),
            SizedBox(width: gap),
            Expanded(
              flex: 3,
              child: _WallDragControl(
                label: 'Horizontal',
                orientation: WallOrientation.horizontal,
                color: color,
                enabled: enabled && walls > 0,
                compact: compact,
                feedbackYOffset: feedbackYOffset,
                onDragStarted: onWallDragStarted,
                onDragEnded: onWallDragEnded,
              ),
            ),
            SizedBox(width: gap),
            Expanded(
              flex: 3,
              child: _WallDragControl(
                label: 'Vertical',
                orientation: WallOrientation.vertical,
                color: color,
                enabled: enabled && walls > 0,
                compact: compact,
                feedbackYOffset: feedbackYOffset,
                onDragStarted: onWallDragStarted,
                onDragEnded: onWallDragEnded,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LocalWallCount extends StatelessWidget {
  const _LocalWallCount({
    required this.label,
    required this.walls,
    required this.color,
    required this.compact,
  });

  final String label;
  final int walls;
  final Color color;
  final bool compact;


  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.18),
        borderRadius: BorderRadius.circular(compact ? 14 : 17),
        border: Border.all(color: color.withValues(alpha: 0.32)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            label,
            maxLines: 1,
            style: TextStyle(
              color: color,
              fontSize: compact ? 10 : 12,
              fontWeight: FontWeight.w900,
            ),
          ),
          SizedBox(height: compact ? 2 : 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                '$walls',
                style: TextStyle(
                  color: color,
                  fontSize: compact ? 21 : 26,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(width: 6),
              _WallShape(
                orientation: WallOrientation.vertical,
                color: color,
                length: compact ? 30 : 36,
                thickness: compact ? 5 : 6,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ControlButton extends StatelessWidget {
  const _ControlButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.enabled,
    required this.onPressed,
    required this.compact,
    this.badge = 0,
  });

  final String label;
  final IconData icon;
  final Color color;
  final bool enabled;
  final VoidCallback onPressed;
  final bool compact;
  final int badge;


  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.42,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: enabled ? onPressed : null,
          borderRadius: BorderRadius.circular(compact ? 16 : 20),
          child: Stack(
            clipBehavior: Clip.none,
            children: <Widget>[
              Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.surface.withValues(alpha: 0.88),
                  borderRadius: BorderRadius.circular(compact ? 16 : 20),
                  border: Border.all(color: color.withValues(alpha: 0.5)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(icon, color: color, size: compact ? 22 : 27),
                    SizedBox(height: compact ? 2 : 4),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        label,
                        maxLines: 1,
                        style: TextStyle(
                          fontSize: compact ? 10 : 12,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              if (badge > 0)
                Positioned(
                  top: -4,
                  left: -3,
                  child: Container(
                    width: compact ? 21 : 24,
                    height: compact ? 21 : 24,
                    alignment: Alignment.center,
                    decoration: const BoxDecoration(
                      color: AppColors.blue,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '$badge',
                      style: TextStyle(
                        fontSize: compact ? 9 : 11,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WallDragControl extends StatelessWidget {
  const _WallDragControl({
    required this.label,
    required this.orientation,
    required this.color,
    required this.enabled,
    required this.compact,
    required this.feedbackYOffset,
    required this.onDragStarted,
    required this.onDragEnded,
  });

  final String label;
  final WallOrientation orientation;
  final Color color;
  final bool enabled;
  final bool compact;
  final double feedbackYOffset;
  final VoidCallback onDragStarted;
  final VoidCallback onDragEnded;


  @override
  Widget build(BuildContext context) {
    final child = Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: AppColors.surface.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(compact ? 16 : 20),
        border: Border.all(color: color.withValues(alpha: 0.55)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(
              fontSize: compact ? 10 : 12,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: compact ? 4 : 7),
          _WallShape(
            orientation: orientation,
            color: color,
            length: compact ? 42 : 52,
            thickness: compact ? 7 : 9,
          ),
        ],
      ),
    );

    return Opacity(
      opacity: enabled ? 1 : 0.4,
      child: Draggable<WallOrientation>(
        data: orientation,
        maxSimultaneousDrags: enabled ? 1 : 0,
        dragAnchorStrategy: pointerDragAnchorStrategy,
        onDragStarted: onDragStarted,
        onDragEnd: (_) => onDragEnded(),
        feedback: Transform.translate(
          offset: Offset(0, feedbackYOffset),
          child: Material(
            type: MaterialType.transparency,
            child: Opacity(
              opacity: 0.62,
              child: _FloatingWall(orientation: orientation, color: color),
            ),
          ),
        ),
        childWhenDragging: Opacity(opacity: 0.3, child: child),
        child: child,
      ),
    );
  }
}

class _FloatingWall extends StatelessWidget {
  const _FloatingWall({required this.orientation, required this.color});

  final WallOrientation orientation;
  final Color color;


  @override
  Widget build(BuildContext context) {
    return Container(
      width: orientation == WallOrientation.horizontal ? 78 : 15,
      height: orientation == WallOrientation.horizontal ? 15 : 78,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: Colors.white.withValues(alpha: 0.7)),
      ),
    );
  }
}

class _WallShape extends StatelessWidget {
  const _WallShape({
    required this.orientation,
    required this.color,
    required this.length,
    required this.thickness,
  });

  final WallOrientation orientation;
  final Color color;
  final double length;
  final double thickness;


  @override
  Widget build(BuildContext context) {
    return Container(
      width: orientation == WallOrientation.horizontal ? length : thickness,
      height: orientation == WallOrientation.horizontal ? thickness : length,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(99),
      ),
    );
  }
}

class _WallStockCard extends StatelessWidget {
  const _WallStockCard({
    required this.walls,
    required this.color,
    required this.compact,
  });

  final int walls;
  final Color color;
  final bool compact;


  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 12),
      decoration: BoxDecoration(
        color: AppColors.surface.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(compact ? 16 : 20),
        border: Border.all(color: color.withValues(alpha: 0.55)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            '$walls',
            style: TextStyle(
              color: color,
              fontSize: compact ? 24 : 31,
              fontWeight: FontWeight.w900,
            ),
          ),
          SizedBox(width: compact ? 8 : 12),
          Flexible(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Your Walls',
                  maxLines: 1,
                  style: TextStyle(
                    color: color,
                    fontSize: compact ? 10 : 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: compact ? 4 : 6),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    children: List<Widget>.generate(
                      min(walls, 10),
                      (_) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Container(
                          width: compact ? 5 : 6,
                          height: compact ? 25 : 31,
                          decoration: BoxDecoration(
                            color: color,
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
