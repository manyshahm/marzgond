import 'dart:async';

import 'package:flutter/material.dart';

import '../../models/country.dart';
import '../../network/online_game_service.dart';
import '../../state/auth_state.dart';
import '../../theme/app_theme.dart';
import 'country_picker_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();
  CountryInfo? _country;
  bool _obscure = true;
  bool _submitting = false;
  bool _allowPop = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  Future<void> _selectCountry() async {
    final selected = await Navigator.of(context).push<CountryInfo>(
      MaterialPageRoute<CountryInfo>(builder: (_) => const CountryPickerScreen()),
    );
    if (selected != null && mounted) setState(() => _country = selected);
  }

  Future<void> _submit() async {
    if (_submitting || !(_formKey.currentState?.validate() ?? false)) return;
    final country = _country;
    if (country == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select a country.')),
      );
      return;
    }
    if (_passwordController.text != _confirmController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Passwords do not match.')),
      );
      return;
    }
    setState(() => _submitting = true);
    final error = await AuthState.instance.register(
      name: _nameController.text,
      email: _emailController.text,
      password: _passwordController.text,
      country: country,
    );
    if (!mounted) return;
    setState(() => _submitting = false);
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
      return;
    }
    unawaited(OnlineGameService.instance.initializePresence());
    setState(() => _allowPop = true);
    await WidgetsBinding.instance.endOfFrame;
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _allowPop,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Create Account'),
          leading: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 30),
            children: <Widget>[
              const Icon(Icons.person_add_alt_1_rounded, size: 72, color: AppColors.cyan),
              const SizedBox(height: 14),
              const Text(
                'Create Your Wallfront Account',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 24),
              Form(
                key: _formKey,
                child: Column(
                  children: <Widget>[
                    TextFormField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                        labelText: 'Player Name',
                        prefixIcon: Icon(Icons.badge_outlined),
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        final name = (value ?? '').trim();
                        if (name.length < 2) return 'Enter a valid player name.';
                        if (!RegExp(r'^[A-Za-z0-9 ]+$').hasMatch(name)) {
                          return 'Use English letters, numbers, and spaces only.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email_outlined),
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) => (value ?? '').contains('@')
                          ? null
                          : 'Enter a valid email address.',
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: _obscure,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.password_rounded),
                        border: const OutlineInputBorder(),
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => _obscure = !_obscure),
                          icon: Icon(
                            _obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded,
                          ),
                        ),
                      ),
                      validator: (value) => (value ?? '').length >= 8
                          ? null
                          : 'Use at least 8 characters.',
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _confirmController,
                      obscureText: _obscure,
                      decoration: const InputDecoration(
                        labelText: 'Confirm Password',
                        prefixIcon: Icon(Icons.password_outlined),
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) => (value ?? '').isEmpty
                          ? 'Confirm your password.'
                          : null,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              InkWell(
                onTap: _selectCountry,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF42506A)),
                  ),
                  child: Row(
                    children: <Widget>[
                      Text(_country?.flag ?? '🌍', style: const TextStyle(fontSize: 25)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _country?.name ?? 'Select Country',
                          style: TextStyle(
                            color: _country == null ? AppColors.muted : AppColors.text,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const Icon(Icons.expand_more_rounded),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 22),
              SizedBox(
                height: 52,
                child: FilledButton(
                  onPressed: _submitting ? null : _submit,
                  child: Text(_submitting ? 'Creating Account…' : 'Create Account'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
