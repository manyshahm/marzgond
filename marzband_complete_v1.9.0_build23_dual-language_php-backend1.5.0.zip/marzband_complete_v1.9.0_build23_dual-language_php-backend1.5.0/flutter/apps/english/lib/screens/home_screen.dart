import 'dart:math';
import 'dart:ui' show BlurStyle, MaskFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/auth_gate.dart';
import '../services/network_status.dart';
import '../state/auth_state.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/neon_background.dart';
import '../widgets/player_avatar.dart';
import 'league_ranking_screen.dart';
import 'matchmaking_screen.dart';
import 'offline_mode_screen.dart';
import 'profile_screen.dart';
import 'store_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  int _previousIndex = 0;
  bool _exitDialogOpen = false;

  @override
  void initState() {
    super.initState();
    NetworkStatus.instance.addListener(_networkChanged);
  }

  @override
  void dispose() {
    NetworkStatus.instance.removeListener(_networkChanged);
    super.dispose();
  }

  void _networkChanged() {
    if (mounted) setState(() {});
  }

  void _showOfflineMessage() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('No internet connection')),
    );
  }

  Future<void> _openOnline() async {
    if (!NetworkStatus.instance.isOnline) {
      _showOfflineMessage();
      return;
    }
    if (!await AuthGate.ensureLoggedIn(context) || !mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const MatchmakingScreen()),
    );
  }

  void _openOffline() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const OfflineModeScreen()),
    );
  }

  void _openStore() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const StoreScreen()),
    );
  }

  Future<void> _openProfile() async {
    final oldIndex = _index;
    if (!await AuthGate.ensureLoggedIn(context) || !mounted) {
      if (_index != oldIndex) setState(() => _index = oldIndex);
      return;
    }
    _selectIndex(2);
  }

  Future<void> _onDestinationSelected(int value) async {
    if (value == _index) return;
    if (value == 1 && !NetworkStatus.instance.isOnline) {
      _showOfflineMessage();
      return;
    }
    if (value == 2) {
      await _openProfile();
      return;
    }
    _selectIndex(value);
  }

  void _selectIndex(int value) {
    if (!mounted || value == _index) return;
    HapticFeedback.selectionClick();
    setState(() {
      _previousIndex = _index;
      _index = value;
    });
  }

  Future<void> _handleBack() async {
    if (_index != 0) {
      _selectIndex(0);
      return;
    }
    if (_exitDialogOpen) return;
    _exitDialogOpen = true;
    final exit = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (context) => AlertDialog(
            title: const Text('Exit Game'),
            content: const Text('Do you want to exit Wallfront?'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('No'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Yes'),
              ),
            ],
          ),
        ) ??
        false;
    _exitDialogOpen = false;
    if (exit) await SystemNavigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final isOnline = NetworkStatus.instance.isOnline;
    final pages = <Widget>[
      _HomeTab(
        active: _index == 0,
        onOnline: _openOnline,
        onOffline: _openOffline,
        onProfile: _openProfile,
        onStore: _openStore,
        onLeague: () {
          if (isOnline) {
            _selectIndex(1);
          } else {
            _showOfflineMessage();
          }
        },
        onlineEnabled: isOnline,
      ),
      const LeagueRankingScreen(),
      const ProfileScreen(),
    ];

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _handleBack();
      },
      child: Scaffold(
        extendBody: true,
        body: NeonBackground(
          child: Stack(
            children: List<Widget>.generate(pages.length, (index) {
              final active = index == _index;
              final slideDirection = _index >= _previousIndex ? 1.0 : -1.0;
              return Positioned.fill(
                child: IgnorePointer(
                  ignoring: !active,
                  child: AnimatedOpacity(
                    opacity: active ? 1 : 0,
                    duration: const Duration(milliseconds: 190),
                    curve: Curves.easeOut,
                    child: AnimatedSlide(
                      offset: active ? Offset.zero : Offset(0.025 * slideDirection, 0),
                      duration: const Duration(milliseconds: 190),
                      curve: Curves.easeOut,
                      child: TickerMode(enabled: active, child: pages[index]),
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
        bottomNavigationBar: _GameBottomNavigation(
          selectedIndex: _index,
          onSelected: _onDestinationSelected,
          rankingEnabled: isOnline,
        ),
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab({
    required this.active,
    required this.onOnline,
    required this.onOffline,
    required this.onProfile,
    required this.onStore,
    required this.onLeague,
    required this.onlineEnabled,
  });

  final bool active;
  final VoidCallback onOnline;
  final VoidCallback onOffline;
  final VoidCallback onProfile;
  final VoidCallback onStore;
  final VoidCallback onLeague;
  final bool onlineEnabled;

  @override
  Widget build(BuildContext context) {
    final preferences = PlayerPreferences.instance;
    final auth = AuthState.instance;
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[preferences, auth]),
      builder: (context, _) {
        return SafeArea(
          bottom: false,
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              Positioned.fill(
                child: Image.asset(
                  'assets/images/home/home_bg.webp',
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.medium,
                ),
              ),
              Positioned.fill(
                child: TickerMode(enabled: active, child: const _HomeParticles()),
              ),
              const Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: <Color>[
                          Color(0x22000000),
                          Color(0x00000000),
                          Color(0x30000000),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 104),
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        PlayerAvatar(
                          avatar: preferences.avatarChoice,
                          size: 62,
                          selected: true,
                          onTap: onProfile,
                        ),
                        const Spacer(),
                        _HeaderValue(
                          icon: Icons.emoji_events_rounded,
                          value: preferences.cups,
                          color: AppColors.cyan,
                          onTap: onLeague,
                        ),
                        const SizedBox(width: 8),
                        _HeaderValue(
                          icon: Icons.monetization_on_rounded,
                          value: preferences.coins,
                          color: AppColors.gold,
                          onTap: onStore,
                        ),
                      ],
                    ),
                    const Spacer(),
                    const Text(
                      'BATTLE OF WALLS',
                      style: TextStyle(
                        color: AppColors.cyan,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                        shadows: <Shadow>[
                          Shadow(color: Colors.black54, blurRadius: 12),
                        ],
                      ),
                    ),
                    const SizedBox(height: 15),
                    _AnimatedImageButton(
                      imagePath: 'assets/images/home/online_button.webp',
                      onTap: onOnline,
                      enabled: onlineEnabled,
                    ),
                    const SizedBox(height: 12),
                    _AnimatedImageButton(
                      imagePath: 'assets/images/home/offline_button.webp',
                      onTap: onOffline,
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _GameBottomNavigation extends StatelessWidget {
  const _GameBottomNavigation({
    required this.selectedIndex,
    required this.onSelected,
    required this.rankingEnabled,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final bool rankingEnabled;

  @override
  Widget build(BuildContext context) {
    final preferences = PlayerPreferences.instance;
    return AnimatedBuilder(
      animation: preferences,
      builder: (context, _) {
        return SafeArea(
          minimum: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          child: Container(
            height: 72,
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: const Color(0xE80A1120),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0xFF243552), width: 1.2),
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: _NavItem(
                    label: 'Home',
                    icon: Icons.castle_rounded,
                    color: AppColors.blue,
                    selected: selectedIndex == 0,
                    onTap: () => onSelected(0),
                  ),
                ),
                Expanded(
                  child: _NavItem(
                    label: 'Ranking',
                    icon: Icons.workspace_premium_rounded,
                    color: AppColors.gold,
                    selected: selectedIndex == 1,
                    enabled: rankingEnabled,
                    onTap: () => onSelected(1),
                  ),
                ),
                Expanded(
                  child: _NavItem(
                    label: 'Profile',
                    color: AppColors.cyan,
                    selected: selectedIndex == 2,
                    avatar: PlayerAvatar(
                      avatar: preferences.avatarChoice,
                      size: 28,
                      selected: selectedIndex == 2,
                    ),
                    onTap: () => onSelected(2),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
    this.icon,
    this.avatar,
    this.enabled = true,
  });

  final String label;
  final IconData? icon;
  final Widget? avatar;
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 170),
        curve: Curves.easeOut,
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          color: selected && enabled ? color.withValues(alpha: 0.16) : Colors.transparent,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(
            color: selected && enabled ? color.withValues(alpha: 0.62) : Colors.transparent,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            AnimatedScale(
              scale: selected ? 1.08 : 0.94,
              duration: const Duration(milliseconds: 170),
              child: avatar ?? Icon(
                icon,
                color: selected && enabled ? color : AppColors.muted.withValues(alpha: enabled ? 1 : 0.45),
                size: 25,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              maxLines: 1,
              style: TextStyle(
                color: selected && enabled ? color : AppColors.muted.withValues(alpha: enabled ? 1 : 0.45),
                fontSize: 10.5,
                fontWeight: selected ? FontWeight.w900 : FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeaderValue extends StatelessWidget {
  const _HeaderValue({
    required this.icon,
    required this.value,
    required this.color,
    this.onTap,
  });

  final IconData icon;
  final int value;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final content = Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xB00B1222),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.38)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 6),
          Text('$value', style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
    if (onTap == null) return content;
    return GestureDetector(onTap: onTap, child: content);
  }
}

class _AnimatedImageButton extends StatefulWidget {
  const _AnimatedImageButton({required this.imagePath, required this.onTap, this.enabled = true});

  final String imagePath;
  final VoidCallback onTap;
  final bool enabled;

  @override
  State<_AnimatedImageButton> createState() => _AnimatedImageButtonState();
}

class _AnimatedImageButtonState extends State<_AnimatedImageButton> {
  bool _pressed = false;
  bool _opening = false;

  Future<void> _activate() async {
    if (_opening || !widget.enabled) return;
    _opening = true;
    HapticFeedback.selectionClick();
    setState(() => _pressed = true);
    await Future<void>.delayed(const Duration(milliseconds: 90));
    if (!mounted) return;
    setState(() => _pressed = false);
    await Future<void>.delayed(const Duration(milliseconds: 80));
    if (!mounted) return;
    widget.onTap();
    await Future<void>.delayed(const Duration(milliseconds: 220));
    _opening = false;
  }

  @override
  Widget build(BuildContext context) {
    final width = min(MediaQuery.sizeOf(context).width * 0.82, 330.0);
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: widget.enabled ? _activate : widget.onTap,
      onTapDown: (_) {
        if (!_opening) setState(() => _pressed = true);
      },
      onTapCancel: () {
        if (!_opening) setState(() => _pressed = false);
      },
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1,
        duration: const Duration(milliseconds: 95),
        curve: Curves.easeOut,
        child: AnimatedOpacity(
          opacity: widget.enabled ? (_pressed ? 0.92 : 1) : 0.42,
          duration: const Duration(milliseconds: 95),
          child: Image.asset(
            widget.imagePath,
            width: width,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.high,
          ),
        ),
      ),
    );
  }
}

class _HomeParticles extends StatefulWidget {
  const _HomeParticles();

  @override
  State<_HomeParticles> createState() => _HomeParticlesState();
}

class _HomeParticlesState extends State<_HomeParticles>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: CustomPaint(painter: _ParticlePainter(animation: _controller)),
      ),
    );
  }
}

class _ParticlePainter extends CustomPainter {
  _ParticlePainter({required this.animation}) : super(repaint: animation);

  final Animation<double> animation;

  @override
  void paint(Canvas canvas, Size size) {
    final progress = animation.value;
    for (var i = 0; i < 18; i++) {
      final leftSide = i.isEven;
      final phase = (progress + i * 0.083) % 1.0;
      final baseX = leftSide ? size.width * 0.05 : size.width * 0.95;
      final spread = size.width * (0.05 + (i % 4) * 0.018);
      final wobble = sin((phase * pi * 2) + i) * spread;
      final x = leftSide ? baseX + wobble.abs() : baseX - wobble.abs();
      final y = size.height * (0.73 - phase * 0.48);
      final fade = sin(phase * pi).clamp(0.0, 1.0).toDouble();
      final radius = 1.2 + (i % 4) * 0.65;
      final color = leftSide ? AppColors.blue : AppColors.orange;
      canvas.drawCircle(
        Offset(x, y),
        radius,
        Paint()
          ..color = color.withValues(alpha: 0.15 + fade * 0.62)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * 1.8),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter oldDelegate) => false;
}
