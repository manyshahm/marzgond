import 'package:flutter/material.dart';

import '../models/country.dart';
import '../services/app_navigation.dart';
import '../state/auth_state.dart';
import '../state/game_history_store.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/player_avatar.dart';
import 'auth/country_picker_screen.dart';
import 'match_history_screen.dart';
import 'store_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final preferences = PlayerPreferences.instance;
    final history = GameHistoryStore.instance;
    final auth = AuthState.instance;
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[preferences, history, auth]),
      builder: (context, _) {
        if (!auth.isLoggedIn) {
          return const SafeArea(
            child: Center(
              child: Text(
                'Sign in to view your profile.',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
          );
        }
        final wins = preferences.wins;
        final losses = preferences.losses;
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
            children: <Widget>[
              const Text(
                'Profile',
                style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 18),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: <Widget>[
                      PlayerAvatar(
                        avatar: preferences.avatarChoice,
                        size: 112,
                        selected: true,
                      ),
                      const SizedBox(height: 14),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(auth.country.flag, style: const TextStyle(fontSize: 24)),
                          const SizedBox(width: 8),
                          Text(
                            auth.name,
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        auth.email,
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(color: AppColors.muted),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: <Widget>[
                          Expanded(child: _Stat(value: '$wins', label: 'Win')),
                          Expanded(child: _Stat(value: '$losses', label: 'Loss')),
                          Expanded(
                            child: _Stat(value: '${preferences.cups}', label: 'Cups'),
                          ),
                          Expanded(
                            child: _Stat(value: '${preferences.coins}', label: 'Coins'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              _ProfileTile(
                icon: Icons.public_rounded,
                title: 'Country',
                subtitle: '${auth.country.flag} ${auth.country.name}',
                onTap: () async {
                  final selected = await Navigator.of(context).push<CountryInfo>(
                    MaterialPageRoute<CountryInfo>(
                      builder: (_) => const CountryPickerScreen(),
                    ),
                  );
                  if (selected != null) await auth.updateCountry(selected);
                },
              ),
              _ProfileTile(
                icon: Icons.shopping_bag_rounded,
                title: 'Store & Customization',
                subtitle: 'Earn coins, buy walls, and choose an avatar',
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const StoreScreen()),
                  );
                },
              ),
              _ProfileTile(
                icon: Icons.history_rounded,
                title: 'Match History',
                subtitle: 'Your latest 20 matches and in-game replays',
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const MatchHistoryScreen(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  await auth.logout();
                  if (!context.mounted) return;
                  AppNavigation.goHome(context);
                },
                icon: const Icon(Icons.logout_rounded),
                label: const Text('Sign Out'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.value, required this.label});

  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          value,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(color: AppColors.muted, fontSize: 12),
        ),
      ],
    );
  }
}

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        leading: Icon(icon, color: AppColors.cyan),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}
