import 'dart:async';

import 'package:flutter/material.dart';

import '../engine/game_engine.dart';
import '../models/game_history.dart';
import '../models/game_models.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/game_background.dart';
import '../widgets/game_board.dart';
import '../widgets/player_avatar.dart';

class ReplayScreen extends StatefulWidget {
  const ReplayScreen({required this.entry, super.key});

  final GameHistoryEntry entry;

  @override
  State<ReplayScreen> createState() => _ReplayScreenState();
}

class _ReplayScreenState extends State<ReplayScreen> {
  late GameEngine _engine;
  Timer? _timer;
  int _index = 0;
  bool _playing = false;

  @override
  void initState() {
    super.initState();
    _engine = GameEngine(mode: widget.entry.mode);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _togglePlay() {
    if (_playing) {
      _timer?.cancel();
      setState(() => _playing = false);
      return;
    }
    if (_index >= widget.entry.moves.length) _reset();
    setState(() => _playing = true);
    _timer = Timer.periodic(const Duration(milliseconds: 520), (_) {
      if (!mounted) return;
      if (_index >= widget.entry.moves.length) {
        _timer?.cancel();
        setState(() => _playing = false);
        return;
      }
      _apply(widget.entry.moves[_index]);
      setState(() => _index++);
    });
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _engine = GameEngine(mode: widget.entry.mode);
      _index = 0;
      _playing = false;
    });
  }

  void _apply(MoveRecord move) {
    if (_engine.turn != move.player) _engine.turn = move.player;
    if (move.isWall) {
      final wall = move.wall!;
      _engine.placeWall(
        row: wall.row,
        col: wall.col,
        orientation: wall.orientation,
      );
    } else {
      _engine.move(move.to!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final preferences = PlayerPreferences.instance;
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Replay Match'),
          backgroundColor: Colors.transparent,
          leading: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
        ),
        body: GameBackground(
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
              child: Column(
                children: <Widget>[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.surface.withValues(alpha: 0.88),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0xFF293A56)),
                    ),
                    child: Row(
                      children: <Widget>[
                        PlayerAvatar(
                          avatar: preferences.avatarChoice,
                          size: 48,
                          selected: true,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                widget.entry.didPlayerWin ? 'Victory' : 'Defeat',
                                style: const TextStyle(
                                  fontSize: 19,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                widget.entry.finishReason,
                                style: const TextStyle(color: AppColors.muted),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '$_index/${widget.entry.moves.length}',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: GameBoard(
                      engine: _engine,
                      interactive: false,
                      onMove: (_) {},
                      onWall: (_, __, ___) {},
                      primaryColor: preferences.playerColor,
                      secondaryColor: preferences.opponentColor,
                      primaryWallColor: preferences.playerWallColor,
                      secondaryWallColor: preferences.opponentWallColor,
                      activeColor: preferences.playerColor,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: SizedBox(
                          height: 54,
                          child: OutlinedButton.icon(
                            onPressed: _reset,
                            icon: const Icon(Icons.replay_rounded),
                            label: const Text(
                              'Restart',
                              style: TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: SizedBox(
                          height: 54,
                          child: FilledButton.icon(
                            onPressed: _togglePlay,
                            icon: Icon(
                              _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                            ),
                            label: Text(
                              _playing ? 'Pause' : 'Play',
                              style: const TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
