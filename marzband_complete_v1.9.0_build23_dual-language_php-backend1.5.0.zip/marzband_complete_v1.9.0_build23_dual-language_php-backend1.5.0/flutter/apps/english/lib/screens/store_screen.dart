import 'dart:async';

import 'package:flutter/material.dart';

import '../config/economy_config.dart';
import '../services/auth_gate.dart';
import '../services/network_status.dart';
import '../services/rewarded_ad_service.dart';
import '../state/auth_state.dart';
import '../state/player_preferences.dart';
import '../theme/app_theme.dart';
import '../widgets/fortune_wheel.dart';
import '../widgets/neon_background.dart';
import '../widgets/player_avatar.dart';

class StoreScreen extends StatefulWidget {
  const StoreScreen({super.key});

  @override
  State<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends State<StoreScreen> {
  final PlayerPreferences _preferences = PlayerPreferences.instance;

  @override
  void initState() {
    super.initState();
    if (AuthState.instance.isLoggedIn && NetworkStatus.instance.isOnline) {
      unawaited(_preferences.syncFromServer());
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Store & Customization'),
            backgroundColor: Colors.transparent,
            leading: IconButton(
              onPressed: () => Navigator.of(context).maybePop(),
              icon: const Icon(Icons.arrow_back_rounded),
            ),
            bottom: const TabBar(
              tabs: <Tab>[
                Tab(text: 'Coins', icon: Icon(Icons.monetization_on_rounded)),
                Tab(text: 'Walls', icon: Icon(Icons.view_week_rounded)),
                Tab(text: 'Avatars', icon: Icon(Icons.face_rounded)),
              ],
            ),
          ),
          body: NeonBackground(
            child: AnimatedBuilder(
              animation: _preferences,
              builder: (context, _) => Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.gold.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: AppColors.gold.withValues(alpha: 0.4),
                        ),
                      ),
                      child: Row(
                        children: <Widget>[
                          const Icon(
                            Icons.monetization_on_rounded,
                            color: AppColors.gold,
                          ),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Text(
                              'Coin Balance',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                          ),
                          Text(
                            '${_preferences.coins}',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: TabBarView(
                      children: <Widget>[
                        _CoinRewardsTab(preferences: _preferences),
                        _WallsTab(preferences: _preferences),
                        _AvatarTab(preferences: _preferences),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CoinRewardsTab extends StatefulWidget {
  const _CoinRewardsTab({required this.preferences});

  final PlayerPreferences preferences;

  @override
  State<_CoinRewardsTab> createState() => _CoinRewardsTabState();
}

class _CoinRewardsTabState extends State<_CoinRewardsTab> {
  bool _showingAd = false;

  Future<bool> _ensureAccount() async {
    if (!NetworkStatus.instance.isOnline) {
      _message('No internet connection');
      return false;
    }
    if (!AuthState.instance.isLoggedIn) {
      return AuthGate.ensureLoggedIn(context);
    }
    return true;
  }

  void _message(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _watchAdForCoins() async {
    if (_showingAd || !await _ensureAccount()) return;
    setState(() => _showingAd = true);
    final rewarded = await RewardedAdService.show(context);
    if (!mounted) return;
    if (rewarded) {
      final before = widget.preferences.coins;
      await widget.preferences.addCoins(EconomyConfig.rewardedAdCoins);
      final received = widget.preferences.coins - before;
      _message(received > 0 ? '$received coins received.' : 'Reward could not be saved.');
    } else {
      _message('The video was not completed.');
    }
    if (mounted) setState(() => _showingAd = false);
  }

  Future<void> _showDailyReward() async {
    if (!await _ensureAccount()) return;
    await widget.preferences.syncFromServer();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AnimatedBuilder(
        animation: widget.preferences,
        builder: (context, _) {
          final available = widget.preferences.hasPendingDailyReward;
          return AlertDialog(
            icon: const Icon(
              Icons.calendar_month_rounded,
              color: AppColors.gold,
              size: 42,
            ),
            title: Text('Daily Login — Day ${widget.preferences.pendingDailyRewardDay}'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  available
                      ? '${widget.preferences.pendingDailyRewardCoins} coins are ready.'
                      : 'Today’s reward has already been claimed.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(height: 1.6),
                ),
                const SizedBox(height: 10),
                Text(
                  'Current streak: ${widget.preferences.dailyStreak} days',
                  style: const TextStyle(color: AppColors.muted),
                ),
              ],
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
              FilledButton.icon(
                onPressed: available
                    ? () async {
                        final awarded = await widget.preferences.claimDailyReward();
                        if (!context.mounted) return;
                        Navigator.of(context).pop();
                        _message(
                          awarded > 0
                              ? '$awarded daily reward coins received.'
                              : 'Reward could not be claimed.',
                        );
                      }
                    : null,
                icon: const Icon(Icons.card_giftcard_rounded),
                label: Text(available ? 'Claim Reward' : 'Claimed'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _showWheel() async {
    if (!await _ensureAccount()) return;
    await widget.preferences.syncFromServer();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => _WheelDialog(preferences: widget.preferences),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
      children: <Widget>[
        _RewardCard(
          icon: Icons.ondemand_video_rounded,
          color: AppColors.cyan,
          title: 'Watch Rewarded Video',
          buttonText: _showingAd
              ? 'Loading…'
              : 'Claim ${EconomyConfig.rewardedAdCoins} Coins',
          onPressed: _showingAd ? null : _watchAdForCoins,
        ),
        const SizedBox(height: 10),
        _RewardCard(
          icon: Icons.calendar_month_rounded,
          color: AppColors.gold,
          title: 'Daily Login Reward',
          buttonText: 'View Daily Reward',
          onPressed: _showDailyReward,
        ),
        const SizedBox(height: 10),
        _RewardCard(
          icon: Icons.casino_rounded,
          color: AppColors.purple,
          title: 'Daily Fortune Wheel',
          buttonText: 'Open Fortune Wheel',
          onPressed: _showWheel,
        ),
      ],
    );
  }
}

class _WheelDialog extends StatefulWidget {
  const _WheelDialog({required this.preferences});

  final PlayerPreferences preferences;

  @override
  State<_WheelDialog> createState() => _WheelDialogState();
}

class _WheelDialogState extends State<_WheelDialog> {
  Timer? _timer;
  bool _spinning = false;
  double _turns = 0;
  int _prize = 0;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _remainingLabel() {
    final remaining = widget.preferences.wheelRemaining;
    final hours = remaining.inHours;
    final minutes = remaining.inMinutes.remainder(60);
    final seconds = remaining.inSeconds.remainder(60);
    return '${hours.toString().padLeft(2, '0')}:'
        '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  Future<void> _spin() async {
    if (_spinning || !widget.preferences.canSpinWheelToday) return;
    final prize = await widget.preferences.beginWheelSpin();
    if (!mounted || prize <= 0) return;
    final index = EconomyConfig.wheelPrizes.indexOf(prize);
    final fraction = (1 - ((index + 0.5) / EconomyConfig.wheelPrizes.length)) % 1;
    setState(() {
      _spinning = true;
      _prize = prize;
      _turns = _turns.ceilToDouble() + 6 + fraction;
    });
  }

  void _animationEnded() {
    if (!_spinning) return;
    setState(() => _spinning = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$_prize wheel coins received.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final canSpin = widget.preferences.canSpinWheelToday && !_spinning;
    return AlertDialog(
      title: const Text('Daily Fortune Wheel'),
      content: SizedBox(
        width: 330,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              width: 230,
              height: 230,
              child: AnimatedRotation(
                turns: _turns,
                duration: const Duration(milliseconds: 3200),
                curve: Curves.easeOutCubic,
                onEnd: _animationEnded,
                child: const FortuneWheel(prizes: EconomyConfig.wheelPrizes),
              ),
            ),
            const SizedBox(height: 16),
            if (!widget.preferences.canSpinWheelToday)
              Text(
                'Next spin in ${_remainingLabel()}',
                style: const TextStyle(
                  color: AppColors.muted,
                  fontWeight: FontWeight.w800,
                ),
              ),
            if (_prize > 0 && !_spinning)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'You won $_prize coins',
                  style: const TextStyle(
                    color: AppColors.gold,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: _spinning ? null : () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
        FilledButton.icon(
          onPressed: canSpin ? _spin : null,
          style: FilledButton.styleFrom(
            backgroundColor: canSpin ? const Color(0xFF26B66E) : const Color(0xFF596273),
            disabledBackgroundColor: const Color(0xFF596273),
          ),
          icon: const Icon(Icons.casino_rounded),
          label: Text(_spinning ? 'Spinning…' : 'Spin'),
        ),
      ],
    );
  }
}

class _RewardCard extends StatelessWidget {
  const _RewardCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.buttonText,
    required this.onPressed,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String buttonText;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 104,
      child: Card(
        margin: EdgeInsets.zero,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final narrow = constraints.maxWidth < 390;
            final infoWidth = narrow ? 126.0 : 148.0;
            return Padding(
              padding: EdgeInsets.symmetric(
                horizontal: narrow ? 11 : 14,
                vertical: 10,
              ),
              child: Row(
                children: <Widget>[
                  SizedBox(
                    width: infoWidth,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          title,
                          maxLines: 2,
                          softWrap: true,
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: narrow ? 14 : 15,
                            fontWeight: FontWeight.w900,
                            height: 1.05,
                          ),
                        ),
                        const SizedBox(height: 7),
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.14),
                            borderRadius: BorderRadius.circular(13),
                          ),
                          child: Icon(icon, color: color, size: 24),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: narrow ? 8 : 12),
                  Expanded(
                    child: SizedBox(
                      height: 46,
                      child: FilledButton(
                        onPressed: onPressed,
                        style: FilledButton.styleFrom(
                          padding: EdgeInsets.symmetric(
                            horizontal: narrow ? 8 : 12,
                          ),
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            buttonText,
                            maxLines: 1,
                            softWrap: false,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _WallsTab extends StatelessWidget {
  const _WallsTab({required this.preferences});

  final PlayerPreferences preferences;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.92,
      ),
      itemCount: WallSkinChoice.values.length,
      itemBuilder: (context, index) {
        final choice = WallSkinChoice.values[index];
        final owned = preferences.ownsWall(choice);
        final selected = preferences.wallSkinChoice == choice;
        return _ShopCard(
          title: choice.label,
          price: choice.price,
          owned: owned,
          selected: selected,
          preview: _WallPreview(choice: choice),
          onTap: () async {
            if (!NetworkStatus.instance.isOnline) {
              _showStoreMessage(context, 'No internet connection');
              return;
            }
            if (!AuthState.instance.isLoggedIn &&
                !await AuthGate.ensureLoggedIn(context)) {
              return;
            }
            final success = await preferences.buyWallSkin(choice);
            if (!context.mounted) return;
            if (!success) _showNotEnough(context);
          },
        );
      },
    );
  }
}

class _AvatarTab extends StatelessWidget {
  const _AvatarTab({required this.preferences});

  final PlayerPreferences preferences;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.78,
      ),
      itemCount: storeAvatarChoices.length,
      itemBuilder: (context, index) {
        final choice = storeAvatarChoices[index];
        return _ShopCard(
          title: choice.label,
          price: choice.price,
          owned: preferences.ownsAvatar(choice),
          selected: preferences.avatarChoice == choice,
          preview: PlayerAvatar(avatar: choice, size: 86),
          onTap: () async {
            if (!NetworkStatus.instance.isOnline) {
              _showStoreMessage(context, 'No internet connection');
              return;
            }
            if (!AuthState.instance.isLoggedIn &&
                !await AuthGate.ensureLoggedIn(context)) {
              return;
            }
            final success = await preferences.buyAvatar(choice);
            if (!context.mounted) return;
            if (!success) _showNotEnough(context);
          },
        );
      },
    );
  }
}

class _ShopCard extends StatelessWidget {
  const _ShopCard({
    required this.title,
    required this.price,
    required this.owned,
    required this.selected,
    required this.preview,
    required this.onTap,
  });

  final String title;
  final int price;
  final bool owned;
  final bool selected;
  final Widget preview;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              preview,
              const SizedBox(height: 11),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 7),
                decoration: BoxDecoration(
                  color: selected
                      ? const Color(0xFF31C875).withValues(alpha: 0.16)
                      : AppColors.surfaceAlt,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  selected
                      ? 'Selected'
                      : owned
                          ? 'Select'
                          : price == 0
                              ? 'Free'
                              : '$price Coins',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: selected ? const Color(0xFF31C875) : AppColors.text,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WallPreview extends StatelessWidget {
  const _WallPreview({required this.choice});

  final WallSkinChoice choice;

  @override
  Widget build(BuildContext context) {
    final gradient = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: choice.gradientColors,
    );
    return SizedBox(
      height: 76,
      child: Center(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  width: 78,
                  height: 13,
                  decoration: BoxDecoration(
                    gradient: gradient,
                    borderRadius: BorderRadius.circular(99),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.48),
                    ),
                  ),
                ),
                const SizedBox(height: 9),
                Container(
                  width: 25,
                  height: 25,
                  decoration: BoxDecoration(
                    gradient: gradient,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.48),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 11),
            Container(
              width: 13,
              height: 58,
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(99),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.48),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void _showStoreMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

void _showNotEnough(BuildContext context) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text('Not enough coins to buy this item.')),
  );
}
