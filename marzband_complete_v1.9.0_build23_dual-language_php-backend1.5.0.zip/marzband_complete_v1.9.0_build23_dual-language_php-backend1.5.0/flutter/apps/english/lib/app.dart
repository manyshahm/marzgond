import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';

class MarzbandApp extends StatelessWidget {
  const MarzbandApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Wallfront: Battle of Walls',
      theme: AppTheme.dark,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.ltr,
        child: child ?? const SizedBox.shrink(),
      ),
      routes: <String, WidgetBuilder>{
        '/home': (_) => const HomeScreen(),
      },
      home: const SplashScreen(),
    );
  }
}
