import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class FortuneWheel extends StatelessWidget {
  const FortuneWheel({required this.prizes, super.key});

  final List<int> prizes;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: <Widget>[
          CustomPaint(
            painter: _FortuneWheelPainter(prizes),
            child: const SizedBox.expand(),
          ),
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: AppColors.surface,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withValues(alpha: 0.45), width: 2),
            ),
            child: const Icon(Icons.casino_rounded, color: AppColors.gold, size: 30),
          ),
          const Positioned(
            top: -14,
            child: Icon(Icons.arrow_drop_down_rounded, color: AppColors.gold, size: 48),
          ),
        ],
      ),
    );
  }
}

class _FortuneWheelPainter extends CustomPainter {
  const _FortuneWheelPainter(this.prizes);

  final List<int> prizes;

  static const List<Color> _colors = <Color>[
    AppColors.blue,
    AppColors.orange,
    AppColors.purple,
    AppColors.cyan,
    AppColors.red,
    AppColors.gold,
    Color(0xFF31C875),
    Color(0xFF315BCE),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    if (prizes.isEmpty) return;
    final center = size.center(Offset.zero);
    final radius = size.shortestSide / 2 - 5;
    final sweep = math.pi * 2 / prizes.length;
    final rect = Rect.fromCircle(center: center, radius: radius);

    for (var index = 0; index < prizes.length; index++) {
      final start = -math.pi / 2 + index * sweep;
      final paint = Paint()
        ..color = _colors[index % _colors.length].withValues(alpha: 0.88)
        ..style = PaintingStyle.fill;
      canvas.drawArc(rect, start, sweep, true, paint);
      canvas.drawArc(
        rect,
        start,
        sweep,
        true,
        Paint()
          ..color = Colors.white.withValues(alpha: 0.24)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2,
      );

      final angle = start + sweep / 2;
      final labelCenter = Offset(
        center.dx + math.cos(angle) * radius * 0.66,
        center.dy + math.sin(angle) * radius * 0.66,
      );
      final textPainter = TextPainter(
        text: TextSpan(
          text: '${prizes[index]}',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w900,
            shadows: <Shadow>[Shadow(color: Colors.black54, blurRadius: 5)],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      textPainter.paint(
        canvas,
        labelCenter - Offset(textPainter.width / 2, textPainter.height / 2),
      );
    }

    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = AppColors.gold.withValues(alpha: 0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4,
    );
  }

  @override
  bool shouldRepaint(covariant _FortuneWheelPainter oldDelegate) {
    return oldDelegate.prizes != prizes;
  }
}
