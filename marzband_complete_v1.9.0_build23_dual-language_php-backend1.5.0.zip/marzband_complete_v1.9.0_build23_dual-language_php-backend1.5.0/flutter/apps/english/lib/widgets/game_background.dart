import 'package:flutter/material.dart';

class GameBackground extends StatelessWidget {
  const GameBackground({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: <Widget>[
        Positioned.fill(
          child: Image.asset(
            'assets/images/game/game_bg.webp',
            fit: BoxFit.cover,
            filterQuality: FilterQuality.medium,
          ),
        ),
        const Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: <Color>[
                  Color(0x44000000),
                  Color(0x18000000),
                  Color(0x52000000),
                ],
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}
