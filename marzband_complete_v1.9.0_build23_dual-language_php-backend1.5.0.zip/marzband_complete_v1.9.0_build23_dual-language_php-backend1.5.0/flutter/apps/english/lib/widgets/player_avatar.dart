import 'package:flutter/material.dart';

import '../state/player_preferences.dart';

class PlayerAvatar extends StatelessWidget {
  const PlayerAvatar({
    required this.avatar,
    required this.size,
    this.selected = false,
    this.onTap,
    super.key,
  });

  final AvatarChoice avatar;
  final double size;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final image = Image.asset(
      avatar.assetPath,
      width: size,
      height: size,
      fit: BoxFit.contain,
      alignment: Alignment.center,
      filterQuality: FilterQuality.medium,
      gaplessPlayback: true,
    );

    final content = SizedBox.square(
      dimension: size,
      child: DecoratedBox(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: selected
              ? Border.all(
                  color: avatar.accent.withValues(alpha: 0.92),
                  width: size >= 80 ? 2.2 : 1.5,
                )
              : null,
          boxShadow: selected
              ? <BoxShadow>[
                  BoxShadow(
                    color: avatar.accent.withValues(alpha: 0.22),
                    blurRadius: size * 0.12,
                  ),
                ]
              : null,
        ),
        child: ClipOval(child: image),
      ),
    );

    if (onTap == null) return content;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: content,
    );
  }
}
