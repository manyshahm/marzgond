import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../engine/game_engine.dart';
import '../models/game_models.dart';

class GameBoard extends StatefulWidget {
  const GameBoard({
    required this.engine,
    required this.onMove,
    required this.onWall,
    required this.primaryColor,
    required this.secondaryColor,
    this.primaryWallColor,
    this.secondaryWallColor,
    this.primaryWallGradient,
    this.secondaryWallGradient,
    required this.activeColor,
    this.previewVerticalOffsetCells = -1.15,
    this.interactive = true,
    super.key,
  });

  final GameEngine engine;
  final ValueChanged<Cell> onMove;
  final void Function(int row, int col, WallOrientation orientation) onWall;
  final Color primaryColor;
  final Color secondaryColor;
  final Color? primaryWallColor;
  final Color? secondaryWallColor;
  final List<Color>? primaryWallGradient;
  final List<Color>? secondaryWallGradient;
  final Color activeColor;
  final double previewVerticalOffsetCells;
  final bool interactive;

  @override
  State<GameBoard> createState() => _GameBoardState();
}

class _GameBoardState extends State<GameBoard> {
  final GlobalKey _boardKey = GlobalKey();
  _WallPreview? _preview;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = math.min(constraints.maxWidth, constraints.maxHeight);
        return Center(
          child: SizedBox.square(
            key: _boardKey,
            dimension: size,
            child: DragTarget<WallOrientation>(
              onWillAcceptWithDetails: (details) {
                if (!widget.interactive) return false;
                _updatePreview(details.offset, size, details.data);
                return true;
              },
              onMove: (details) {
                if (!widget.interactive) return;
                _updatePreview(details.offset, size, details.data);
              },
              onAcceptWithDetails: (details) {
                if (!widget.interactive) {
                  _clearPreview();
                  return;
                }
                _updatePreview(details.offset, size, details.data);
                final preview = _preview;
                if (preview != null && preview.isValid) {
                  widget.onWall(
                    preview.row,
                    preview.col,
                    preview.orientation,
                  );
                }
                _clearPreview();
              },
              onLeave: (_) => _clearPreview(),
              builder: (context, candidateData, rejectedData) {
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTapUp: widget.interactive
                      ? (details) => _handleTap(details.localPosition, size)
                      : null,
                  child: CustomPaint(
                    painter: _BoardPainter(
                      engine: widget.engine,
                      legalMoves: widget.interactive
                          ? widget.engine.legalMoves()
                          : const <Cell>{},
                      preview: _preview,
                      primaryColor: widget.primaryColor,
                      secondaryColor: widget.secondaryColor,
                      primaryWallColor: widget.primaryWallColor ?? widget.primaryColor,
                      secondaryWallColor: widget.secondaryWallColor ?? widget.secondaryColor,
                      primaryWallGradient: widget.primaryWallGradient,
                      secondaryWallGradient: widget.secondaryWallGradient,
                      activeColor: widget.activeColor,
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  void _handleTap(Offset position, double size) {
    final geometry = _BoardGeometry(size);
    if (!geometry.inner.contains(position)) return;

    final x = position.dx - geometry.inner.left;
    final y = position.dy - geometry.inner.top;
    final row = (y / geometry.cell).floor();
    final col = (x / geometry.cell).floor();

    if (row < 0 || row >= GameEngine.boardSize) return;
    if (col < 0 || col >= GameEngine.boardSize) return;

    widget.onMove(Cell(row, col));
  }

  void _updatePreview(
    Offset globalPosition,
    double size,
    WallOrientation orientation,
  ) {
    final renderObject =
        _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (renderObject == null || !renderObject.hasSize) return;

    final geometry = _BoardGeometry(size);
    final pointerLocal = renderObject.globalToLocal(globalPosition);
    final local = pointerLocal.translate(
      0,
      geometry.cell * widget.previewVerticalOffsetCells,
    );

    if (!geometry.inner.inflate(geometry.cell * 0.18).contains(local)) {
      _clearPreview();
      return;
    }

    final relativeX = local.dx - geometry.inner.left;
    final relativeY = local.dy - geometry.inner.top;

    final rawCol = (relativeX / geometry.cell - 1).round();
    final rawRow = (relativeY / geometry.cell - 1).round();
    final insideSlot = rawRow >= 0 &&
        rawRow <= GameEngine.boardSize - 2 &&
        rawCol >= 0 &&
        rawCol <= GameEngine.boardSize - 2;

    final row = rawRow.clamp(0, GameEngine.boardSize - 2) as int;
    final col = rawCol.clamp(0, GameEngine.boardSize - 2) as int;
    final legal = insideSlot &&
        widget.engine.canPlaceWall(
          row: row,
          col: col,
          orientation: orientation,
        );

    final next = _WallPreview(
      row: row,
      col: col,
      orientation: orientation,
      isValid: legal,
    );

    if (next == _preview) return;
    setState(() => _preview = next);
  }

  void _clearPreview() {
    if (_preview == null || !mounted) return;
    setState(() => _preview = null);
  }
}

@immutable
class _WallPreview {
  const _WallPreview({
    required this.row,
    required this.col,
    required this.orientation,
    required this.isValid,
  });

  final int row;
  final int col;
  final WallOrientation orientation;
  final bool isValid;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is _WallPreview &&
          row == other.row &&
          col == other.col &&
          orientation == other.orientation &&
          isValid == other.isValid;

  @override
  int get hashCode => Object.hash(row, col, orientation, isValid);
}

class _BoardGeometry {
  _BoardGeometry(double size)
      : boardRect = Rect.fromLTWH(
          size * 0.045,
          size * 0.045,
          size - size * 0.09,
          size - size * 0.09,
        ) {
    inner = boardRect.deflate(size * 0.018);
    cell = inner.width / GameEngine.boardSize;
  }

  final Rect boardRect;
  late final Rect inner;
  late final double cell;
}

class _BoardPainter extends CustomPainter {
  _BoardPainter({
    required this.engine,
    required this.legalMoves,
    required this.preview,
    required this.primaryColor,
    required this.secondaryColor,
    required this.primaryWallColor,
    required this.secondaryWallColor,
    required this.primaryWallGradient,
    required this.secondaryWallGradient,
    required this.activeColor,
  });

  final GameEngine engine;
  final Set<Cell> legalMoves;
  final _WallPreview? preview;
  final Color primaryColor;
  final Color secondaryColor;
  final Color primaryWallColor;
  final Color secondaryWallColor;
  final List<Color>? primaryWallGradient;
  final List<Color>? secondaryWallGradient;
  final Color activeColor;

  @override
  void paint(Canvas canvas, Size size) {
    final geometry = _BoardGeometry(size.width);
    final boardRect = geometry.boardRect;
    final inner = geometry.inner;
    final cell = geometry.cell;

    final framePaint = Paint()
      ..shader = LinearGradient(
        colors: <Color>[
          primaryColor.withValues(alpha: 0.62),
          secondaryColor.withValues(alpha: 0.62),
        ],
      ).createShader(boardRect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.007;
    canvas.drawRRect(
      RRect.fromRectAndRadius(boardRect, Radius.circular(size.width * 0.06)),
      framePaint,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(inner, Radius.circular(size.width * 0.045)),
      Paint()..color = const Color(0xFF0A101B),
    );

    final cellPaint = Paint()..color = const Color(0xFF121A28);
    final linePaint = Paint()
      ..color = const Color(0xFF34435E)
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.0, cell * 0.025).toDouble();

    for (var row = 0; row < GameEngine.boardSize; row++) {
      for (var col = 0; col < GameEngine.boardSize; col++) {
        final rect = Rect.fromLTWH(
          inner.left + col * cell + 2,
          inner.top + row * cell + 2,
          cell - 4,
          cell - 4,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.12)),
          cellPaint,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.12)),
          linePaint,
        );
        if (legalMoves.contains(Cell(row, col))) {
          canvas.drawCircle(
            rect.center,
            cell * 0.105,
            Paint()..color = activeColor.withValues(alpha: 0.9),
          );
        }
      }
    }

    for (final wall in engine.walls) {
      _drawWall(canvas, inner, cell, wall);
    }

    final currentPreview = preview;
    if (currentPreview != null) {
      _drawPreview(canvas, inner, cell, currentPreview);
    }

    _drawPawn(canvas, inner, cell, engine.blue, primaryColor);
    _drawPawn(canvas, inner, cell, engine.red, secondaryColor);
  }

  void _drawWall(Canvas canvas, Rect inner, double cell, Wall wall) {
    final color = wall.owner == Player.blue ? primaryWallColor : secondaryWallColor;
    final gradient = wall.owner == Player.blue
        ? primaryWallGradient
        : secondaryWallGradient;
    final rect = _wallRect(
      inner,
      cell,
      wall.row,
      wall.col,
      wall.orientation,
    );

    final paint = Paint();
    if (gradient != null && gradient.length > 1) {
      paint.shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: gradient
            .map((item) => item.withValues(alpha: 0.94))
            .toList(growable: false),
      ).createShader(rect);
    } else {
      paint.color = color.withValues(alpha: 0.88);
    }
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.08)),
      paint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.08)),
      Paint()
        ..color = Colors.white.withValues(alpha: 0.24)
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(0.7, cell * 0.018).toDouble(),
    );
  }

  void _drawPreview(
    Canvas canvas,
    Rect inner,
    double cell,
    _WallPreview preview,
  ) {
    final color = preview.isValid
        ? const Color(0xFF31E879)
        : const Color(0xFFFF3B4D);
    final rect = _wallRect(
      inner,
      cell,
      preview.row,
      preview.col,
      preview.orientation,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        rect.inflate(cell * 0.08),
        Radius.circular(cell * 0.12),
      ),
      Paint()..color = color.withValues(alpha: 0.18),
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.09)),
      Paint()..color = color.withValues(alpha: 0.92),
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.09)),
      Paint()
        ..color = Colors.white.withValues(alpha: 0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.5, cell * 0.035).toDouble(),
    );
  }

  Rect _wallRect(
    Rect inner,
    double cell,
    int row,
    int col,
    WallOrientation orientation,
  ) {
    final thickness = cell * 0.14;
    return orientation == WallOrientation.horizontal
        ? Rect.fromLTWH(
            inner.left + col * cell + cell * 0.05,
            inner.top + (row + 1) * cell - thickness / 2,
            cell * 1.9,
            thickness,
          )
        : Rect.fromLTWH(
            inner.left + (col + 1) * cell - thickness / 2,
            inner.top + row * cell + cell * 0.05,
            thickness,
            cell * 1.9,
          );
  }

  void _drawPawn(Canvas canvas, Rect inner, double cell, Cell pawn, Color color) {
    final center = Offset(
      inner.left + (pawn.col + 0.5) * cell,
      inner.top + (pawn.row + 0.5) * cell,
    );

    canvas.drawCircle(center, cell * 0.25, Paint()..color = color);
    canvas.drawCircle(
      center - Offset(cell * 0.07, cell * 0.08),
      cell * 0.065,
      Paint()..color = Colors.white.withValues(alpha: 0.82),
    );
  }

  @override
  bool shouldRepaint(covariant _BoardPainter oldDelegate) => true;
}
