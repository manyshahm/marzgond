import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:marzband/engine/bot_player.dart';
import 'package:marzband/engine/game_engine.dart';
import 'package:marzband/models/game_models.dart';

void main() {
  group('GameEngine', () {
    test('starts with correct positions and walls', () {
      final engine = GameEngine();
      expect(engine.blue, const Cell(8, 4));
      expect(engine.red, const Cell(0, 4));
      expect(engine.blueWalls, 10);
      expect(engine.redWalls, 10);
      expect(engine.turn, Player.blue);
    });

    test('blue can move one legal step', () {
      final engine = GameEngine();
      expect(engine.move(const Cell(7, 4)), isTrue);
      expect(engine.blue, const Cell(7, 4));
      expect(engine.turn, Player.red);
    });

    test('wall placement consumes one wall and switches turn', () {
      final engine = GameEngine();
      expect(
        engine.placeWall(
          row: 6,
          col: 3,
          orientation: WallOrientation.horizontal,
        ),
        isTrue,
      );
      expect(engine.blueWalls, 9);
      expect(engine.turn, Player.red);
    });

    test('crossing walls are rejected', () {
      final engine = GameEngine();
      expect(
        engine.placeWall(
          row: 4,
          col: 4,
          orientation: WallOrientation.horizontal,
        ),
        isTrue,
      );
      expect(
        engine.canPlaceWall(
          row: 4,
          col: 4,
          orientation: WallOrientation.vertical,
          forPlayer: Player.red,
        ),
        isFalse,
      );
    });

    test('both players always retain a path after legal wall', () {
      final engine = GameEngine();
      expect(
        engine.canPlaceWall(
          row: 2,
          col: 2,
          orientation: WallOrientation.vertical,
        ),
        isTrue,
      );
      expect(engine.shortestPathLength(Player.blue), isNotNull);
      expect(engine.shortestPathLength(Player.red), isNotNull);
    });

    test('invalid wall does not consume wall or switch turn', () {
      final engine = GameEngine();
      expect(
        engine.placeWall(
          row: -1,
          col: 0,
          orientation: WallOrientation.horizontal,
        ),
        isFalse,
      );
      expect(engine.blueWalls, 10);
      expect(engine.turn, Player.blue);
      expect(engine.walls, isEmpty);
    });

    test('expired turn switches player without consuming a wall', () {
      final engine = GameEngine();
      expect(engine.expireTurn(), isTrue);
      expect(engine.turn, Player.red);
      expect(engine.blueWalls, 10);
      expect(engine.redWalls, 10);
    });

    test('resign awards the game to the opponent', () {
      final engine = GameEngine();
      expect(engine.resign(), isTrue);
      expect(engine.winner, Player.red);
      expect(engine.isFinished, isTrue);
    });


    test('snapshot preserves move history for adaptive AI', () {
      final engine = GameEngine();
      expect(engine.move(const Cell(7, 4)), isTrue);
      final restored = GameEngine.fromSnapshot(engine.toSnapshot());
      expect(restored.history.length, 1);
      expect(restored.history.first.player, Player.blue);
      expect(restored.history.first.from, const Cell(8, 4));
      expect(restored.history.first.to, const Cell(7, 4));
    });

    test('clone keeps game state independent', () {
      final engine = GameEngine();
      expect(engine.move(const Cell(7, 4)), isTrue);
      final clone = engine.clone();
      expect(clone.red, engine.red);
      expect(clone.turn, engine.turn);
      clone.move(const Cell(1, 4));
      expect(engine.red, const Cell(0, 4));
    });



    test('easy bot avoids meaningless opening actions', () {
      final engine = GameEngine()..turn = Player.red;
      final beforeOwn = engine.shortestPathLength(Player.red)!;
      final beforeOpponent = engine.shortestPathLength(Player.blue)!;
      final action = BotPlayer(
        difficulty: BotDifficulty.easy,
        random: Random(7),
      ).choose(engine);

      if (action.isMove) {
        expect(action.cell!.row, greaterThan(engine.red.row));
      } else {
        expect(action.isWall, isTrue);
        expect(
          engine.placeWall(
            row: action.row!,
            col: action.col!,
            orientation: action.orientation!,
          ),
          isTrue,
        );
        final ownDamage =
            engine.shortestPathLength(Player.red)! - beforeOwn;
        final opponentDamage =
            engine.shortestPathLength(Player.blue)! - beforeOpponent;
        expect(opponentDamage, greaterThanOrEqualTo(ownDamage));
      }
    });

    test('every bot level takes an immediate winning move', () {
      for (final difficulty in BotDifficulty.values) {
        final engine = GameEngine()
          ..red = const Cell(7, 4)
          ..blue = const Cell(4, 4)
          ..turn = Player.red;
        final action = BotPlayer(
          difficulty: difficulty,
          random: Random(3),
        ).choose(engine);
        expect(action, const BotAction.move(Cell(8, 4)));
      }
    });

    test('every bot level blocks an immediate opponent win', () {
      for (final difficulty in BotDifficulty.values) {
        final engine = GameEngine()
          ..blue = const Cell(1, 4)
          ..red = const Cell(4, 4)
          ..turn = Player.red;
        final action = BotPlayer(
          difficulty: difficulty,
          random: Random(11),
        ).choose(engine);

        final applied = action.isMove
            ? engine.move(action.cell!)
            : action.isWall &&
                engine.placeWall(
                  row: action.row!,
                  col: action.col!,
                  orientation: action.orientation!,
                );
        expect(applied, isTrue, reason: 'difficulty: $difficulty');
        final blueCanWinNow = engine
            .legalMoves(Player.blue)
            .any((cell) => cell.row == 0);
        expect(blueCanWinNow, isFalse, reason: 'difficulty: $difficulty');
      }
    });
    test('easy bot returns a legal action', () {
      final engine = GameEngine()..turn = Player.red;
      final bot = BotPlayer(
        difficulty: BotDifficulty.easy,
        random: Random(1),
      );
      final action = bot.choose(engine);
      final legal = action.isMove
          ? engine.legalMoves().contains(action.cell)
          : action.isWall &&
              engine.canPlaceWall(
                row: action.row!,
                col: action.col!,
                orientation: action.orientation!,
              );
      expect(legal, isTrue);
    });


    test('hard bot recalculates after a simulated user reply', () {
      final engine = GameEngine();
      expect(engine.move(const Cell(7, 4)), isTrue);
      expect(engine.move(const Cell(1, 4)), isTrue);
      expect(
        engine.placeWall(
          row: 4,
          col: 3,
          orientation: WallOrientation.horizontal,
        ),
        isTrue,
      );

      final firstBotAction = BotPlayer(
        difficulty: BotDifficulty.hard,
        random: Random(17),
      ).choose(engine);
      final firstApplied = firstBotAction.isMove
          ? engine.move(firstBotAction.cell!)
          : firstBotAction.isWall &&
              engine.placeWall(
                row: firstBotAction.row!,
                col: firstBotAction.col!,
                orientation: firstBotAction.orientation!,
              );
      expect(firstApplied, isTrue);

      final userPath = engine.shortestPath(Player.blue);
      expect(userPath.length, greaterThan(1));
      expect(engine.move(userPath[1]), isTrue);

      final response = BotPlayer(
        difficulty: BotDifficulty.hard,
        random: Random(19),
      ).choose(engine);
      final responseIsLegal = response.isMove
          ? engine.legalMoves().contains(response.cell)
          : response.isWall &&
              engine.canPlaceWall(
                row: response.row!,
                col: response.col!,
                orientation: response.orientation!,
              );
      expect(responseIsLegal, isTrue);
    });
  });
}
