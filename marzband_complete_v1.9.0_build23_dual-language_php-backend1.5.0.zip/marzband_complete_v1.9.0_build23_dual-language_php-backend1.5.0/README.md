# Marzband complete dual-language release 1.9.0+23

Contents:

- `flutter/`: repository-ready English and Persian Flutter sources
- `backend/`: shared PHP `1.5.0` backend (`api` + `admin-panel`)
- `workflow/`: standalone copy of the GitHub Actions workflow

Workflow outputs:

1. Signed English APK
2. Signed English AAB
3. Signed Persian APK
